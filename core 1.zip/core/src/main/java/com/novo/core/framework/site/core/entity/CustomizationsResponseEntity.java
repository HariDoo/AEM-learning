package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a response entity for customizations.
 * It contains a list of organizations entity.
 */
public class CustomizationsResponseEntity {

    /**
     * Get the list of organizations entity.
     * @return A list of organizations entity
     */
    public List<OrganizationsEntity> getOrganizationsEntityList() {
        return organizationsEntityList;
    }

    /**
     * Set the list of organizations entity.
     * @param organizationsEntityList A list of organizations entity
     */

    public void setOrganizationsEntityList(List<OrganizationsEntity> organizationsEntityList) {
        this.organizationsEntityList = new ArrayList<>(organizationsEntityList);
    }

    /**
     * List of organizations associated with this user.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<OrganizationsEntity> organizationsEntityList;

}
