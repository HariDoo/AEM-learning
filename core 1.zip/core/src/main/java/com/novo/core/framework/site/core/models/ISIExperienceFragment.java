package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.designer.Style;
import com.novo.core.framework.site.core.utils.FragmentUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

/**
 * Model class for ISI Experience Fragment component.
 *
 * @author fsurat
 */
@Model(adaptables = {SlingHttpServletRequest.class,Resource.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ISIExperienceFragment {

    @Inject
    @Via("resource")
    private String fragmentPath;

    @SlingObject
    private ResourceResolver resourceResolver;

    @ScriptVariable
    private Page currentPage;

    @ScriptVariable
    private Style currentStyle;

    public String getFragmentPath() {
        return fragmentPath;
    }

    /**
     * Initializer method for Model class
     */
    @PostConstruct
    public void init() {
        fragmentPath = FragmentUtil.getPath(StringUtils.isNotBlank(fragmentPath) ? fragmentPath : currentStyle.get("fragmentPath",StringUtils.EMPTY),
            currentPage,
            resourceResolver
        );
    }
}
