package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static com.novo.core.framework.site.core.models.DropDownItem.addHtmlExtension;

/**
 * Class having properties used to override link title and target for global navigation
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NavigationItem {

    /**
     * The current brand
     */
    private String brand;

    /**
     * Current link title
     */
    private String title;

    /**
     * Current link target
     */
    private String link;

    /**
     * Gets the link properties for the given node resource
     * @param item child resource of current link node
     * @return a NavigationItem object containing the link title and link target
     */
    public static NavigationItem build(Resource item) {
        final ValueMap map = item.getValueMap();
        if(!map.isEmpty()) {
            final NavigationItem navigationItem = new NavigationItem();
            String link = map.get("link", String.class);
            if (isNotEmpty(link) && !link.startsWith("javascript:")) {
                link = addHtmlExtension(link);
            }
            navigationItem.setLink(link);
            navigationItem.setBrand(map.get("brand", String.class));
            navigationItem.setTitle(map.get("title", String.class));
            return navigationItem;
        }

        return null;
    }

    /**
     * Gets the overridden link target
     * @return a String with the overridden link target
     */
    public String getLink() {
        return link;
    }

    /**
     * Gets the Brand setup for this configuration
     * @return a String with the current brand for this configuration
     */
    public String getBrand() {
        return brand;
    }

    /**
     * Gets the overridden link title
     * @return a String with the overridden link title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the new target for the current link
     * @param link a String with the new link target
     */
    public void setLink(String link) {
        this.link = link;
    }

    /*
     * Sets the current Brand name setup for this configuration
     */
    public void setBrand(String brandName) {
        this.brand = brandName;
    }

    /**
     * Sets the new title for the current link
     * @param title a String with the new link title
     */
    public void setTitle(String title) {
        this.title = title;
    }
}
