package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class StateNamesEntity {

    /**
     *state name field.
     */
    @ValueMapValue
    private String stateName;
    /**
     *state code field.
     */
    @ValueMapValue
    private String stateValue;

    public String getStateName() {
        return stateName;
    }

    public String getStateValue() {
        return stateValue;
    }
}
