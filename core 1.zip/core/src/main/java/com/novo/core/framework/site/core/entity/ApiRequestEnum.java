package com.novo.core.framework.site.core.entity;

/**
 * Enum to be used for type of request
 *
 * @since 1.0
 * @version 1.0
 */
public enum ApiRequestEnum {

    CREATE_CART,
    GET_CART,
    DELETE_CART,
    CREATE_CART_CONTENT,
    GET_CART_CONTENT,
    UPLOAD_LOGO,
    CREATE_CUSTOMIZATION,
    GET_CUSTOMIZATION,
    UPDATE_CART,
    ORGANIZATION_DETAILS,
    UPDATE_ORGANIZATION_DETAILS
}
