package com.novo.core.framework.site.core.utils;

import com.day.cq.commons.jcr.JcrConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.util.Charsets;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.models.ContentModel;
import com.novo.core.framework.site.core.models.PublishContentModel;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.LogoConfigService;
import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.novo.core.framework.site.core.constants.MessageConstant.*;

/**
 * The class {@code CartUtils} that contains all static methods
 * required for the services
 *
 * @version 1.0
 * @since 1.0
 */
public class CartUtils {
    /**
     * The ID of the organization.
     */
    public static final String ORGANIZATION_ID = "organizationId";
    /**
     * The authentication token.
     */
    public static final String AUTH_TOKEN = "authToken";
    /**
     * The default file size.
     */
    private static final int DEFAULT_FILESIZE = 1024;
    /**
     * The key for the cart unique identifier.
     */
    private static final String CART_UNIQUE_KEY = "CartUniqueKey";
    /**
     * The type of disease.
     */
    private static final String DISEASE_TYPE = "diseaseType";
    /**
     * The slash character.
     */
    private static final String SLASH = "/";
    /**
     * The unique key string.
     */
    private static final String UNIQUE_KEY = "?uniqueKey=";
    /**
     *This constant represents the payload for the request.
     */
    public static final String PAYLOAD_FOR_THE_REQUEST = "Payload for the request :: {}";
    /**
     *This constant represents the response entity returned by
     * the getCartsResponseEntity method.
     */
    public static final String DATA_NOT_FOUND_CART_APISERVLET_GET_CARTS_RESPONSE_ENTITY = "Data Not Found : CartAPIServlet() :: getCartsResponseEntity ";

    /**
     *This is a logger instance used for logging cart
     * utility messages.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CartUtils.class);
    /**
     * Used for html extension.
     */
    public static final String HTML = ".html";


    /**
     * Method to make GET Request
     *
     * @param url to be used to make request
     * @param requestJson to be passed as request param
     * @return {@link ClientResponse}
     * @throws IOException when not able to connect to the server
     */
    public static ClientResponse sendGET(final String url, final Map<String, String> requestJson) throws IOException {

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Url for GET Request :: {}", url.replaceAll("[\n\r]", "_"));
            LOGGER.info("PayLoad for request :: {}", url.replaceAll("[\n\r]", "_"));
        }
        ClientResponse clientResponse = new ClientResponse();
        if (StringUtils.isBlank(url))
            return new ClientResponse();
        final HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader(CommonConstants.CONTENT_TYPE, CommonConstants.CONTENT_TYPE_JSON);
        for (Map.Entry<String, String> key : requestJson.entrySet()) {
            httpGet.setHeader(key.getKey(), key.getValue());
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); final CloseableHttpResponse httpResponse = httpClient.execute(httpGet)) {
            HttpEntity httpEntity = httpResponse.getEntity();
            clientResponse.setStatusCode(httpResponse.getStatusLine().getStatusCode());
            if (httpEntity != null) {
                String result = EntityUtils.toString(httpEntity, Charsets.UTF_8);
                clientResponse.setData(result);
                EntityUtils.consume(httpEntity);
            }

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Response data after GET request execution :: {}", clientResponse.getData());
                LOGGER.info("Response code after GET request execution :: {}", clientResponse.getStatusCode());
            }
            return clientResponse;
        }catch (IOException e) {
            LOGGER.info("CartUtils : sendGET() : IO Exception occured while getting Object from request {0}", e);
        }
        return clientResponse;
    }

    /**
     * Method to make DELETE Request
     *
     * @param url to be used to make delete request
     * @param requestJson params to be used for the request
     * @return {@link ClientResponse}
     * @throws IOException when not able to connect to microservice
     */
    public static ClientResponse sendDELETE(final String url, final Map<String, String> requestJson) throws IOException {

        if (StringUtils.isBlank(url))
            return new ClientResponse();
        final HttpDelete httpDelete = new HttpDelete(url);
        httpDelete.setHeader(CommonConstants.CONTENT_TYPE, CommonConstants.CONTENT_TYPE_JSON);
        for (Map.Entry<String, String> key : requestJson.entrySet()) {
            httpDelete.setHeader(key.getKey(), key.getValue());
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault(); final CloseableHttpResponse httpResponse = httpClient.execute(httpDelete)) {
            HttpEntity httpEntity = httpResponse.getEntity();
            ClientResponse clientResponse = new ClientResponse();
            clientResponse.setStatusCode(httpResponse.getStatusLine().getStatusCode());
            if (httpEntity != null) {
                String result = EntityUtils.toString(httpEntity, Charsets.UTF_8);
                clientResponse.setData(result);
                EntityUtils.consume(httpEntity);
            }
            return clientResponse;
        }
    }


    /**
     * Method to make POST Request
     *
     * @param url to be used to make delete request
     * @param requestBody to be used for making the request
     * @param requestJson to be used as the body
     * @return {@link ClientResponse}
     * @throws IOException when not able to connect to microservice
     */
    public static ClientResponse sendPOST(final String url, final String requestBody, final Map<String, String> requestJson) throws IOException {

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Url for POST Request :: {}", url);
            LOGGER.info(PAYLOAD_FOR_THE_REQUEST, requestBody);
            LOGGER.info("Header for POST :: {}", requestJson);
        }


        if (StringUtils.isBlank(url))
            return new ClientResponse();
        final HttpPost post = new HttpPost(url);

        for (Map.Entry<String, String> key : requestJson.entrySet()) {
            post.setHeader(key.getKey(), key.getValue());
        }
        if (StringUtils.isNotBlank(requestBody)) {
            post.addHeader(CommonConstants.CONTENT_TYPE, CommonConstants.CONTENT_TYPE_JSON);
            post.setEntity(new StringEntity(requestBody));
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             final CloseableHttpResponse httpResponse = httpClient.execute(post)) {
            HttpEntity httpEntity = httpResponse.getEntity();
            ClientResponse clientResponse = new ClientResponse();
            clientResponse.setStatusCode(httpResponse.getStatusLine().getStatusCode());
            if (httpEntity != null) {
                String result = EntityUtils.toString(httpEntity, Charsets.UTF_8);
                clientResponse.setData(result);
                EntityUtils.consume(httpEntity);
            }

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Response data after POST request execution :: {}", clientResponse.getData());
                LOGGER.info("Response code after POST request execution :: {}", clientResponse.getStatusCode());
            }
            return clientResponse;
        }
    }


    /**
     * Method to make PUT Request
     * @param url to be used to make update request
     * @param requestBody to be used for making the request
     * @param requestJson to be used as the body
     * @return {@link ClientResponse}
     * @throws IOException when not able to connect to microservice
     */
    public static ClientResponse sendPUT(final String url, final String requestBody, final Map<String, String> requestJson) throws IOException {

        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Url for PUT Request :: {}", url);
            LOGGER.info(PAYLOAD_FOR_THE_REQUEST, requestBody);
            LOGGER.info("Header for PUT :: {}", requestJson);
        }

        if (StringUtils.isBlank(url))
            return new ClientResponse();
        final HttpPut put = new HttpPut(url);

        for (final Map.Entry<String, String> key : requestJson.entrySet()) {
            put.setHeader(key.getKey(), key.getValue());
        }
        if (StringUtils.isNotBlank(requestBody)) {
            put.addHeader(CommonConstants.CONTENT_TYPE, CommonConstants.CONTENT_TYPE_JSON);
            put.setEntity(new StringEntity(requestBody));
        }
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             final CloseableHttpResponse httpResponse = httpClient.execute(put)) {
            final HttpEntity httpEntity = httpResponse.getEntity();
            final ClientResponse clientResponse = new ClientResponse();
            clientResponse.setStatusCode(httpResponse.getStatusLine().getStatusCode());
            if (httpEntity != null) {
                final String result = EntityUtils.toString(httpEntity, Charsets.UTF_8);
                clientResponse.setData(result);
                EntityUtils.consume(httpEntity);
            }

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Response data after PUT request execution :: {}", clientResponse.getData());
                LOGGER.info("Response code after PUT request execution :: {}", clientResponse.getStatusCode());
            }
            return clientResponse;
        }
    }

    /**
     * Method to get UserId from Client Response
     *
     * @param clientResponse represents novo api response
     * @return {@link Long} of given {@link Class}
     * @throws JSONException when not able to get elements from json
     */
    public static long getIdFromUserObj(ClientResponse clientResponse) throws JSONException {
        long profileId = 0;
        if (clientResponse != null && clientResponse.getStatusCode() == HttpServletResponse.SC_OK && StringUtils.isNotBlank(clientResponse.getData())) {
            JSONObject jsonObject = new JSONObject(clientResponse.getData());
            LOGGER.debug("User id before type casting {}",clientResponse.getData());
            profileId = jsonObject.getLong(CommonConstants.ID);
            LOGGER.debug("User id after type casting {}",clientResponse.getData());
        }
        return profileId;
    }

    /**
     * Returns the object of Type T fetched from {@link SlingHttpServletRequest}}
     *
     * @param slingHttpServletRequest {@link SlingHttpServletRequest}
     * @param type                    {@link Class}
     * @return {@link Object} of given {@link Class}
     */
    public static <T> T getObjectFromRequest(final SlingHttpServletRequest slingHttpServletRequest, final Class<T> type)  {
        T object = null;
        if (slingHttpServletRequest != null) {
            try (final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(slingHttpServletRequest.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                object = new Gson().fromJson(String.valueOf(stringBuilder), type);
            } catch (final IOException ioException) {
                LOGGER.error("CartUtils : getObjectFromRequest() : IO Exception occured while getting Object from request {0}", ioException);
            }
        }
        return object;
    }

    /**
     * ethod to get ResourceResolver from ResourceResolverFactory
     *
     * @param resourceResolverFactory {@link ResourceResolverFactory} to be passed
     * @param subService is the name of the service user
     * @return {@link ResourceResolver}
     */
    public static ResourceResolver getResourceResolver(final ResourceResolverFactory resourceResolverFactory,
                                                       final String subService) {
        ResourceResolver resourceResolver = null;
        if (null != resourceResolverFactory && StringUtils.isNotBlank(subService)) {
            try {
                final Map<String, Object> authInfo = new HashMap<>();
                authInfo.put(ResourceResolverFactory.SUBSERVICE, subService);
                resourceResolver = resourceResolverFactory.getServiceResourceResolver(authInfo);
            } catch (final LoginException loginException) {
                LOGGER.error(
                        "CartUtils getResourceResolver() : Exception while getting resource resolver for subservice {} : {}",
                        subService, loginException);
            }
        }
        return resourceResolver;
    }

    /**
     * Method to get HTML from the nodePath
     *
     * @param nodePath the path in the repository containing mailer template HTML
     * @param session {@link Session} object to be passe
     * @return {@link String}
     */
    public static String getStringFromNodePath(final String nodePath, final Session session) {
        try {
            if (nodePath != null) {
                final Node contentNode = session.getNode(nodePath);
                if (contentNode != null) {
                    final InputStream emailStream = contentNode.getProperty(JcrConstants.JCR_DATA).getBinary()
                            .getStream();
                    return IOUtils.toString(emailStream, StandardCharsets.UTF_8);
                }
            }
        } catch (final RepositoryException repositoryException) {
            LOGGER.error(
                    "CartUtils :  getStringFromNodePath() : Respository Exception occured while reading the node of path {0}",
                    repositoryException);
        } catch (final IOException ioException) {
            LOGGER.error(
                    "CartUtils :  getStringFromNodePath() : IO Exception occured while reading the node of path {0}",
                    ioException);
        }
        return null;
    }

    /**
     * Method to get API response from .NET side
     *
     * @param response {@link SlingHttpServletResponse} object to be passed
     * @param obj is the object needs to be send as the part of response
     * @param statusCode to be added in the response headers
     */
    public static void sendAPIResponse(SlingHttpServletResponse response, Object obj, int statusCode) {
        response.setStatus(statusCode);
        response.setContentType(CommonConstants.CONTENT_TYPE_JSON);
        response.setCharacterEncoding(CommonConstants.UTF_8_ENCODING);
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            response.getWriter().write(objectMapper.writeValueAsString(obj));
        } catch (IOException e) {
            LOGGER.error("CartUtils :: sendAPIResponse :: IO Exception while sending the response");
        }
    }

    /**
     * Generic method to map json response to entity class
     *
     * @param object is the object that is needed to be converted in the class
     * @param type represents which class the object should get type casted into
     * @param <T>    type is mapped entity class
     * @return mapped entity
     */
    public static <T> T objectMapper(Object object, final Class<T> type) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.convertValue(object, type);
    }


    /**
     * Method to validate get cart content api request params
     *
     * @param saveCartContentRequestEntity represents {@link SaveCartContentRequestEntity}
     * @param contentDistributionMsgConfigService represents {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestGetCartContent(SaveCartContentRequestEntity saveCartContentRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(saveCartContentRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_CONTENT_PROFILE_NOT_FOUND), HttpServletResponse.SC_FORBIDDEN);
    }

    /**
     * Method to validate create cart content api request params
     *
     * @param saveCartContentRequestEntity represents {@link SaveCartContentRequestEntity}
     * @param contentDistributionMsgConfigService represents {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestCreateCartContent(SaveCartContentRequestEntity saveCartContentRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(saveCartContentRequestEntity.getDiseaseType()) && StringUtils.isBlank(saveCartContentRequestEntity.getAuthToken()))
            throw new CartServletException(false,contentDistributionMsgConfigService.getApiResponseMessage(CREATE_CART_CONTENT_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(saveCartContentRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(CREATE_CART_CONTENT_PROFILE_NOT_FOUND), HttpServletResponse.SC_FORBIDDEN);
        else if (StringUtils.isBlank(saveCartContentRequestEntity.getDiseaseType()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(CREATE_CART_CONTENT_INVALID_DISEASE_TYPE), HttpServletResponse.SC_BAD_REQUEST);
        else if (saveCartContentRequestEntity.getContentData() == null)
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(CREATE_CART_CONTENT_INVALID_CONTENT), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method to validate get cart api request params
     *
     * @param cartRequestEntity represents {@link CartRequestEntity}
     * @param contentDistributionMsgConfigService represents {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestGetCart(CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(cartRequestEntity.getAuthToken()) && StringUtils.isBlank(cartRequestEntity.getDiseaseType()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_INVALID_AUTH_TOKEN), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getDiseaseType()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_INVALID_DISEASE_TYPE), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method to validate get cart api request params
     *
     * @param cartRequestEntity represents {@link CartRequestEntity}
     * @param contentDistributionMsgConfigService represents
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestGetCustomizations(CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(cartRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_INVALID_AUTH_TOKEN), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method to validate create cart api request params
     *
     * @param cartRequestEntity represents {@link CartRequestEntity}
     * @param contentDistributionMsgConfigService represents
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestCreateCart(CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        final String cartName = cartRequestEntity.getCartName();
        if (StringUtils.isBlank(cartRequestEntity.getAuthToken()) && StringUtils.isBlank(cartRequestEntity.getDiseaseType()) && StringUtils.isBlank(cartRequestEntity.getCartName()) && StringUtils.isBlank(cartRequestEntity.getOrganizationId()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_AUTH_TOKEN_CONST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getDiseaseType()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_DISEASE_TYPE_CONST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getCartName()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_EMPTY_CART_NAME), HttpServletResponse.SC_BAD_REQUEST);
        else if (cartName == null || cartName.trim().isEmpty() || cartName.length() > 50)
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_INVALID_CART_NAME), HttpServletResponse.SC_BAD_REQUEST);
        else if (cartRequestEntity.getMaxCount() <= 0)
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_MAX_LIMIT_REACH), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method to validate update cart api request params
     *
     * @param cartRequestEntity represents {@link CartRequestEntity}
     * @param contentDistributionMsgConfigService represents
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestUpdateCart(CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(cartRequestEntity.getAuthToken()) && StringUtils.isBlank(cartRequestEntity.getCartName()) && StringUtils.isBlank(cartRequestEntity.getOrganizationId()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(POST_CART_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(PUT_CART_AUTH_TOKEN_CONST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getOrganizationId()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(PUT_CART_ORGANIZATION_ID_MISSING), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartRequestEntity.getCartName()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(PUT_CART_EMPTY_CART_NAME), HttpServletResponse.SC_BAD_REQUEST);
        else if (cartRequestEntity.getCartName().length() > 50)
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(PUT_CART_INVALID_CART_NAME), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method to validate delete cart api request params
     *
     * @param cartId represents cartId param
     * @param authToken represents authToken param
     * @param contentDistributionMsgConfigService represents {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when validation fails
     */
    public static void validateRequestDeleteCart(String cartId, String authToken, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if (StringUtils.isBlank(authToken) && StringUtils.isBlank(cartId))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(DELETE_CART_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(authToken))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(DELETE_CART_INVALID_AUTH_TOKEN), HttpServletResponse.SC_BAD_REQUEST);
        else if (StringUtils.isBlank(cartId))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(DELETE_CART_INVALID_CART_ID), HttpServletResponse.SC_BAD_REQUEST);
    }


    /**
     * Method to map GET cart content API response to {@link ResponseEntity}
     *
     * @param clientResponse represents {@link ClientResponse} object
     * @param resourceResolver represents {@link ResourceResolver}
     * @param isPublishCartContent is the flag to check if this method is used for publish
     *                             cart content or another api
     * @throws JSONException when not able to get element as required from json object
     */
    public static SaveCartContentRequestEntity[] responseEntityForGetCartContent(ClientResponse clientResponse, ResourceResolver resourceResolver, boolean isPublishCartContent) throws JSONException {
        JSONObject jsonObjectResponse = new JSONObject(clientResponse.getData());
        JSONObject jsonObject = jsonObjectResponse.getJSONObject(CommonConstants.DATA);
        if (jsonObject.has(CommonConstants.CART_CONTENT)) {
            JSONArray dataArray = jsonObject.getJSONArray(CommonConstants.CART_CONTENT);
            SaveCartContentRequestEntity[] saveCartContentRequestEntityList = new Gson().fromJson(String.valueOf(dataArray), SaveCartContentRequestEntity[].class);
            for (SaveCartContentRequestEntity saveCartContentRequestEntity :
                    saveCartContentRequestEntityList) {
                List<ContentDataEntity> contentDataEntityList = new ArrayList<>();
                for (ContentDataEntity entity :
                        saveCartContentRequestEntity.getContentData()) {
                    Resource resource = resourceResolver.getResource(entity.getPath().concat(SLASH).concat(JcrConstants.JCR_CONTENT));
                    if (resource==null){
                        saveCartContentRequestEntity.getContentData().remove(entity);
                        break;
                    }
                    if (isPublishCartContent ) {
                        PublishContentModel publishContentModel = resource.adaptTo(PublishContentModel.class);
                        publishContentModel.setOrder(entity.getOrder());
                        publishContentModel.setPath(entity.getPath());
                        entity = objectMapper(publishContentModel, ContentDataEntity.class);
                    } else{
                        ContentModel contentModel = resource.adaptTo(ContentModel.class);
                        if(contentModel != null) {
                            contentModel.setOrder(entity.getOrder());
                            entity = objectMapper(contentModel, ContentDataEntity.class);
                        }
                        else {
                            LOGGER.error("CartUtilsServlet :: responseEntityForGetCartContent() :: Unable to bind up the ContentModelEntity");
                        }
                    }
                    contentDataEntityList.add(entity);
                }
                saveCartContentRequestEntity.setContentData(contentDataEntityList);
            }
            return  saveCartContentRequestEntityList;
        }
        return new SaveCartContentRequestEntity[0];
    }

    /**
     * Method to get the {@link CartContentResponseEntity}
     * for publish cart content api servlet
     *
     * @param saveCartContentRequestEntities represents {@link SaveCartContentRequestEntity} array
     * @param clientResponse represents {@link ClientResponse}
     * @return CartContentResponseEntity objet after adding logo props to it
     * @throws JSONException if not able to get the properties from json object
     */
    public static CartContentResponseEntity publishCartContentResponse(SaveCartContentRequestEntity[] saveCartContentRequestEntities,ClientResponse clientResponse) throws JSONException {
        JSONObject jsonObjectResponse = new JSONObject(clientResponse.getData());
        JSONObject jsonObject = jsonObjectResponse.getJSONObject(CommonConstants.DATA);
        if (jsonObject.has(CommonConstants.ORGANIZATION_DETAILS)){
            final JSONObject jsonLogoObj = jsonObject.getJSONObject(CommonConstants.ORGANIZATION_DETAILS);
            OrganizationDetailsRequestEntity logoprops = new Gson().fromJson(String.valueOf(jsonLogoObj),OrganizationDetailsRequestEntity.class);

            return new CartContentResponseEntity(saveCartContentRequestEntities,logoprops);
        }
        return new CartContentResponseEntity();
    }
    /**
     * Method to map {@link SlingHttpServletRequest} parameters to {@link SaveCartContentRequestEntity}
     *
     * @param request represents {@link SlingHttpServletRequest}
     * @return {@link SaveCartContentRequestEntity}
     */
    public static SaveCartContentRequestEntity getSaveCartContentRequestEntityFromRequest(SlingHttpServletRequest request) {
        SaveCartContentRequestEntity saveCartContentRequestEntity = new SaveCartContentRequestEntity();
        if (StringUtils.isNotBlank(request.getParameter(AUTH_TOKEN)))
            saveCartContentRequestEntity.setAuthToken(request.getParameter(AUTH_TOKEN));
        return saveCartContentRequestEntity;
    }

    /**
     * Method to map {@link SlingHttpServletRequest} parameters to {@link CartRequestEntity}
     *
     * @param request represents {@link SlingHttpServletRequest}
     * @return {@link CartRequestEntity}
     */
    public static CartRequestEntity createCartRequestEntityFromRequest(SlingHttpServletRequest request) {
        CartRequestEntity cartRequestEntity = new CartRequestEntity();
        if (StringUtils.isNotBlank(request.getParameter(AUTH_TOKEN)))
            cartRequestEntity.setAuthToken(request.getParameter(AUTH_TOKEN));
        if (StringUtils.isNotBlank(request.getParameter(DISEASE_TYPE)))
            cartRequestEntity.setDiseaseType(request.getParameter(DISEASE_TYPE));
        return cartRequestEntity;
    }

    /**
     * Method to map {@link SlingHttpServletRequest}
     * parameters to {@link CartRequestEntity}
     * @param request represents {@link SlingHttpServletRequest}
     * @return {@link CartRequestEntity}
     */
    public static CartRequestEntity getOrganizationDetailsEntityFromRequest(SlingHttpServletRequest request) {
        final CartRequestEntity cartRequestEntity = new CartRequestEntity();
        if (StringUtils.isNotBlank(request.getParameter(AUTH_TOKEN)))
            cartRequestEntity.setAuthToken(request.getParameter(AUTH_TOKEN));
        if (StringUtils.isNotBlank(request.getParameter(ORGANIZATION_ID)))
            cartRequestEntity.setOrganizationId(request.getParameter(ORGANIZATION_ID));
        return cartRequestEntity;
    }

    /**
     * Method to map {@link SlingHttpServletRequest}
     * parameters to {@link CartRequestEntity}
     * @param request represents {@link SlingHttpServletRequest}
     * @return {@link CartRequestEntity}
     */
    public static CartRequestEntity getCustomizationsRequestEntityFromRequest(SlingHttpServletRequest request) {
        final CartRequestEntity cartRequestEntity = new CartRequestEntity();
        if (StringUtils.isNotBlank(request.getParameter(AUTH_TOKEN)))
            cartRequestEntity.setAuthToken(request.getParameter(AUTH_TOKEN));
        return cartRequestEntity;
    }
    /**
     * Method to map GET cart API response to {@link CartResponseEntity}
     *
     * @param clientResponse represents {@link ClientResponse}
     *
     * @return {@link CartRequestEntity}
     * @throws JSONException when not able to retrieve json properties from object
     */
    public static CartResponseEntity getCartsResponseEntity(ClientResponse clientResponse,
                                                            String publishPagePath) throws JSONException {
        CartResponseEntity cartResponseEntity = new CartResponseEntity();
        JSONObject jsonClientResponse = new JSONObject(clientResponse.getData());
        JSONObject jsonCarts = jsonClientResponse.getJSONObject(CommonConstants.DATA);
        if (jsonClientResponse.has(CommonConstants.DATA) && jsonCarts.length() != 0) {
            if (jsonCarts.getJSONArray("cartContent").length() == 0) {
                LOGGER.error("CartUtils Servlet: getCartsResponseEntity() : CartResponseEntity is blank");
                cartResponseEntity  = new CartResponseEntity();
            }
            else {
                cartResponseEntity = new Gson().fromJson(jsonCarts.toString(), CartResponseEntity.class);
                LOGGER.error("CartUtils Servlet: getCartsResponseEntity() : CartResponseEntity got successfully");
                for (final CartEntity cartEntity : cartResponseEntity.getCartContent()) {
                    if (cartEntity.getOrganizationId() == null) {
                        cartEntity.setOrganizationId(0);
                        cartEntity.setCustomizationName("No Customization");
                    }
                }
                setPublishUrlInCartResponseEntity(cartResponseEntity, publishPagePath);
            }
        } else {
            LOGGER.debug(DATA_NOT_FOUND_CART_APISERVLET_GET_CARTS_RESPONSE_ENTITY);
        }
        return cartResponseEntity;
    }


    /**
     * Method to get customization list in response entity
     *
     * @param clientResponse represents {@link ClientResponse}
     */
    public static List<OrganizationsEntity> getCustomizationResponseEntity(ClientResponse clientResponse) throws JSONException, IOException {
        List<OrganizationsEntity> organizationEntity = new ArrayList<>();
        final JSONObject jsonClientResponse = new JSONObject(clientResponse.getData());
        if (jsonClientResponse.has(CommonConstants.DATA)) {
            final JSONArray jsonCarts = jsonClientResponse.getJSONArray(CommonConstants.DATA);
            if (jsonCarts != null) {
                organizationEntity =  new ObjectMapper().readValue(String.valueOf(jsonCarts), new TypeReference<List<OrganizationsEntity>>(){
                });
            }
        } else {
            LOGGER.debug(DATA_NOT_FOUND_CART_APISERVLET_GET_CARTS_RESPONSE_ENTITY);
        }
        return organizationEntity;
    }


    /**
     * Method to get organizationDetails in response entity
     *
     * @param clientResponse represents {@link ClientResponse}
     */
    public static OrganizationDetailsRequestEntity getOrganizationDetailsData(ClientResponse clientResponse)
            throws JSONException, IOException {
        OrganizationDetailsRequestEntity detailsRequest = new OrganizationDetailsRequestEntity();
        final JSONObject jsonClientResponse = new JSONObject(clientResponse.getData());
        if (jsonClientResponse.has(CommonConstants.DATA)) {
            final JSONObject jsonCarts = jsonClientResponse.getJSONObject(CommonConstants.DATA);
            if (jsonCarts != null) {
                detailsRequest =  new ObjectMapper().readValue(String.valueOf(jsonCarts),
                        new TypeReference<OrganizationDetailsRequestEntity>(){});
            }
        } else {
            LOGGER.debug(DATA_NOT_FOUND_CART_APISERVLET_GET_CARTS_RESPONSE_ENTITY);
        }
        return detailsRequest;
    }


    /**
     * Method to set publish url in the response entity
     *
     * @param cartResponseEntity represents {@link ClientResponse}
     */
    private static void setPublishUrlInCartResponseEntity(CartResponseEntity cartResponseEntity,
                                                          String publishPagePath) {
        for (CartEntity entity : cartResponseEntity.getCartContent()) {
            if (StringUtils.isNotBlank(entity.getUniqueId()))
                entity.setPublishUrl(publishPagePath+ HTML +UNIQUE_KEY+entity.getUniqueId());
        }
    }

    /**
     * Method to validate Status code of {@link ClientResponse}
     *
     * @param response represents {@link ClientResponse}
     * @return {@link Integer} reprenting the status code
     */
    public static int getValidStatusCode(ClientResponse response) {
        return Objects.isNull(response) ? HttpServletResponse.SC_INTERNAL_SERVER_ERROR : response.getStatusCode();
    }

    /**
     * Method to get the key from the response object
     *
     * @param response represent {@link ClientResponse}
     * @return String that represents uniqueKey
     * @throws JSONException when not able to get element from json object
     */
    public static String getKeyFromPostCartContentResponse(ClientResponse response) throws JSONException {
        JSONObject jsonObj = new JSONObject(response.getData());
        String uniqueKey = StringUtils.EMPTY;
        if (jsonObj.has(CommonConstants.DATA)) {
            JSONObject dataObj = jsonObj.getJSONObject(CommonConstants.DATA);
            if (dataObj != null && dataObj.has(CART_UNIQUE_KEY)) {
                uniqueKey = dataObj.getString(CART_UNIQUE_KEY);
            }
        }
        return uniqueKey;
    }

    /**
     * Method to get organizationDetails in response entity.
     * @param response
     * @return
     * @throws JSONException
     */
    public static OrganizationDetailsRequestEntity getOrganizationDetailsResponse(ClientResponse response) throws JSONException {
        OrganizationDetailsRequestEntity organizationDetailsRequestEntity =new OrganizationDetailsRequestEntity();
        final JSONObject jsonObj = new JSONObject(response.getData());
        final JSONObject jsonCarts = jsonObj.getJSONObject(CommonConstants.DATA);
        if (jsonCarts.has(CommonConstants.ORGANIZATION_DETAILS)) {
            final JSONObject dataObj = jsonCarts.getJSONObject(CommonConstants.ORGANIZATION_DETAILS);
            organizationDetailsRequestEntity = new Gson().fromJson(String.valueOf(dataObj), OrganizationDetailsRequestEntity.class);
        }
        return organizationDetailsRequestEntity;
    }

    /**
     * Method to validate file size and format from the request
     * @param logoRequestEntity {@link LogoRequestEntity} object
     * @param logoConfigService {@link LogoConfigService}
     * @param contentDistributionMsgConfigService
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when any validation fails
     */
    public static void validateFileSizeAndFormat(LogoRequestEntity logoRequestEntity, LogoConfigService logoConfigService, ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {

        if (logoRequestEntity.getBase64Image().length() > logoConfigService.getFileSize() * DEFAULT_FILESIZE * DEFAULT_FILESIZE)
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(UPLOAD_CUSTOMIZATION_FILE_SIZE_EXCEED), HttpServletResponse.SC_BAD_REQUEST);
        if (Arrays.stream(logoConfigService.getFileFormat()).noneMatch(entry -> logoRequestEntity.getFilename().toLowerCase().endsWith(entry)))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(UPLOAD_CUSTOMIZATION_FILE_FORMAT_INVALID), HttpServletResponse.SC_BAD_REQUEST);
    }

    /**
     * Method used to validate null and blanks in logo servlet request
     *
     * @param logoRequestEntity represents {@link LogoRequestEntity}
     * @param contentDistributionMsgConfigService represents
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when any validation fails
     */
    public static void validateUploadLogoRequest(LogoRequestEntity logoRequestEntity,ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if(StringUtils.isBlank(logoRequestEntity.getCustomizationName()) && StringUtils.isBlank(logoRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPLOAD_CUSTOMIZATION_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if(StringUtils.isBlank(logoRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPLOAD_CUSTOMIZATION_PROFILE_NOT_FOUND), HttpServletResponse.SC_FORBIDDEN);
    }


    /**
     * Method used to validate null and blanks in
     * update organization servlet request
     * @param logoRequestEntity represents {@link LogoRequestEntity}
     * @param contentDistributionMsgConfigService represents
     * {@link ContentDistributionMsgConfigService}
     * @throws CartServletException when any validation fails
     */
    public static void validateUpdateOrganizationRequest(LogoRequestEntity logoRequestEntity,ContentDistributionMsgConfigService contentDistributionMsgConfigService) throws CartServletException {
        if(StringUtils.isBlank(logoRequestEntity.getCustomizationName()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPLOAD_CUSTOMIZATION_BAD_REQUEST), HttpServletResponse.SC_BAD_REQUEST);
        else if(StringUtils.isBlank(logoRequestEntity.getAuthToken()))
            throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPLOAD_CUSTOMIZATION_PROFILE_NOT_FOUND), HttpServletResponse.SC_FORBIDDEN);
    }

    /**
     * method that parses the clientResponse data and returns a ResponseEntity object.
     * @param data
     * @return
     */
    public static ResponseEntity<String> parseResponseEntity(String data) {
        return new Gson().fromJson(data, ResponseEntity.class);
    }

}
