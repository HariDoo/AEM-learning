package com.novo.core.framework.site.core.models;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.inject.Named;

/**
 * Model to map fields for publish content model
 * <b>Education Center</b> project implementation
 *
 * @version 1.0
 * @since 1.0
 */
@Model(adaptables = Resource.class , defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class PublishContentModel {

    @ValueMapValue
    @Named(value = "jcr:title")
    private String title;

    @ValueMapValue
    @Named(value = "rollupMedia")
    private String assetType;

    @ValueMapValue
    @Named(value = "thumbnailImage")
    private String thumbnail;

    private String path = StringUtils.EMPTY;
    private int order = 0;

    public String getTitle() {
        return title;
    }

    public String getAssetType() {
        return assetType;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getThumbnail() {
        return thumbnail;
    }
}
