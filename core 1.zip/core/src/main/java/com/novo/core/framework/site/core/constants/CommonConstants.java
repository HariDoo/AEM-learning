package com.novo.core.framework.site.core.constants;

/**
 * Constants class
 *
 * @version 1.0
 * @since 1.0
 */
public class CommonConstants {
    public static final String PAGE = "Page";
    public static final String VIDEO = "Video";
    public static final String ASSET = "Asset";
    public static final String DATA = "data";

    private CommonConstants() {
        throw new IllegalStateException("Constants class");
    }

    public static final String UTF_8_ENCODING = "UTF-8";
    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String API_KEY = "ApiKey";
    public static final String AUTHORIZATION = "Authorization";
    public static final String ID = "id";
    public static final String TOKEN_STR= "Token ";
    public static final String CART_CONTENT = "cartContent";

    /**
     * This constant used for represents the operationalTimes field
     */
    public static final String OPERATIONAL_TIMES = "operationalTimes";

    /**
     * This constant used for represents the organizationDetails field
     */
    public static final String ORGANIZATION_DETAILS = "organizationDetails";
    public static final String COLON_CHAR = ":";
}
