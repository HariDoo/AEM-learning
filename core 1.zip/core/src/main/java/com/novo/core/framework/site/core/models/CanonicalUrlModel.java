package com.novo.core.framework.site.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;

@Model(adaptables = SlingHttpServletRequest.class)
public class CanonicalUrlModel {

    @Inject
    private Page currentPage;

    @Inject
    @Optional
    @Via("resource")
    private String canonicalUrl;

    @SlingObject
    private ResourceResolver resourceResolver;

    @PostConstruct
    protected void init() {
        if (canonicalUrl == null || canonicalUrl.isEmpty()) {
            try{
                Externalizer externalizer = resourceResolver.adaptTo(Externalizer.class);
                String URL = externalizer.publishLink(resourceResolver, currentPage.getPath()) + ".html";

                URL = URL.replace("http://", "https://");
                URL = URL.replace(".com/home.html", ".com/");

                canonicalUrl = URL;
            }
            catch (Exception e){

            }
        }
    }

    public String getCanonicalUrl() {
        return canonicalUrl;
    }

}
