package com.novo.core.framework.site.core.constants;

import com.novo.core.framework.site.core.entity.ApiRequestEnum;
import com.novo.core.framework.site.core.entity.ApiResponseEnum;

/**
 * This class contains constant strings for API requests and responses.
 */
public class MessageConstant {

    private MessageConstant() {
        // empty constructor body
    }

    /**
     * This constant represents the authentication token for creating a cart.
     */
    public static final String POST_CART_AUTH_TOKEN_CONST = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_AUTH_TOKEN);

    /**
     * This constant represents the disease type for creating a cart.
     */
    public static final String POST_CART_DISEASE_TYPE_CONST = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_DISEASE_TYPE);

    /**
     * This constant represents an empty cart name for creating a cart.
     */
    public static final String POST_CART_EMPTY_CART_NAME = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.EMPTY_CART_NAME);
    /**
     * This constant represents an invalid cart name for creating a cart.
     */
    public static final String POST_CART_INVALID_CART_NAME = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_CART_NAME);

    /**
     * This constant represents the maximum limit reached for creating a cart.
     */
    public static final String POST_CART_MAX_LIMIT_REACH = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MAX_LIMIT_REACH);

    /**
     * This constant represents a user ID not found for creating a cart.
     */
    public static final String POST_CART_USERID_NOT_FOUND = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * This constant represents a broken microservice for creating a cart.
     */
    public static final String POST_CART_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * This constant represents an internal server error for creating a cart.
     */
    public static final String POST_CART_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * This constant represents an error response when attempting
     * to create a cart and the request is malformed.
     */
    public static final String POST_CART_BAD_REQUEST = String.valueOf(ApiRequestEnum.CREATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.BAD_REQUEST);

    /**
     * Represents an error response when attempting to update a
     * cart and the server encounters an internal error.
     */
    public static final String PUT_CART_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Represents an error response when attempting to update
     * a cart and the microservice is broken.
     */
    public static final String PUT_CART_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Represents an error response when attempting to update
     * a cart and the user ID is not found.
     */
    public static final String PUT_CART_USERID_NOT_FOUND = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Represents an error response when attempting to update
     * a cart and the organization ID is missing.
     */
    public static final String PUT_CART_ORGANIZATION_ID_MISSING = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.EMPTY_ORGANIZATION_ID);

    /**
     * This constant is represents an error response when
     * attempting to update a cart and the authToken is invalid.
     */
    public static final String PUT_CART_AUTH_TOKEN_CONST = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_AUTH_TOKEN);

    /**
     * This constant is represents an error response when
     * attempting to update a cart and the cartName is empty.
     */
    public static final String PUT_CART_EMPTY_CART_NAME = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.EMPTY_CART_NAME);
    /**
     * Indicates that the request to update the cart failed
     * because the cart name is invalid.
     */
    public static final String PUT_CART_INVALID_CART_NAME = String.valueOf(ApiRequestEnum.UPDATE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_CART_NAME);

    /**
     * Indicates that the request to get the cart failed
     * because the authentication token is invalid.
     */
    public static final String GET_CART_INVALID_AUTH_TOKEN = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_AUTH_TOKEN);

    /**
     * Indicates that the request to get the cart
     * failed because the disease type is invalid.
     */
    public static final String GET_CART_INVALID_DISEASE_TYPE = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_DISEASE_TYPE);

    /**
     * Indicates that the request to get the cart
     * failed because the user ID is not found.
     */
    public static final String GET_CART_USERID_NOT_FOUND = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Indicates that the request to get the cart
     * failed because the microservice is broken.
     */
    public static final String GET_CART_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Indicates that the request to get the cart
     * failed because of an internal server error.
     */
    public static final String GET_CART_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Indicates that the request to get the
     * cart failed because of a bad request.
     */
    public static final String GET_CART_BAD_REQUEST = String.valueOf(ApiRequestEnum.GET_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.BAD_REQUEST);

    /**
     * Indicates that the request to delete the cart
     * failed because the cart ID is invalid.
     */
    public static final String DELETE_CART_INVALID_CART_ID = String.valueOf(ApiRequestEnum.DELETE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_CART_ID);

    /**
     * Indicates that the request to delete the cart
     * failed because the microservice is broken.
     */
    public static final String DELETE_CART_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.DELETE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Indicates that the request to delete the cart failed
     * because of an internal server error.
     */
    public static final String DELETE_CART_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.DELETE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Indicates that the request to delete the cart failed
     * because of a bad request.
     */
    public static final String DELETE_CART_BAD_REQUEST = String.valueOf(ApiRequestEnum.DELETE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.BAD_REQUEST);

    /**
     * Indicates that the request to delete the cart failed
     * because the authentication token is invalid.
     */
    public static final String DELETE_CART_INVALID_AUTH_TOKEN = String.valueOf(ApiRequestEnum.DELETE_CART) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_AUTH_TOKEN);

    /**
     * Indicates that the request to get cart content failed
     * because the profile is not found.
     */
    public static final String GET_CART_CONTENT_PROFILE_NOT_FOUND = String.valueOf(ApiRequestEnum.GET_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Used when the resolver is not found while
     * getting the cart content.
     */
    public static final String GET_CART_CONTENT_RESOLVER_NOT_FOUND = String.valueOf(ApiRequestEnum.GET_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.RESOLVER_NOT_FOUND);

    /**
     * Used when the microservice is broken while
     * getting the cart content.
     */
    public static final String GET_CART_CONTENT_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.GET_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Used when an internal server error occurs while
     * getting the cart content.
     */
    public static final String GET_CART_CONTENT_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.GET_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Used when the user profile is not found while
     * creating cart content.
     */

    public static final String CREATE_CART_CONTENT_PROFILE_NOT_FOUND = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Used when an internal server error occurs while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Used when the microservice is broken while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Used when the disease type is invalid while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_INVALID_DISEASE_TYPE = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_DISEASE_TYPE);

    /**
     * Used when the content is invalid while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_INVALID_CONTENT = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_DATA);

    /**
     * Used when the request is bad while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_BAD_REQUEST = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.BAD_REQUEST);

    /**
     * Used when the resolver is null while
     * creating cart content.
     */
    public static final String CREATE_CART_CONTENT_NULL_RESOLVER = String.valueOf(ApiRequestEnum.CREATE_CART_CONTENT) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.RESOLVER_NOT_FOUND);

    /**
     * Used when the request is bad while
     * uploading customization.
     */
    public static final String UPLOAD_CUSTOMIZATION_BAD_REQUEST = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.CUSTOMIZATION_NAME_NOT_FOUND);

    /**
     * Used when the user profile is not found while
     * uploading customization.
     */
    public static final String UPLOAD_CUSTOMIZATION_PROFILE_NOT_FOUND = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Used when the file size is exceeded while
     * uploading customization.
     */
    public static final String UPLOAD_CUSTOMIZATION_FILE_SIZE_EXCEED = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FILE_SIZE_EXCEED);

    /**
     * Used when the file format is invalid while
     * uploading customization.
     */
    public static final String UPLOAD_CUSTOMIZATION_FILE_FORMAT_INVALID = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FILE_FORMAT_INVALID);

    /**
     * Used when the file name is invalid while
     * uploading customization.
     */
    public static final String UPLOAD_CUSTOMIZATION_INVALID_FILE_NAME = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_FILE_NAME);

    /**
     * Error message when image file is invalid
     * during customization upload.
     */
    public static final String UPLOAD_CUSTOMIZATION_INVALID_IMAGE_FILE = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_IMAGE_FILE);

    /**
     * Error message when redirect URL is
     * invalid during logo upload.
     */
    public static final String UPLOAD_LOGO_INVALID_REDIRECT_URL = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_REDIRECT_URL);

    /**
     * Error message when there is an internal
     * server error during customization upload.
     */
    public static final String UPLOAD_CUSTOMIZATION_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Error message when there is a servlet error
     * during customization upload.
     */
    public static final String UPLOAD_CUSTOMIZATION_SERVLET_ERROR = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Error message when the customization microservice is broken.
     */
    public static final String UPLOAD_CUSTOMIZATION_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.CREATE_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Error message when the user ID is not found
     * during customization retrieval.
     */
    public static final String GET_CUSTOMIZATION_USERID_NOT_FOUND = String.valueOf(ApiRequestEnum.GET_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Error message when there is an internal server
     * error during customization retrieval.
     */
    public static final String GET_CUSTOMIZATION_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.GET_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Error message when the customization microservice
     * is broken during retrieval.
     */
    public static final String GET_CUSTOMIZATION_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.GET_CUSTOMIZATION) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Error message when the user ID is not found during
     * organization details retrieval.
     */
    public static final String GET_ORGANIZATION_DETAIL_USERID_NOT_FOUND = String.valueOf(ApiRequestEnum.ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.FORBIDDEN);

    /**
     * Error message when the organization details microservice
     * is broken during retrieval.
     */
    public static final String GET_ORGANIZATION_DETAIL_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * Error message when there is an internal server error
     * during organization details retrieval.
     */
    public static final String GET_ORGANIZATION_DETAIL_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Error message when there is an internal server error
     * during organization details update.
     */
    public static final String UPDATE_ORGANIZATION_INTERNAL_SERVER_ERROR = String.valueOf(ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INTERNAL_SERVER_ERROR);

    /**
     * Error message when the organization details microservice
     * is broken during update
     */
    public static final String UPDATE_ORGANIZATION_MICROSERVICE_BROKEN = String.valueOf(ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.MICROSERVICE_BROKEN);

    /**
     * An error message indicating that the profile for the specified user
     * ID could not be found when attempting to update organization details.
     */
    public static final String UPDATE_ORGANIZATION_PROFILE_NOT_FOUND = String.valueOf(ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS) + CommonConstants.COLON_CHAR + String.valueOf(ApiResponseEnum.INVALID_USER_ID);

}
