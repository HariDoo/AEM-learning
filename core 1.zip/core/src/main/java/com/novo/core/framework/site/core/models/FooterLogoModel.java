package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

@Model(adaptables = Resource.class)
public class FooterLogoModel {

    @ValueMapValue(name = PROPERTY_RESOURCE_TYPE, injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "No resourceType")
    protected String resourceType;

    @Inject
    @Optional
    private List<Resource> logoList;

    public List<FooterLogoList> footer = new ArrayList<>();

    @PostConstruct
    protected void init() {
    	if (logoList != null) {
	        if (!logoList.isEmpty()) {
	            for (Resource resource : logoList) {
	                FooterLogoList navigationItem = resource.adaptTo(FooterLogoList.class);
	                footer.add(navigationItem);
	            }
	        }
    	}
    }

    public boolean getIsEmpty() {
        return footer.isEmpty();
    }

    public List<FooterLogoList> getFooter() {
        return footer;
    } 

    public void setFooter(List<FooterLogoList> footer) {
        this.footer = footer;
    }

}
