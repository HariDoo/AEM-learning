package com.novo.core.framework.site.core.services.impl;

import com.novo.core.framework.site.core.services.LogoConfigService;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Impl to handle logo functionality that 
 * implements {@link LogoConfigService}
 *
 * check the component and designate annotations for defining service
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = LogoConfigService.class, immediate = true)
@Designate(ocd = LogoConfigServiceImpl.LogoServiceUrlConfiguration.class)
public class LogoConfigServiceImpl implements LogoConfigService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LogoConfigServiceImpl.class);

    private int fileSize = 0;
    private String[] fileFormat = new String[5];

    @Activate
    @Modified
    protected void activateOrModified(LogoServiceUrlConfiguration config) {
        fileSize = config.fileSizeConfig();
        fileFormat = config.fileFormatListConfig();

        LOGGER.debug("LogoConfigService Activate()"
                + " contentdistribution logo file size config : {}", fileSize);
        LOGGER.debug("LogoConfigService Activate() "
                + "contentdistribution logo file formats config: {}", fileFormat);
    }

    @Override
    public int getFileSize() {
        return fileSize;
    }

    @Override
    public String[] getFileFormat() {
        return fileFormat;
    }

    @ObjectClassDefinition(name = "Content Distribution Core Logo Configuration")
    public @interface LogoServiceUrlConfiguration {

        /**
         * Attribute definition for file size
         *
         * @return
         */
        @AttributeDefinition(
                name = "Logo file size",
                description = "Enter file size should be in MB(MegaBytes)"
        )
        int fileSizeConfig() default 0;

        /**
         * Attribute definition for file formats
         *
         * @return
         */
        @AttributeDefinition(
                name = "Logo file formats",
                description = "Enter file format ex(png,jpeg,jpg)"
        )
        String[] fileFormatListConfig() default StringUtils.EMPTY;
    }
}
