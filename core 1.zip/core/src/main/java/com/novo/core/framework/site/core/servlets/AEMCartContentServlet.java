package com.novo.core.framework.site.core.servlets;

import com.day.cq.commons.jcr.JcrConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.*;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;


/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * <p>
 * It exposes two methods mainly
 * POST and GET method that can be used to get the cart content
 * or post urls to .NET API further
 * <p>
 * check the component annotations to understand the API signatures
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=cq/Page",
        "sling.servlet.selectors=cartContentApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.extensions=json"})
public class AEMCartContentServlet extends SlingAllMethodsServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(AEMCartContentServlet.class);
    private static final String UNIQUE_KEY = "?uniqueKey=";
    /**
     * This regex pattern matches any forward
     * slash characters in the host string
     */
    private static final String REGEX_HOST = "/+";
    /**
     * This constant represents the ID of the user's cart.
     */
    public static final String CART_ID = "cartId";
    /**
     * This constant is used to represent html extension.
     */
    public static final String HTML = ".html";
    /**
     * This constant is used to represent publishPagePath string.
     */
    public static final String PUBLISH_PAGE_PATH = "publishPagePath";

    @Reference
    private transient ResourceResolverFactory resourceResolverFactory;

    @Reference
    private transient CartService cartService;

    @Reference
    private transient MailSenderService mailSenderService;

    @Reference
    private transient RestService restService;

    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    @Reference
    private transient ServletAPIUrlsService servletAPIUrlsService;

    /**
     * POST method that posts urls to the .NET API
     *
     * @param request  {@link SaveCartContentRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doPost(final SlingHttpServletRequest request, final SlingHttpServletResponse response) {
        String publishPagePath = StringUtils.EMPTY;
        try {
            final Resource resource = request.getResource().getChild(JcrConstants.JCR_CONTENT);
            if(Objects.nonNull(resource)) {
                final ValueMap valueMap = resource.getValueMap();
                publishPagePath = valueMap.get(PUBLISH_PAGE_PATH, String.class);
            }
            SaveCartContentRequestEntity saveCartContentRequestEntity = CartUtils.getObjectFromRequest(request, SaveCartContentRequestEntity.class);
            ClientResponse clientResponse;

            CartUtils.validateRequestCreateCartContent(saveCartContentRequestEntity, contentDistributionMsgConfigService);
            clientResponse = cartService.getUserProfile(saveCartContentRequestEntity.getAuthToken());
            Profile profile = new Gson().fromJson(clientResponse.getData(), Profile.class);

            if (profile == null) {
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Not able to get the successful profile object created");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_PROFILE_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }

            if (profile.getId() == null) {
                final ResponseEntity<String> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Not able to get the profile Id");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_PROFILE_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            saveCartContentRequestEntity.setUserId(Long.valueOf(profile.getId()));
            clientResponse = cartService.createCartContent(saveCartContentRequestEntity);

            if (clientResponse != null && StringUtils.isNotBlank(clientResponse.getData())) {
                ObjectMapper objectMapper = new ObjectMapper();
                ResponseEntity<String> responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                String message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                if (clientResponse.getStatusCode() != HttpServletResponse.SC_OK) {
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                    return;
                }
                String host = String.valueOf(request.getRequestURL()).split(REGEX_HOST)[1];
                final String pubUrl = getConfigUrl(host ,CartUtils.getKeyFromPostCartContentResponse(clientResponse), publishPagePath);
                profile.setPublishUrl(pubUrl);
                // Mailer Template Service
                if(mailSenderService.isMailerEnabledFlag())
                    mailSenderService.sendMailWithEmailTemplate(profile,host, CartUtils.getOrganizationDetailsResponse(clientResponse));
                responseEntity.setData(pubUrl);
                responseEntity.setMessage(message);
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            } else {
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_INTERNAL_SERVER_ERROR));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                LOGGER.debug("Content Not Saved :: AEMCartContentServlet() :: doPost {}", "Content Not Saved");
            }
        } catch (JSONException e ) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("JSONException:: AEMCartContentServlet() :: doPost {0}", e);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (IOException ioe){
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException :: AEMCartContentServlet() :: doPost {0}", ioe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (CartServletException ce) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("Error getting request parameters", ce);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        }
    }

    /**
     * GET method that get urls from the .NET API
     *
     * @param request  {@link SaveCartContentRequestEntity}
     * @param response {@link ResponseEntity }
     */
    @Override
    protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response) {

        // step to map request with the desired bean
        SaveCartContentRequestEntity saveCartContentRequestEntity;
        saveCartContentRequestEntity = CartUtils.getSaveCartContentRequestEntityFromRequest(request);
        ClientResponse clientResponse;

        // Getting the resolver using service user that is configurable using the service username in config
        try(ResourceResolver resourceResolver = CartUtils.getResourceResolver(resourceResolverFactory, restService.getServiceUser())) {
            final Integer cartId = Integer.valueOf(request.getParameter(CART_ID));
            // validating the request
            CartUtils.validateRequestGetCartContent(saveCartContentRequestEntity, contentDistributionMsgConfigService);
            saveCartContentRequestEntity.setCartId(cartId);
            // getting the user profile from novo API call
            clientResponse = cartService.getUserProfile(saveCartContentRequestEntity.getAuthToken());
            long userId = CartUtils.getIdFromUserObj(clientResponse);

            if (userId == 0) {
                ResponseEntity<Object> responseEntity = new ResponseEntity<>();
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_PROFILE_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            if (resourceResolver == null) {
                ResponseEntity<Object> responseEntity = new ResponseEntity<>();
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_RESOLVER_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                return;
            }

            saveCartContentRequestEntity.setUserId(userId);
            // Getting cart content from .NET API call
            clientResponse = cartService.getCartContent(saveCartContentRequestEntity);
            if (clientResponse != null && StringUtils.isNotBlank(clientResponse.getData())) {
                ResponseEntity<Object> responseEntity = new ResponseEntity<>();
                ObjectMapper objectMapper = new ObjectMapper();
                responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                String message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                if (clientResponse.getStatusCode() != HttpServletResponse.SC_OK) {
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                    return;
                }
                responseEntity.setData(CartUtils.responseEntityForGetCartContent(clientResponse, resourceResolver, true));
                responseEntity.setSuccess(true);
                responseEntity.setMessage(message);

                // Mapping the urls with AEM resource to fetch the props out of them
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));

            } else {
                ResponseEntity<Object> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Cart Content is null :: AEMCartContentServlet() :: doGet {}", "Content Not Found");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_MICROSERVICE_BROKEN));
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            }
        } catch (CartServletException ce) {
            ResponseEntity<Object> responseEntity = new ResponseEntity<>();
            LOGGER.error("Error getting request parameters", ce);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        } catch (JSONException e) {
            ResponseEntity<Object> responseEntity = new ResponseEntity<>();
            LOGGER.error("JSONException:: AEMCartContentServlet() :: doGet {0}", e);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch(IOException ioe){
            ResponseEntity<Object> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException:: AEMCartContentServlet() :: doGet {0}", ioe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    private String getConfigUrl(String host,String uniqueKey, String publishPagePath){
        return host.concat(publishPagePath+ HTML +UNIQUE_KEY+uniqueKey);
    }
}
