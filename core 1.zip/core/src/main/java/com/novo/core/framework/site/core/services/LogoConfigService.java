package com.novo.core.framework.site.core.services;

/**
 * Interface to be used for Logo Config Service
 */
public interface LogoConfigService {

    /**
     * Method to get the authored file size 
     * using osgi config
     *
     * @return size in the int format
     */
    int getFileSize();

    /**
     * Method to fetch all the allowed formats for 
     * logo extensions that are allowed
     *
     * @return the array of accepted file formats
     */
    String[] getFileFormat();
}
