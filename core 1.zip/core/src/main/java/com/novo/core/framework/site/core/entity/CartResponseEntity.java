package com.novo.core.framework.site.core.entity;

import java.util.List;

/**
 * Represents CartResponseEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class CartResponseEntity {
    private List<CartEntity> cartContent;

    public List<CartEntity> getCartContent() {
        return cartContent;
    }

    public void setCartContent(List<CartEntity> cartContent) {
        this.cartContent = cartContent;
    }
}
