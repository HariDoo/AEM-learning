package com.novo.core.framework.site.core.services;

import com.novo.core.framework.site.core.entity.*;
import org.apache.sling.api.SlingHttpServletResponse;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;

import java.io.IOException;

/**
 * Interface defining methods for interacting with the
 * CartService in .Net api layer
 */
public interface CartService {

    /**
     * method is used to fetch the cart Details for a specified user.
     * @param response
     * @param cartRequestEntity
     * @param contentDistributionMsgConfigService
     * @param cartService
     */
    void getCartDetails(@NotNull SlingHttpServletResponse response,
                        CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService,
                        CartService cartService, String publishPagePath);

    /**
     * Method to create cart in .Net api layer
     *
     * @param cartRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse createCart(CartRequestEntity cartRequestEntity) throws JSONException, IOException;

    /**
     * Method to update cart in .Net api layer
     *
     * @param cartRequestEntity
     * @return
     * @throws IOException
     */
    ClientResponse updateCart(CartRequestEntity cartRequestEntity) throws  IOException;

    /**
     * Method to get carts from .Net api layer
     *
     * @param cartRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse getCart(CartRequestEntity cartRequestEntity) throws JSONException, IOException;

    /**
     * Method to get customization from .Net api layer
     *
     * @param cartRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    ClientResponse getCustomization(CartRequestEntity cartRequestEntity) throws  IOException;


    /**
     * Method to get customization from .Net api layer
     *
     * @param cartRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    ClientResponse getOrganizationDetails(CartRequestEntity cartRequestEntity) throws  IOException;

    /**
     * Method to get cart content from .Net api layer
     *
     * @param cartContentRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse getCartContent(SaveCartContentRequestEntity cartContentRequestEntity) throws JSONException, IOException;

    /**
     * Method to create cart content in .Net api layer
     *
     * @param cartContentRequestEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse createCartContent(SaveCartContentRequestEntity cartContentRequestEntity) throws JSONException, IOException;

    /**
     * Method to Delete cart  in .Net api layer
     *
     * @param cartEntity
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse deleteCart(CartEntity cartEntity) throws JSONException, IOException;

    /**
     * Method to upload logo
     *
     * @param data
     * @return
     * @throws JSONException
     * @throws IOException
     */
    public ClientResponse uploadLogo(Object data) throws JSONException, IOException;

    /**
     * Method to get User Profile
     *
     * @param authToken
     * @return
     * @throws IOException
     */
    public ClientResponse getUserProfile(String authToken) throws IOException;

    /**
     * Method to get Updated Organization
     *
     * @param data
     * @return
     * @throws IOException
     */
    public ClientResponse updateOrganization(Object data) throws JSONException, IOException;
}
