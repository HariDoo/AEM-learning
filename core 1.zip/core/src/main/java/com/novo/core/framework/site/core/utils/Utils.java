package com.novo.core.framework.site.core.utils;

import org.apache.commons.lang3.StringUtils;

import org.apache.sling.api.SlingHttpServletRequest;
import org.jetbrains.annotations.NotNull;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import java.util.Objects;

public class Utils {

    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    public static final String HTML_EXTENSION = ".html";
    public static final String SLASH = "/";
    public static final String HASH = "#";
    public static final String PDF =".pdf";
    private static final String PARENT_REGEX = "%s/";

    private Utils() {
    }

    /**
     * If the provided {@code path} identifies a {@link Page}, this method will generate the correct URL for the page. Otherwise the
     * original {@code String} is returned.
     *
     * @param request     the current request, used to determine the server's context path
     * @param pageManager the page manager
     * @param path        the page path
     * @return the URL of the page identified by the provided {@code path}, or the original {@code path} if this doesn't identify a
     * {@link Page}
     */
    @NotNull
    public static String getURL(@NotNull SlingHttpServletRequest request, @NotNull PageManager pageManager, @NotNull String path) {
        Page page = pageManager.getPage(path);
        if (page != null) {
            return getURL(request, page);
        }
        return path;
    }

    /**
     * Given a {@link Page}, this method returns the correct URL, taking into account that the provided {@code page} might provide a
     * vanity URL.
     *
     * @param request the current request, used to determine the server's context path
     * @param page    the page
     * @return the URL of the page identified by the provided {@code path}, or the original {@code path} if this doesn't identify a
     * {@link Page}
     */
    @NotNull
    public static String getURL(@NotNull SlingHttpServletRequest request, @NotNull Page page) {
        String vanityURL = page.getVanityUrl();
        return StringUtils.isEmpty(vanityURL) ? request.getContextPath() + page.getPath() + ".html" : request.getContextPath() + vanityURL;
    }
    
    /**
     * Checks if the page is active page.
     *
     * @param redirectpath the redirectpath
     * @param currentPage the current page
     * @param childPage the child page
     * @param currentActivePage the current active page
     * @return the boolean
     */
    @NotNull
    public static Boolean isActivePage(String redirectpath, Page currentPage, Page childPage, String currentActivePage){
    	Boolean active = false;
        
        if(Objects.nonNull(redirectpath)) {
        active = redirectpath.equals(currentPage.getPath());
        }
        else {
          active = String.format(PARENT_REGEX, currentActivePage).contains(String.format(PARENT_REGEX, childPage.getPath()));
        }
        return active;
    }

    public enum Heading {

        H1("h1"),
        H2("h2"),
        H3("h3"),
        H4("h4"),
        H5("h5"),
        H6("h6");

        private String element;

        Heading(String element) {
            this.element = element;
        }

        public static Heading getHeading(String value) {
            for (Heading heading : values()) {
                if (StringUtils.equalsIgnoreCase(heading.element, value)) {
                    return heading;
                }
            }
            return null;
        }

        public String getElement() {
            return element;
        }
        
    }

	


}