package com.novo.core.framework.site.core.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.ApiRequestEnum;
import com.novo.core.framework.site.core.entity.CartRequestEntity;
import com.novo.core.framework.site.core.entity.ClientResponse;
import com.novo.core.framework.site.core.entity.ResponseEntity;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.RestService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component(service = {Servlet.class}, property = {
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.resourceTypes=novo-core-framework/site/components/content/educationcenter/carts",
        "sling.servlet.selectors=updateCartApi",
        "sling.servlet.extensions=json"})
public class UpdateCartServlet extends SlingAllMethodsServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateCartServlet.class);

    @Reference
    private transient CartService cartService;

    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    @Override
    protected void doPost(@NotNull SlingHttpServletRequest request, @NotNull SlingHttpServletResponse response) {
        try {
            final CartRequestEntity cartRequestEntity;
            cartRequestEntity= CartUtils.getObjectFromRequest(request, CartRequestEntity.class);
            ClientResponse clientResponse;
            clientResponse = cartService.getUserProfile(cartRequestEntity.getAuthToken());

            final long userId  = CartUtils.getIdFromUserObj(clientResponse);

            if (userId == 0) {
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Not able to get the successful profile object created");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.PUT_CART_USERID_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            cartRequestEntity.setUserId(userId);
            clientResponse = cartService.updateCart(cartRequestEntity);
            if(clientResponse!=null && StringUtils.isNotBlank(clientResponse.getData())){
                final ObjectMapper objectMapper = new ObjectMapper();
                ResponseEntity<String> responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                final String message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.UPDATE_CART + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                responseEntity.setMessage(message);
                CartUtils.sendAPIResponse(response, responseEntity, clientResponse.getStatusCode());
            }else{
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Cart is null :: CartAPIServlet() :: doPut {}", "Cart Not Found");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.PUT_CART_INTERNAL_SERVER_ERROR));
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            }
        } catch (IOException ioException) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException  :: CartAPIServlet() :: doPut {0}", ioException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.PUT_CART_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (JSONException ioJSONe) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error(" JSONException :: CartAPIServlet() :: doPut {0}", ioJSONe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.PUT_CART_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
