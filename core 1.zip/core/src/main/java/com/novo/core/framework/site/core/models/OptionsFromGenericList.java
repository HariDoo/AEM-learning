package com.novo.core.framework.site.core.models;

import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class OptionsFromGenericList {
    private static final String DEFAULT_US_STATES_LIST_PATH = "/etc/acs-commons/lists/novo/us-states";
    @SlingObject
    private ResourceResolver resourceResolver;

    @ValueMapValue
    private String genericListPath;

    private Map<String, String> optionsMap = new LinkedHashMap<>();
    @PostConstruct
    protected void init() {
        String listPath = Optional.ofNullable(genericListPath)
            .filter(StringUtils::isNotBlank)
            .orElse(DEFAULT_US_STATES_LIST_PATH)
            + "/jcr:content/list";
        Optional.ofNullable(resourceResolver.getResource(listPath))
            .map(Resource::listChildren)
            .orElse(IteratorUtils.emptyIterator())
            .forEachRemaining(item -> optionsMap.put(item.getValueMap().get("value", String.class),
                item.getValueMap().get("jcr:title", String.class)));
    }

    public Map<String, String> getOptionsMap() {
      return optionsMap;
    }
}
