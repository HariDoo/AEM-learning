package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.Page;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Model(adaptables = SlingHttpServletRequest.class)
public class QueryParamModel {
    String cookieName = "qsStore";
   
    @PostConstruct
    protected void init() {
        
    }

    public QueryParamModel() {

    }

    public ServletResponse setParams(ServletRequest request, ServletResponse resp, Map<String,String> params){
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse response = (HttpServletResponse) resp;
        String oldParams = getParams(req);
        String newParams = "";
        if (!oldParams.isEmpty()){
            newParams = mergeParams(oldParams, params);
        }
        else{
            Gson gson = new Gson();
            newParams = gson.toJson(params);
        }
        //Cookie c = new Cookie(cookieName, newParams);
        try{
            Cookie c = new Cookie(cookieName, URLEncoder.encode(newParams, "UTF-8"));
            c.setPath("/");
            c.setMaxAge(86400);
            response.addCookie(c);
        }
        catch(Exception e){

        }
        return response;
    }

    public String mergeParams(String oldParams, Map<String,String> params){
        Gson gson = new Gson();
        Map old = gson.fromJson(oldParams, Map.class);

        Iterator it = params.entrySet().iterator();
        while (it.hasNext()){
            Map.Entry m = (Map.Entry) it.next();
            old.put(m.getKey(), m.getValue());
        }
        return gson.toJson(old);
    }

    public String getParam(HttpServletRequest request, String key){
        String params = getParams(request);

        Gson gson = new Gson();
        Map map = gson.fromJson(params, Map.class);
        try{
            String str = map.get(key).toString();        
            return str;
        }
        catch(Exception e){

        }
        return "";
    }

    public String getParams(HttpServletRequest req){
        Cookie[] cookies = req.getCookies();
        String cookieValue = "";
        if (cookies != null) {
            try{
                for (int i = 0; i < cookies.length; i++) {
                    if (cookies[i].getName().equals(cookieName)) {
                        //cookieValue = cookies[i].getValue();
                        cookieValue = URLDecoder.decode(cookies[i].getValue(), "UTF-8");
                        break;
                    }
                }
            }
            catch (Exception e){

            }
        }
        return cookieValue;
    }

}
