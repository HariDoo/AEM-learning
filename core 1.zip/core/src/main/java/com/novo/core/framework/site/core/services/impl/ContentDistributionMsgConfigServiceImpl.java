package com.novo.core.framework.site.core.services.impl;

import com.novo.core.framework.site.core.entity.ApiMessage;
import com.novo.core.framework.site.core.entity.ApiRequestResponseMap;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

import java.util.HashMap;
import java.util.Map;

/**
 * Message configuration service impl to handle API messages for
 * implements {@link ContentDistributionMsgConfigService}
 *
 * check the component and designate annotations for defining service
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = ContentDistributionMsgConfigService.class)
@Designate(ocd=ContentDistributionMsgConfigServiceImpl.ContentDistributionApiMsgConfig.class)
public class ContentDistributionMsgConfigServiceImpl implements ContentDistributionMsgConfigService{


    private Map<String , String> getApiMessageMap = new HashMap<>();

    /**
     * This method is called when the component is activated or modified,
     * and sets up the API messages for the component.
     * class to retrieve a map of API messages.
     * @param config
     */
    @Activate
    @Modified
    protected void activatedOrModified(final ContentDistributionApiMsgConfig config){
        final ApiMessage apiMessage = ApiRequestResponseMap.setMessages(config);
        getApiMessageMap = ApiRequestResponseMap.getMessageMap(apiMessage);
    }

    @Override
    public String getApiResponseMessage(String resReqType) {
        return getApiMessageMap.get(resReqType);
    }

    @ObjectClassDefinition(name = "Content Distribution API Messages Config")
    public @interface ContentDistributionApiMsgConfig {

        // GET cart config messages start

        /**
         * Attribute definition for GET cart success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart success message",
                description = "Get cart success message for status code 200"
        )
        String getCartApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart bad request message",
                description = "Get cart bad request message for status code 400"
        )
        String getCartApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart forbidden message",
                description = "Get cart forbidden message for status code 403"
        )
        String getCartApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart internal server error message",
                description = "Get cart internal server error message for status code 500"
        )
        String getCartApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart Invalid Auth Token message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Invalid Auth Token",
                description = "Get cart invalid auth token error message for status code 400"
        )
        String getCartApiInvalidAuthToken() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart For Broken Microservice message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Broken Microservice",
                description = "Get cart broken microservice error message for status code 500"
        )
        String getCartApiBrokenMicroservice() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart For User Invalid Disease Type message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart For User Invalid Disease Type",
                description = "Get cart for user invalid disease type error message for status code 400"
        )
        String getCartApiForUserInvalidDiseaseType() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart Broken Sql Connection message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Broken Sql Connection",
                description = "Get cart broken sql connection error message for status code 500"
        )
        String getCartApiBrokenSqlConnection() default StringUtils.EMPTY;

        // GET cart config messages end


        // Get cart content message config starts

        /**
         * Attribute definition for GET cart content success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart content success message",
                description = "Get cart content success message for status code 200"
        )
        String getCartContentApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart content success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart content invalid user ID message",
                description = "Get cart content invalid user ID message for status code 200"
        )
        String getCartContentApiInvalidUserIdConfig() default StringUtils.EMPTY;


        /**
         * Attribute definition for GET cart content bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart content bad request message",
                description = "Get cart content bad request message for status code 400"
        )
        String getCartContentApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart  content forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart content forbidden message",
                description = "Get cart content forbidden message for status code 403"
        )
        String getCartContentApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart content internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get cart content internal server error message",
                description = "Get cart content internal server error message for status code 500"
        )
        String getCartContentApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart Content Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Content Broken Sql Connection",
                description = "Get Cart Content Broken Sql Connection error message for status code 500"
        )
        String getCartContentApiBrokenSqlConnection() default StringUtils.EMPTY;


        /**
         * Attribute definition for GET cart Broken Microservice Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Content Broken Microservice Connection",
                description = "Get cart content broken microservice connection error message for status code 500"
        )
        String getCartContentApiBrokenMicroserviceConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart content With Invalid Unique Key error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Content Invalid Unique Key",
                description = "Get cart content invalid unique Key error message for status code 400"
        )
        String getCartContentApiInvalidUniqueKey() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart content With Null Resolver error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Content With Null Resolver",
                description = "Get Cart Content With Null Resolver error message for status code 500"
        )
        String getCartContentApiWithNullResolver() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET cart content With No Cart Available error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Content With No Cart Available",
                description = "Get Cart Content with no cart available error message for status code 500"
        )
        String getCartContentApiNotCartAvailable() default StringUtils.EMPTY;

        // Get cart content message config ends


        // Create cart content message config starts

        /**
         * Attribute definition for Create cart content success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create cart content success message",
                description = "Create cart content success message for status code 200"
        )
        String createCartContentApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart content For User Invalid Disease Type message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content For Invalid Disease Type",
                description = "Create Cart Content Invalid Disease Type error message for status code 400"
        )
        String createCartContentApiOfNotCreatedDiseaseType() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart content For User Invalid Content Data message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content For Invalid Content Data",
                description = "Create Cart Content Api Invalid Content Data for status code 400"
        )
        String createCartContentApiInvalidContent() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart content bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content bad request message",
                description = "Create Cart Content bad request message for status code 400"
        )
        String createCartContentApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for CREATE cart content forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content forbidden message",
                description = "Create Cart Content forbidden message for status code 403"
        )
        String createCartContentApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Content internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content internal server error message",
                description = "Create Cart Content internal server error message for status code 500"
        )
        String createCartContentApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Content Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content Broken Sql Connection",
                description = "Create Cart Content Broken Sql Connection error message for status code 500"
        )
        String createCartContentApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart content Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content MicroService Broken  Connection",
                description = "Create cart content microservice broken connection error message for status code 500"
        )
        String createCartContentApiMicroserviceBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Content With Blank Path error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content with Blank Path",
                description = "Create Cart Content with Blank Path error message for status code 400"
        )
        String createCartContentApiBlankPath() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Content With Empty Order error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content Empty Order",
                description = "Create Cart Content Empty Order error message for status code 400"
        )
        String createCartContentApiEmptyOrder() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Content With Null Resolver error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Content With Null Resolver",
                description = "Create Cart Content With Null Resolver error message for status code 500"
        )
        String createCartContentApiWithNullResolver() default StringUtils.EMPTY;
        // Create cart content config message ends

        // Create cart config message starts

        /**
         * Attribute definition for Create cart success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart success message",
                description = "Create Cart success message for status code 200"
        )
        String createCartApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart bad request message",
                description = "Create Cart bad request message for status code 400"
        )
        String createCartApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart forbidden message",
                description = "Create Cart forbidden message for status code 403"
        )
        String createCartApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart internal server error message",
                description = "Create Cart internal server error message for status code 500"
        )
        String createCartApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart invalid authToken
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Invalid Auth Token",
                description = "Create Cart Invalid Auth Token error message for status code 400"
        )
        String createCartApiInvalidAuthToken() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart Broken Microservice
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Broken Microservice",
                description = "Create Cart Broken Microservice error message for status code 500"
        )
        String createCartApiBrokenMicroservice() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart invalid disease type
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Invalid Disease Type",
                description = "Create Cart Invalid Disease Type Message for status message 400 "
        )
        String createCartApiInvalidDiseaseType() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart invalid cart name
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Empty Cart Name",
                description = "Create Cart Empty Cart Name Message for status message 400 "
        )
        String createCartApiEmptyCartName() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart More Than Fifty Char message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart More Than Fifty Char",
                description = "Create Cart More Than Fifty Char error message for status message 400"
        )
        String createCartApiMoreThanFiftyChar() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart Broken Sql Connection message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Broken Sql Connection",
                description = "Create Cart Broken Sql Connection error message for status message 500"
        )
        String createCartApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Cart Max Limit Reach message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create Cart Max Limit Reach",
                description = "Create Cart Max Limit Reach error message for status message 400"
        )
        String createCartApiMaxLimitReach() default StringUtils.EMPTY;

        // Create cart config message ends


        // Delete config message start here

        /**
         * Attribute definition for Delete cart success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart success message",
                description = "Delete Cart success message for status code 200"
        )
        String deleteCartApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart bad request message",
                description = "Delete Cart bad request message for status code 400"
        )
        String deleteCartApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for delete cart forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart forbidden message",
                description = "Delete Cart forbidden message for status code 403"
        )
        String deleteCartApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart internal server error message",
                description = "Delete Cart internal server error message for status code 500"
        )
        String deleteCartApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart not exist error message",
                description = "Delete Cart not exist error message for status code 400"
        )
        String deleteCartApiCartNotExist() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart Broken Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart Broken Connection",
                description = "Delete Cart Broken Connection error message for status code 500"
        )
        String deleteCartApiBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart Broken Sql Connection",
                description = "Delete Cart Broken Sql Connection error message for status message 500"
        )
        String deleteCartApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart Invalid Cart Id error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart Invalid Cart Id",
                description = "Delete Cart Invalid Cart Id error message for status code 400")
        String deleteCartApiInvalidCartId() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete cart Invalid Auth Token error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Delete Cart Invalid Auth Token",
                description = "Delete cart invalid auth token error message for status code 400")
        String deleteCartApiInvalidAuthToken() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization success message",
                description = "Create organization success message for status code 200"
        )
        String uploadLogoApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization bad request message",
                description = "Create organization bad request message for status code 400"
        )
        String uploadLogoApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization forbidden message",
                description = "Create organization forbidden message for status code 403"
        )
        String uploadLogoApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization internal server error message",
                description = "Create organization internal server error message for status code 500"
        )
        String uploadLogoApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for file size exceeded error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization file size exceed message",
                description = "Create organization file size exceed message for status code 400"
        )
        String uploadLogoApiFileSizeExceedMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization file format error message",
                description = "Create organization file format error message for status code 400"
        )
        String uploadLogoApiFileFormatErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Broken Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization  Broken Connection",
                description = "Create organization  Broken Connection error message for status code 500"
        )
        String uploadLogoApiBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Broken Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization already exist",
                description = "Create organization already exist error message for status code 500"
        )
        String uploadLogoApiOrganizationAlreadyExist() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart Broken Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization invalid length for base 64 string",
                description = "Create organization invalid length for base 64 string error message for status code 500"
        )
        String uploadLogoApiInvalidLengthBase64() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization Invalid file error message",
                description = "Create organization Invalid file error message for status code 400"
        )
        String uploadLogoApiInvalidFileNameMessageConfig() default StringUtils.EMPTY;


        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization Invalid Image file error message",
                description = "Create organization Invalid Image file error message for status code 400"
        )
        String uploadLogoApiInvalidImageFileMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization Invalid Redirect Url error message",
                description = "Create organization Invalid Redirect Url error message for status code 400"
        )
        String uploadLogoApiInvalidRedirectUrlMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload logo internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Create organization Invalid User Id error message",
                description = "Create organization User Id error message for status code 400"
        )
        String uploadLogoApiInvalidUserIdMessageConfig() default StringUtils.EMPTY;


        // Get organization detail message config starts

        /**
         * Attribute definition for Get Organization success message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization success message",
                description = "Get Organization success message for status code 200"
        )
        String getOrganizationApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Content bad request message",
                description = "Get Organization bad request message for status code 400"
        )
        String getOrganizationApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Content forbidden message",
                description = "Get Organization forbidden message for status code 403"
        )
        String getOrganizationApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization internal server error message",
                description = "Get Organization internal server error message for status code 500"
        )
        String getOrganizationApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Broken Sql Connection",
                description = "Get Organization Broken Sql Connection error message for status code 500"
        )
        String getOrganizationApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization MicroService Broken  Connection",
                description = "Get Organization microservice broken connection error message for status code 500"
        )
        String getOrganizationApiMicroserviceBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Invalid User ID",
                description = "Get Organization Invalid User ID error message for status code 500"
        )
        String getOrganizationApiInvalidUserConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization success message
         *
         * @return
         */


        //Get Organization Detail
        @AttributeDefinition(
                name = "Get Organization Detail success message",
                description = "Get Organization Detail success message for status code 200"
        )
        String getOrganizationDetailApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail Content bad request message",
                description = "Get Organization Detail bad request message for status code 400"
        )
        String getOrganizationDetailApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail Content forbidden message",
                description = "Get Organization Detail forbidden message for status code 403"
        )
        String getOrganizationDetailApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail internal server error message",
                description = "Get Organization Detail internal server error message for status code 500"
        )
        String getOrganizationDetailApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail Broken Sql Connection",
                description = "Get Organization Detail Broken Sql Connection error message for status code 500"
        )
        String getOrganizationDetailApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail MicroService Broken  Connection",
                description = "Get Organization Detail microservice broken connection error message for status code 500"
        )
        String getOrganizationDetailApiMicroserviceBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Get Organization Detail Resource Not Found",
                description = "Get Organization Detail Resource Not Found error message for status code 500"
        )
        String getOrganizationDetailApiResourceNotFoundConfig() default StringUtils.EMPTY;


        //Update Cart

        @AttributeDefinition(
                name = "Update Cart success message",
                description = "Update Cart success message for status code 200"
        )
        String getUpdateCartApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Cart Content bad request message",
                description = "Update Cart bad request message for status code 400"
        )
        String getUpdateCartApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Cart Content forbidden message",
                description = "Update Cart forbidden message for status code 403"
        )
        String getUpdateCartApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update CartGet Organization Detail internal server error message",
                description = "Update Cart internal server error message for status code 500"
        )
        String getUpdateCartApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Cart Broken Sql Connection",
                description = "Update Cart Broken Sql Connection error message for status code 500"
        )
        String getUpdateCartApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Cart MicroService Broken  Connection",
                description = "Update Cart microservice broken connection error message for status code 500"
        )
        String getUpdateCartApiMicroserviceBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Cart Resource Not Found",
                description = "Update Cart Resource Not Found error message for status code 500"
        )
        String getUpdateCartApiResourceNotFoundConfig() default StringUtils.EMPTY;


        // Update Organization

        @AttributeDefinition(
                name = "Update Organization success message",
                description = "Update Organization success message for status code 200"
        )
        String getUpdateOrganizationApiSuccessMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization bad request message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Content bad request message",
                description = "Update Organization bad request message for status code 400"
        )
        String getUpdateOrganizationApiBadRequestMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization forbidden profile message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Content forbidden message",
                description = "Update Organization forbidden message for status code 403"
        )
        String getUpdateOrganizationApiForbiddenMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization internal server error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Organization Detail internal server error message",
                description = "Update Organization internal server error message for status code 500"
        )
        String getUpdateOrganizationApiInternalServerErrorMessageConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Broken Sql Connection error message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Broken Sql Connection",
                description = "Update Organization Broken Sql Connection error message for status code 500"
        )
        String getUpdateOrganizationApiBrokenSqlConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization MicroService Broken  Connection",
                description = "Update Organization microservice broken connection error message for status code 500"
        )
        String getUpdateOrganizationApiMicroserviceBrokenConnection() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization already exist",
                description = "Update Organization already exist error message for status code 500"
        )
        String getUpdateOrganizationApiNotExistConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Get Organization Microservice Broken message
         *
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Invalid User",
                description = "Update Organization Invalid User error message for status code 500"
        )
        String getUpdateOrganizationApiInvalidUserConfig() default StringUtils.EMPTY;
    }
}
