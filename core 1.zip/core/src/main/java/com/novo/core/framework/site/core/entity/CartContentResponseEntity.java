package com.novo.core.framework.site.core.entity;

/**
 * Represents CartContentResponseEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class CartContentResponseEntity {

    private SaveCartContentRequestEntity[] cartContent;
    /**
     * The request entity containing organization details
     * used for creating or updating an organization.
     */
    private OrganizationDetailsRequestEntity organizationDetails;

    public CartContentResponseEntity() {
    }

    /**
     * This constructor takes in an array of cart content and organization
     * details and initializes them to the class variables.
     * @param cartContent The array of cart content to be saved.
     * @param organizationDetails The organization details associated
     * with the cart content.
     */
    public CartContentResponseEntity(SaveCartContentRequestEntity[] cartContent, OrganizationDetailsRequestEntity organizationDetails) {
        this.cartContent = cartContent;
        this.organizationDetails = organizationDetails;
    }

    public SaveCartContentRequestEntity[] getCartContent() {
        return cartContent;
    }

    public OrganizationDetailsRequestEntity getOrganizationDetails() {
        return organizationDetails;
    }

    public void setOrganizationDetails(OrganizationDetailsRequestEntity organizationDetails) {
        this.organizationDetails = organizationDetails;
    }

    public void setCartContent(SaveCartContentRequestEntity[] cartContent) {
        this.cartContent = cartContent;
    }

}
