package com.novo.core.framework.site.core.services.impl;

import com.novo.core.framework.site.core.entity.ServletAPIUrls;
import com.novo.core.framework.site.core.services.ServletAPIUrlsService;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Servlet api impl for urls config to be used by UI
 *
 * check the component and designate annotations for defining service
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = ServletAPIUrlsService.class)
@Designate(ocd= ServletAPIUrlsServiceImpl.ContentDistributionApiUrlsConfig.class)
public class ServletAPIUrlsServiceImpl implements ServletAPIUrlsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServletAPIUrlsServiceImpl.class);

    private ServletAPIUrls servletAPIUrls = new ServletAPIUrls();

    /**
     * Activates or modifies the Content Distribution API URLs
     * configuration.
     * Sets the necessary servlet URLs for various API endpoints.
     * @param config the ContentDistributionApiUrlsConfig object
     * containing the servlet URLs
     */
    @Activate
    @Modified
    protected void activatedOrModified(final ContentDistributionApiUrlsConfig config){
        servletAPIUrls.setCartAPI(config.cartServletUrlConfig());
        servletAPIUrls.setUpdateCartAPI(config.updateCartServletUrlConfig());
        servletAPIUrls.setCartContentAPI(config.cartContentServletUrlConfig());
        servletAPIUrls.setPublishCartContentAPI(config.publishCartContentServletUrlConfig());
        servletAPIUrls.setResourceType(config.resourceTypeUrlConfig());
        servletAPIUrls.setUploadLogoAPI(config.uploadLogoServletUrlConfig());
        servletAPIUrls.setOrganizationDetailsAPI(config.organizationDetailsServletUrlConfig());
        servletAPIUrls.setDeleteCartApi(config.deleteCartServletUrlConfig());
        servletAPIUrls.setUpdateOrganizationDetailsApi(config.updateOrganizationServletUrlConfig());
        servletAPIUrls.setCartDetailsDetailsApi(config.cartDetailsServletUrlConfig());

        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Cart API  URL : {}", servletAPIUrls.getCartAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Update Cart API  URL : {}", servletAPIUrls.getUpdateCartAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Cart Content API  URL : {}", servletAPIUrls.getCartContentAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Publish Cart Content API  URL : {}", servletAPIUrls.getPublishCartContentAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution ResourceType URL : {}", servletAPIUrls.getResourceType());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Upload Logo URL : {}", servletAPIUrls.getUploadLogoAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Get Organization Details URL : {}", servletAPIUrls.getOrganizationDetailsAPI());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution Delete Cart URL : {}", servletAPIUrls.getDeleteCartApi());
        LOGGER.debug("RestAPIUrlsService Activate() "
                + "contentdistribution GET Cart Details URL : {}", servletAPIUrls.getCartDetailsDetailsApi());

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("RestAPIUrlsService Activate() contentdistribution Get Organization Details URL : {}", servletAPIUrls.getOrganizationDetailsAPI());
        }
    }

    @Override
    public ServletAPIUrls getRestAPIUrls() {
        return servletAPIUrls;
    }

    @ObjectClassDefinition(name = "Content Distribution API Urls Config")
    public @interface ContentDistributionApiUrlsConfig {

        /**
         * Attribute definition for GET cart API url
         * @return
         */
        @AttributeDefinition(
                name = "Cart api url",
                description = "Cart api url"
        )
        String cartServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for UPDATE cart API url
         * @return
         */
        @AttributeDefinition(
                name = "Update cart api url",
                description = "Update cart api url"
        )
        String updateCartServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create cart API url
         * @return
         */
        @AttributeDefinition(
                name = "Cart content api url",
                description = "Cart content api url"
        )
        String cartContentServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Content API url
         * @return
         */
        @AttributeDefinition(
                name = "Publish cart content api url",
                description = "Publish cart content api url"
        )
        String publishCartContentServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for GET Content API url
         * @return
         */
        @AttributeDefinition(
                name = "Resource type url",
                description = "Resource type url"
        )
        String resourceTypeUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Create Customization API url
         * @return
         */
        @AttributeDefinition(
                name = "Create Customization api url",
                description = "Create Customization api url"
        )
        String uploadLogoServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Upload Logo API url
         * @return
         */
        @AttributeDefinition(
                name = "Organization Details api url",
                description = "Organization Details api url"
        )
        String organizationDetailsServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Delete Cart API url
         * @return
         */
        @AttributeDefinition(
                name = "Delete cart api url",
                description = "Delete cart api url"
        )
        String deleteCartServletUrlConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Update Organization details API url
         * @return
         */
        @AttributeDefinition(
                name = "Update Organization Details api url",
                description = "Update Organization Details api url"
        )
        String updateOrganizationServletUrlConfig() default StringUtils.EMPTY;


        /**
         * Attribute definition for getting Cart details API url
         * @return
         */
        @AttributeDefinition(
                name = "Get Cart Details api url",
                description = "Get Cart Details api url"
        )
        String cartDetailsServletUrlConfig() default StringUtils.EMPTY;
    }
}
