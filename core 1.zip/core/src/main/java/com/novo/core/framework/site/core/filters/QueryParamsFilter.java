package com.novo.core.framework.site.core.filters;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import static org.apache.sling.engine.EngineConstants.*;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Component;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.novo.core.framework.site.core.models.QueryParamModel;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;


@Component(service = Filter.class, property = {
        SLING_FILTER_SCOPE + "=" + FILTER_SCOPE_REQUEST, Constants.SERVICE_RANKING + ":Integer=1",
        SLING_FILTER_RESOURCETYPES + "=cq:Page"
})
public class QueryParamsFilter implements Filter{

    final ArrayList<String> resTypes = new ArrayList<String>(Arrays.asList(
        "novo-core-framework/site/components/structure/novo-home",
        "novo-core-framework/site/components/structure/novo-content",
        "novo-core-framework/site/components/structure/novo-content-rollup",
        "novo-core-framework/site/components/structure/novo-redirect",
        "novo-core-framework/site/components/structure/novo-registration"
    ));

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Usually, do nothing
    }

    @Override
    public final void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;
        try{
            final Resource resource = slingRequest.getResource();
            final Page page = resource.adaptTo(Page.class);
            final ValueMap vm = page.getProperties();
            String type = vm.get("sling:resourceType", String.class);
            if (!type.isEmpty() && resTypes.contains(type)) {
                Map<String, String> qp = new HashMap<String, String>();
                Enumeration<String> names = request.getParameterNames();
                while (names.hasMoreElements()){
                    String n = names.nextElement();
                    qp.put(n, String.join(",", request.getParameterValues(n)));
                }
                if (!qp.isEmpty()){
                    QueryParamModel qpModel = new QueryParamModel();
                    response = qpModel.setParams(request, response, qp);
                }
            }
        }
        catch(Exception e){
            
        }
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Usually, do nothing
    }
}
