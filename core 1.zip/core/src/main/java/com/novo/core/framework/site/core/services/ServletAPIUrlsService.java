package com.novo.core.framework.site.core.services;

import com.novo.core.framework.site.core.entity.ServletAPIUrls;

public interface ServletAPIUrlsService {

    /**
     * Method to return servlet endpoint urls
     *
     * @return {@link ServletAPIUrls}
     */
    public ServletAPIUrls getRestAPIUrls();
}
