package com.novo.core.framework.site.core.entity;

/**
 * Represents an APIMessage object
 *
 * @version 1.0
 * @since 1.0
 */
@SuppressWarnings("PMD.TooManyFields")
public class ApiMessage {

    private String getCartsSuccessMessage;
    private String getCartsBadRequestMessage;
    private String getCartsForbiddenMessage;
    private String getCartsInternalServerErrorMessage;
    private String getCartInvalidAuthToken;
    private String getCartBrokenMicroservice;
    private String getCartForUserInvalidDiseaseType;
    private String getCartBrokenSqlConnection;

    private String createCartSuccessMessage;
    private String createCartBadRequestMessage;
    private String createCartsForbiddenMessage;
    private String createCartInternalServerErrorMessage;
    private String createCartInvalidAuthToken;
    private String createCartBrokenMicroservice;
    private String createCartMoreThanFiftyChar;
    private String createCartBrokenSqlConnection;
    private String createCartMaxLimitReach;
    private String createCartInvalidDiseaseType;
    private String createCartEmptyCartName;


    private String getCartContentSuccessMessage;
    private String getCartContentBadRequestMessage;
    private String getCartContentForbiddenMessage;
    private String getCartContentInternalServerErrorMessage;
    private String getCartContentBrokenSqlConnection;
    private String getCartContentBrokenConnection;
    private String getCartContentInvalidUniqueKey;
    private String getCartContentWithNullResolver;
    private String getCartContentWithNoValidResources;
    private String getCartContentResourcesPageNotPresent;
    private String getCartContentApiNotCartAvailable;

    private String createCartContentSuccessMessage;
    /**
     * String representing the invalid user for create cart content.
     */
    private String createCartContentInvalidUser;
    /**
     * String representing the invalid cart for create cart content.
     */
    private String createCartContentInvalidCart;
    private String createCartContentBadRequestMessage;
    private String createCartContentForbiddenMessage;
    private String createCartContentInternalServerErrorMessage;
    private String createCartContentBrokenSqlConnection;
    private String createCartContentOfNotCreatedDiseaseType;
    private String createCartContentBlankPath;
    private String createCartContentEmptyOrder;
    private String createCartContentWithNullResolver;
    private String createCartContentBrokenConnection;
    private String createCartContentInvalidContent;

    private String deleteCartSuccessMessage;
    private String deleteCartBadRequestMessage;
    private String deleteCartForbiddenMessage;
    private String deleteCartInternalServerErrorMessage;
    private String deleteCartBrokenConnection;
    private String deleteCartBrokenSqlConnection;
    private String deleteCartInvalidCartId;
    private String deleteCartCartNotExist;
    private String deleteCartInvalidAuthToken;


    private String uploadLogoSuccessMessage;
    private String uploadLogoBadRequestMessage;
    private String uploadLogoForbiddenMessage;
    private String uploadLogoInternalServerErrorMessage;
    private String uploadLogoFileSizeExceedMessage;
    private String uploadLogoFileFormatInvalidMessage;
    private String uploadLogoBrokenConnection;
    private String uploadLogoInvalidFileName;
    private String uploadLogoInvalidImageFile;
    private String uploadLogoInvalidRedirectUrl;
    /**
     * String representing the invalid userId for upload logo.
     */
    private String uploadLogoInvalidUserId;
    /**
     * String representing an error message when the
     * length of the Base64-encoded logo exceeds the allowed limit.
     */
    private String uploadLogoInvalidLengthBase64;
    /**
     * String representing an error message when the organization already exist.
     */
    private String uploadLogoOrganizationAlreadyExist;

    /**
     * String representing a success message when the organization data
     * fetched successfully from api.
     */
    private String getOrganizationApiSuccess;
    /**
     * String representing an error message when a bad request error occurs
     * while making an API call to retrieve organization data.
     */
    private String getOrganizationApiBadRequest;
    /**
     * String representing an error message when a forbidden access error occurs
     * while making an API call to retrieve organization data.
     */
    private String getOrganizationApiForbidden;
    /**
     * String representing an error message when an internal server error occurs
     * while making an API call to retrieve organization data.
     */
    private String getOrganizationApiInternalServerError;
    /**
     * String representing an error message when a broken SQL connection error occurs
     * while making an API call to retrieve organization data.
     */
    private String getOrganizationApiBrokenSqlConnection;
    /**
     * String representing an error message when the microservice used to
     * retrieve organization data is broken.
     */
    private String getOrganizationApiMicroserviceBroken;
    /**
     * String representing an error message when an invalid user tries to
     * make an API call to retrieve organization data.
     */
    private String getOrganizationApiInvalidUser;
    /**
     * String representing a success message when an API call to retrieve
     * organization data is successful.
     */

    private String getOrganizationDetailApiSuccess;
    /**
     * String representing an error message when a bad request error occurs
     * while making an API call to retrieve organization detail data.
     */
    private String getOrganizationDetailApiBadRequest;
    /**
     * String representing an error message when a forbidden access error occurs
     * while making an API call to retrieve organization detail data.
     */
    private String getOrganizationDetailApiForbidden;
    /**
     * String representing an error message when an internal server error occurs
     * while making an API call to retrieve organization detail data.
     */
    private String getOrganizationDetailApiInternalServerError;
    /**
     * String representing an error message when a broken SQL connection error occurs
     * while making an API call to retrieve organization detail data.
     */
    private String getOrganizationDetailApiBrokenSqlConnection;
    /**
     * String representing an error message when the microservice used to
     * retrieve organization detail data is broken.
     */
    private String getOrganizationDetailApiMicroserviceBroken;
    /**
     * The error message or code returned when a requested
     * organization detail resource is not found.
     */
    private String getOrganizationDetailApiResourceNotFound;

    /**
     *The message or code indicating a successful update of a cart.
     */
    private String updateCartApiSuccess;
    /**
     * String representing an error message when a bad request error occurs
     * while making an API call for updating cart.
     */
    private String updateCartApiBadRequest;
    /**
     * String representing an error message when a forbidden access error occurs
     * while making an API call for updating cart.
     */
    private String updateCartApiForbidden;
    /**
     * String representing an error message when an internal server error occurs
     * while making an API call for updating cart.
     */
    private String updateCartApiInternalServerError;
    /**
     * String representing an error message when a broken SQL connection error occurs
     * while making an API call for updating cart.
     */
    private String updateCartApiBrokenSqlConnection;
    /**
     * String representing an error message when the microservice used to
     * updating cart data is broken.
     */
    private String updateCartApiMicroserviceBroken;
    /**
     * This field is used in API responses to indicate
     * that the requested cart resource could not be found.
     */
    private String updateCartApiResourceNotFound;


    /**
     *The message or code indicating a successful update of an
     * organization data.
     */
    private String updateOrganizationApiSuccess;
    /**
     * String representing an error message when a bad request error occurs
     * while making an API call for updating organization data.
     */
    private String updateOrganizationApiBadRequest;
    /**
     * String representing an error message when a forbidden access error occurs
     * while making an API call for updating organization data.
     */
    private String updateOrganizationApiForbidden;
    /**
     * String representing an error message when an internal server error occurs
     * while making an API call for updating organization data.
     */
    private String updateOrganizationApiInternalServerError;
    /**
     * String representing an error message when a broken SQL connection error occurs
     * while making an API call for updating organization data.
     */
    private String updateOrganizationApiBrokenSqlConnection;
    /**
     * String representing an error message when the microservice used to
     * updating organization data is broken.
     */
    private String updateOrganizationApiMicroserviceBroken;
    /**
     * The error message or code returned when an attempt is
     * made to update an organization with an invalid user ID.
     */
    private String updateOrganizationInvalidUserId;
    /**
     * The error message or code returned when an attempt
     * is made to create an organization that already exists.
     */
    private String updateOrganizationAlreadyExist;



    public String getUpdateCartApiSuccess() {
        return updateCartApiSuccess;
    }

    public void setUpdateCartApiSuccess(String updateCartApiSuccess) {
        this.updateCartApiSuccess = updateCartApiSuccess;
    }

    public String getUpdateCartApiBadRequest() {
        return updateCartApiBadRequest;
    }

    public void setUpdateCartApiBadRequest(String updateCartApiBadRequest) {
        this.updateCartApiBadRequest = updateCartApiBadRequest;
    }

    public String getUpdateCartApiForbidden() {
        return updateCartApiForbidden;
    }

    public void setUpdateCartApiForbidden(String updateCartApiForbidden) {
        this.updateCartApiForbidden = updateCartApiForbidden;
    }

    public String getUpdateCartApiInternalServerError() {
        return updateCartApiInternalServerError;
    }

    public void setUpdateCartApiInternalServerError(String updateCartApiInternalServerError) {
        this.updateCartApiInternalServerError = updateCartApiInternalServerError;
    }

    public String getUpdateCartApiBrokenSqlConnection() {
        return updateCartApiBrokenSqlConnection;
    }

    public void setUpdateCartApiBrokenSqlConnection(String updateCartApiBrokenSqlConnection) {
        this.updateCartApiBrokenSqlConnection = updateCartApiBrokenSqlConnection;
    }

    public String getUpdateCartApiMicroserviceBroken() {
        return updateCartApiMicroserviceBroken;
    }

    public void setUpdateCartApiMicroserviceBroken(String updateCartApiMicroserviceBroken) {
        this.updateCartApiMicroserviceBroken = updateCartApiMicroserviceBroken;
    }

    public String getUpdateCartApiResourceNotFound() {
        return updateCartApiResourceNotFound;
    }

    public void setUpdateCartApiResourceNotFound(String updateCartApiResourceNotFound) {
        this.updateCartApiResourceNotFound = updateCartApiResourceNotFound;
    }

    public String getDeleteCartInvalidAuthToken() {
        return deleteCartInvalidAuthToken;
    }

    public void setDeleteCartInvalidAuthToken(String deleteCartInvalidAuthToken) {
        this.deleteCartInvalidAuthToken = deleteCartInvalidAuthToken;
    }
    public String getGetOrganizationApiInvalidUser() {
        return getOrganizationApiInvalidUser;
    }

    public void setGetOrganizationApiInvalidUser(String getOrganizationApiInvalidUser) {
        this.getOrganizationApiInvalidUser = getOrganizationApiInvalidUser;
    }

    public String getGetOrganizationDetailApiSuccess() {
        return getOrganizationDetailApiSuccess;
    }

    public void setGetOrganizationDetailApiSuccess(String getOrganizationDetailApiSuccess) {
        this.getOrganizationDetailApiSuccess = getOrganizationDetailApiSuccess;
    }

    public String getGetOrganizationDetailApiBadRequest() {
        return getOrganizationDetailApiBadRequest;
    }

    public void setGetOrganizationDetailApiBadRequest(String getOrganizationDetailApiBadRequest) {
        this.getOrganizationDetailApiBadRequest = getOrganizationDetailApiBadRequest;
    }

    public String getGetOrganizationDetailApiForbidden() {
        return getOrganizationDetailApiForbidden;
    }

    public void setGetOrganizationDetailApiForbidden(String getOrganizationDetailApiForbidden) {
        this.getOrganizationDetailApiForbidden = getOrganizationDetailApiForbidden;
    }

    public String getGetOrganizationDetailApiInternalServerError() {
        return getOrganizationDetailApiInternalServerError;
    }

    public void setGetOrganizationDetailApiInternalServerError(String getOrganizationDetailApiInternalServerError) {
        this.getOrganizationDetailApiInternalServerError = getOrganizationDetailApiInternalServerError;
    }

    public String getGetOrganizationDetailApiBrokenSqlConnection() {
        return getOrganizationDetailApiBrokenSqlConnection;
    }

    public void setGetOrganizationDetailApiBrokenSqlConnection(String getOrganizationDetailApiBrokenSqlConnection) {
        this.getOrganizationDetailApiBrokenSqlConnection = getOrganizationDetailApiBrokenSqlConnection;
    }

    public String getGetOrganizationDetailApiMicroserviceBroken() {
        return getOrganizationDetailApiMicroserviceBroken;
    }

    public void setGetOrganizationDetailApiMicroserviceBroken(String getOrganizationDetailApiMicroserviceBroken) {
        this.getOrganizationDetailApiMicroserviceBroken = getOrganizationDetailApiMicroserviceBroken;
    }

    public String getGetOrganizationDetailApiResourceNotFound() {
        return getOrganizationDetailApiResourceNotFound;
    }

    public void setGetOrganizationDetailApiResourceNotFound(String getOrganizationDetailApiResourceNotFound) {
        this.getOrganizationDetailApiResourceNotFound = getOrganizationDetailApiResourceNotFound;
    }

    public String getDeleteCartCartNotExist() {
        return deleteCartCartNotExist;
    }

    public void setDeleteCartCartNotExist(String deleteCartCartNotExist) {
        this.deleteCartCartNotExist = deleteCartCartNotExist;
    }

    public String getUploadLogoInvalidFileName() {
        return uploadLogoInvalidFileName;
    }

    public void setUploadLogoInvalidFileName(String uploadLogoInvalidFileName) {
        this.uploadLogoInvalidFileName = uploadLogoInvalidFileName;
    }

    public String getUploadLogoInvalidImageFile() {
        return uploadLogoInvalidImageFile;
    }

    public void setUploadLogoInvalidImageFile(String uploadLogoInvalidImageFile) {
        this.uploadLogoInvalidImageFile = uploadLogoInvalidImageFile;
    }

    public String getUploadLogoInvalidRedirectUrl() {
        return uploadLogoInvalidRedirectUrl;
    }

    public void setUploadLogoInvalidRedirectUrl(String uploadLogoInvalidRedirectUrl) {
        this.uploadLogoInvalidRedirectUrl = uploadLogoInvalidRedirectUrl;
    }

    public String getUploadLogoInvalidLengthBase64() {
        return uploadLogoInvalidLengthBase64;
    }

    public void setUploadLogoInvalidLengthBase64(String uploadLogoInvalidLengthBase64) {
        this.uploadLogoInvalidLengthBase64 = uploadLogoInvalidLengthBase64;
    }

    public String getUploadLogoOrganizationAlreadyExist() {
        return uploadLogoOrganizationAlreadyExist;
    }

    public void setUploadLogoOrganizationAlreadyExist(String uploadLogoOrganizationAlreadyExist) {
        this.uploadLogoOrganizationAlreadyExist = uploadLogoOrganizationAlreadyExist;
    }

    public String getUploadLogoBrokenConnection() {
        return uploadLogoBrokenConnection;
    }

    public void setUploadLogoBrokenConnection(String uploadLogoBrokenConnection) {
        this.uploadLogoBrokenConnection = uploadLogoBrokenConnection;
    }

    public String getCreateCartContentInvalidContent() {
        return createCartContentInvalidContent;
    }

    public void setCreateCartContentInvalidContent(String createCartContentInvalidContent) {
        this.createCartContentInvalidContent = createCartContentInvalidContent;
    }

    public String getCreateCartContentBrokenConnection() {
        return createCartContentBrokenConnection;
    }

    public void setCreateCartContentBrokenConnection(String createCartContentBrokenConnection) {
        this.createCartContentBrokenConnection = createCartContentBrokenConnection;
    }

    public String getCreateCartEmptyCartName() {
        return createCartEmptyCartName;
    }

    public void setCreateCartEmptyCartName(String createCartEmptyCartName) {
        this.createCartEmptyCartName = createCartEmptyCartName;
    }

    public String getCreateCartContentBrokenSqlConnection() {
        return createCartContentBrokenSqlConnection;
    }

    public void setCreateCartContentBrokenSqlConnection(String createCartContentBrokenSqlConnection) {
        this.createCartContentBrokenSqlConnection = createCartContentBrokenSqlConnection;
    }

    public void setCreateCartInvalidDiseaseType(String createCartInvalidDiseaseType) {
        this.createCartInvalidDiseaseType = createCartInvalidDiseaseType;
    }

    public String getGetCartContentApiNotCartAvailable() {
        return getCartContentApiNotCartAvailable;
    }

    public void setGetCartContentApiNotCartAvailable(String getCartContentApiNotCartAvailable) {
        this.getCartContentApiNotCartAvailable = getCartContentApiNotCartAvailable;
    }

    public String getCreateCartContentOfNotCreatedDiseaseType() {
        return createCartContentOfNotCreatedDiseaseType;
    }

    public void setCreateCartContentOfNotCreatedDiseaseType(String createCartContentOfNotCreatedDiseaseType) {
        this.createCartContentOfNotCreatedDiseaseType = createCartContentOfNotCreatedDiseaseType;
    }

    public String getCreateCartContentBlankPath() {
        return createCartContentBlankPath;
    }

    public void setCreateCartContentBlankPath(String createCartContentBlankPath) {
        this.createCartContentBlankPath = createCartContentBlankPath;
    }

    public String getCreateCartInvalidDiseaseType() {
        return createCartInvalidDiseaseType;
    }

    public String getCreateCartContentEmptyOrder() {
        return createCartContentEmptyOrder;
    }

    public void setCreateCartContentEmptyOrder(String createCartContentEmptyOrder) {
        this.createCartContentEmptyOrder = createCartContentEmptyOrder;
    }

    public String getCreateCartContentWithNullResolver() {
        return createCartContentWithNullResolver;
    }

    public void setCreateCartContentWithNullResolver(String createCartContentWithNullResolver) {
        this.createCartContentWithNullResolver = createCartContentWithNullResolver;
    }

    public String getGetCartContentBrokenSqlConnection() {
        return getCartContentBrokenSqlConnection;
    }

    public void setGetCartContentBrokenSqlConnection(String getCartContentBrokenSqlConnection) {
        this.getCartContentBrokenSqlConnection = getCartContentBrokenSqlConnection;
    }

    public String getGetCartContentBrokenConnection() {
        return getCartContentBrokenConnection;
    }

    public void setGetCartContentBrokenConnection(String getCartContentBrokenConnection) {
        this.getCartContentBrokenConnection = getCartContentBrokenConnection;
    }

    public String getGetCartContentInvalidUniqueKey() {
        return getCartContentInvalidUniqueKey;
    }

    public void setGetCartContentInvalidUniqueKey(String getCartContentInvalidUniqueKey) {
        this.getCartContentInvalidUniqueKey = getCartContentInvalidUniqueKey;
    }

    public String getGetCartContentWithNullResolver() {
        return getCartContentWithNullResolver;
    }

    public void setGetCartContentWithNullResolver(String getCartContentWithNullResolver) {
        this.getCartContentWithNullResolver = getCartContentWithNullResolver;
    }

    public String getGetCartContentWithNoValidResources() {
        return getCartContentWithNoValidResources;
    }

    public void setGetCartContentWithNoValidResources(String getCartContentWithNoValidResources) {
        this.getCartContentWithNoValidResources = getCartContentWithNoValidResources;
    }

    public String getGetCartContentResourcesPageNotPresent() {
        return getCartContentResourcesPageNotPresent;
    }

    public void setGetCartContentResourcesPageNotPresent(String getCartContentResourcesPageNotPresent) {
        this.getCartContentResourcesPageNotPresent = getCartContentResourcesPageNotPresent;
    }

    public String getDeleteCartBrokenConnection() {
        return deleteCartBrokenConnection;
    }

    public void setDeleteCartBrokenConnection(String deleteCartBrokenConnection) {
        this.deleteCartBrokenConnection = deleteCartBrokenConnection;
    }

    public String getDeleteCartBrokenSqlConnection() {
        return deleteCartBrokenSqlConnection;
    }

    public void setDeleteCartBrokenSqlConnection(String deleteCartBrokenSqlConnection) {
        this.deleteCartBrokenSqlConnection = deleteCartBrokenSqlConnection;
    }

    public String getDeleteCartInvalidCartId() {
        return deleteCartInvalidCartId;
    }

    public void setDeleteCartInvalidCartId(String deleteCartInvalidCartId) {
        this.deleteCartInvalidCartId = deleteCartInvalidCartId;
    }

    public String getCreateCartInvalidAuthToken() {
        return createCartInvalidAuthToken;
    }

    public void setCreateCartInvalidAuthToken(String createCartInvalidAuthToken) {
        this.createCartInvalidAuthToken = createCartInvalidAuthToken;
    }

    public String getCreateCartBrokenMicroservice() {
        return createCartBrokenMicroservice;
    }

    public void setCreateCartBrokenMicroservice(String createCartBrokenMicroservice) {
        this.createCartBrokenMicroservice = createCartBrokenMicroservice;
    }

    public String getCreateCartContentInvalidUser() {
        return createCartContentInvalidUser;
    }

    public void setCreateCartContentInvalidUser(String createCartContentInvalidUser) {
        this.createCartContentInvalidUser = createCartContentInvalidUser;
    }

    public String getCreateCartContentInvalidCart() {
        return createCartContentInvalidCart;
    }

    public void setCreateCartContentInvalidCart(String createCartContentInvalidCart) {
        this.createCartContentInvalidCart = createCartContentInvalidCart;
    }

    public String getCreateCartMoreThanFiftyChar() {
        return createCartMoreThanFiftyChar;
    }

    public void setCreateCartMoreThanFiftyChar(String createCartMoreThanFiftyChar) {
        this.createCartMoreThanFiftyChar = createCartMoreThanFiftyChar;
    }

    public String getCreateCartBrokenSqlConnection() {
        return createCartBrokenSqlConnection;
    }

    public void setCreateCartBrokenSqlConnection(String createCartBrokenSqlConnection) {
        this.createCartBrokenSqlConnection = createCartBrokenSqlConnection;
    }

    public String getCreateCartMaxLimitReach() {
        return createCartMaxLimitReach;
    }

    public void setCreateCartMaxLimitReach(String createCartMaxLimitReach) {
        this.createCartMaxLimitReach = createCartMaxLimitReach;
    }

    public String getGetCartInvalidAuthToken() {
        return getCartInvalidAuthToken;
    }

    public void setGetCartInvalidAuthToken(String getCartInvalidAuthToken) {
        this.getCartInvalidAuthToken = getCartInvalidAuthToken;
    }

    public String getGetCartBrokenMicroservice() {
        return getCartBrokenMicroservice;
    }

    public void setGetCartBrokenMicroservice(String getCartBrokenMicroservice) {
        this.getCartBrokenMicroservice = getCartBrokenMicroservice;
    }

    public String getGetCartForUserInvalidDiseaseType() {
        return getCartForUserInvalidDiseaseType;
    }

    public void setGetCartForUserInvalidDiseaseType(String getCartForUserInvalidDiseaseType) {
        this.getCartForUserInvalidDiseaseType = getCartForUserInvalidDiseaseType;
    }

    public String getGetCartBrokenSqlConnection() {
        return getCartBrokenSqlConnection;
    }

    public void setGetCartBrokenSqlConnection(String getCartBrokenSqlConnection) {
        this.getCartBrokenSqlConnection = getCartBrokenSqlConnection;
    }

    public String getUploadLogoSuccessMessage() {
        return uploadLogoSuccessMessage;
    }

    public void setUploadLogoSuccessMessage(String uploadLogoSuccessMessage) {
        this.uploadLogoSuccessMessage = uploadLogoSuccessMessage;
    }

    public String getUploadLogoBadRequestMessage() {
        return uploadLogoBadRequestMessage;
    }

    public void setUploadLogoBadRequestMessage(String uploadLogoBadRequestMessage) {
        this.uploadLogoBadRequestMessage = uploadLogoBadRequestMessage;
    }

    public String getUploadLogoForbiddenMessage() {
        return uploadLogoForbiddenMessage;
    }

    public void setUploadLogoForbiddenMessage(String uploadLogoForbiddenMessage) {
        this.uploadLogoForbiddenMessage = uploadLogoForbiddenMessage;
    }

    public String getUploadLogoInternalServerErrorMessage() {
        return uploadLogoInternalServerErrorMessage;
    }

    public void setUploadLogoInternalServerErrorMessage(String uploadLogoInternalServerErrorMessage) {
        this.uploadLogoInternalServerErrorMessage = uploadLogoInternalServerErrorMessage;
    }

    public String getUploadLogoFileSizeExceedMessage() {
        return uploadLogoFileSizeExceedMessage;
    }

    public void setUploadLogoFileSizeExceedMessage(String uploadLogoFileSizeExceedMessage) {
        this.uploadLogoFileSizeExceedMessage = uploadLogoFileSizeExceedMessage;
    }

    public String getUploadLogoFileFormatInvalidMessage() {
        return uploadLogoFileFormatInvalidMessage;
    }

    public void setUploadLogoFileFormatInvalidMessage(String uploadLogoFileFormatInvalidMessage) {
        this.uploadLogoFileFormatInvalidMessage = uploadLogoFileFormatInvalidMessage;
    }

    public String getGetCartsForbiddenMessage() {
        return getCartsForbiddenMessage;
    }

    public void setGetCartsForbiddenMessage(String getCartsForbiddenMessage) {
        this.getCartsForbiddenMessage = getCartsForbiddenMessage;
    }

    public String getCreateCartsForbiddenMessage() {
        return createCartsForbiddenMessage;
    }

    public void setCreateCartsForbiddenMessage(String createCartsForbiddenMessage) {
        this.createCartsForbiddenMessage = createCartsForbiddenMessage;
    }

    public String getGetCartContentForbiddenMessage() {
        return getCartContentForbiddenMessage;
    }

    public void setGetCartContentForbiddenMessage(String getCartContentForbiddenMessage) {
        this.getCartContentForbiddenMessage = getCartContentForbiddenMessage;
    }

    public String getCreateCartContentForbiddenMessage() {
        return createCartContentForbiddenMessage;
    }

    public void setCreateCartContentForbiddenMessage(String createCartContentForbiddenMessage) {
        this.createCartContentForbiddenMessage = createCartContentForbiddenMessage;
    }

    public String getDeleteCartForbiddenMessage() {
        return deleteCartForbiddenMessage;
    }

    public void setDeleteCartForbiddenMessage(String deleteCartForbiddenMessage) {
        this.deleteCartForbiddenMessage = deleteCartForbiddenMessage;
    }

    public String getGetCartsSuccessMessage() {
        return getCartsSuccessMessage;
    }

    public void setGetCartsSuccessMessage(String getCartsSuccessMessage) {
        this.getCartsSuccessMessage = getCartsSuccessMessage;
    }

    public String getGetCartsBadRequestMessage() {
        return getCartsBadRequestMessage;
    }

    public void setGetCartsBadRequestMessage(String getCartsBadRequestMessage) {
        this.getCartsBadRequestMessage = getCartsBadRequestMessage;
    }

    public String getGetCartsInternalServerErrorMessage() {
        return getCartsInternalServerErrorMessage;
    }

    public void setGetCartsInternalServerErrorMessage(String getCartsInternalServerErrorMessage) {
        this.getCartsInternalServerErrorMessage = getCartsInternalServerErrorMessage;
    }

    public String getCreateCartSuccessMessage() {
        return createCartSuccessMessage;
    }

    public void setCreateCartSuccessMessage(String createCartSuccessMessage) {
        this.createCartSuccessMessage = createCartSuccessMessage;
    }

    public String getCreateCartBadRequestMessage() {
        return createCartBadRequestMessage;
    }

    public void setCreateCartBadRequestMessage(String createCartBadRequestMessage) {
        this.createCartBadRequestMessage = createCartBadRequestMessage;
    }

    public String getCreateCartInternalServerErrorMessage() {
        return createCartInternalServerErrorMessage;
    }

    public void setCreateCartInternalServerErrorMessage(String createCartInternalServerErrorMessage) {
        this.createCartInternalServerErrorMessage = createCartInternalServerErrorMessage;
    }
    public String getUploadLogoInvalidUserId() {
        return uploadLogoInvalidUserId;
    }

    public void setUploadLogoInvalidUserId(String uploadLogoInvalidUserId) {
        this.uploadLogoInvalidUserId = uploadLogoInvalidUserId;
    }
    public String getGetCartContentSuccessMessage() {
        return getCartContentSuccessMessage;
    }

    public void setGetCartContentSuccessMessage(String getCartContentSuccessMessage) {
        this.getCartContentSuccessMessage = getCartContentSuccessMessage;
    }

    public String getGetCartContentBadRequestMessage() {
        return getCartContentBadRequestMessage;
    }

    public void setGetCartContentBadRequestMessage(String getCartContentBadRequestMessage) {
        this.getCartContentBadRequestMessage = getCartContentBadRequestMessage;
    }

    public String getGetCartContentInternalServerErrorMessage() {
        return getCartContentInternalServerErrorMessage;
    }

    public void setGetCartContentInternalServerErrorMessage(String getCartContentInternalServerErrorMessage) {
        this.getCartContentInternalServerErrorMessage = getCartContentInternalServerErrorMessage;
    }

    public String getCreateCartContentSuccessMessage() {
        return createCartContentSuccessMessage;
    }

    public void setCreateCartContentSuccessMessage(String createCartContentSuccessMessage) {
        this.createCartContentSuccessMessage = createCartContentSuccessMessage;
    }

    public String getCreateCartContentBadRequestMessage() {
        return createCartContentBadRequestMessage;
    }

    public void setCreateCartContentBadRequestMessage(String createCartContentBadRequestMessage) {
        this.createCartContentBadRequestMessage = createCartContentBadRequestMessage;
    }

    public String getCreateCartContentInternalServerErrorMessage() {
        return createCartContentInternalServerErrorMessage;
    }

    public void setCreateCartContentInternalServerErrorMessage(String createCartContentInternalServerErrorMessage) {
        this.createCartContentInternalServerErrorMessage = createCartContentInternalServerErrorMessage;
    }

    public String getDeleteCartSuccessMessage() {
        return deleteCartSuccessMessage;
    }

    public String getGetOrganizationApiSuccess() {
        return getOrganizationApiSuccess;
    }

    public void setGetOrganizationApiSuccess(String getOrganizationApiSuccess) {
        this.getOrganizationApiSuccess = getOrganizationApiSuccess;
    }

    public String getGetOrganizationApiBadRequest() {
        return getOrganizationApiBadRequest;
    }

    public void setGetOrganizationApiBadRequest(String getOrganizationApiBadRequest) {
        this.getOrganizationApiBadRequest = getOrganizationApiBadRequest;
    }

    public String getGetOrganizationApiForbidden() {
        return getOrganizationApiForbidden;
    }

    public void setGetOrganizationApiForbidden(String getOrganizationApiForbidden) {
        this.getOrganizationApiForbidden = getOrganizationApiForbidden;
    }

    public String getGetOrganizationApiInternalServerError() {
        return getOrganizationApiInternalServerError;
    }

    public void setGetOrganizationApiInternalServerError(String getOrganizationApiInternalServerError) {
        this.getOrganizationApiInternalServerError = getOrganizationApiInternalServerError;
    }

    public String getGetOrganizationApiBrokenSqlConnection() {
        return getOrganizationApiBrokenSqlConnection;
    }

    public void setGetOrganizationApiBrokenSqlConnection(String getOrganizationApiBrokenSqlConnection) {
        this.getOrganizationApiBrokenSqlConnection = getOrganizationApiBrokenSqlConnection;
    }

    public String getGetOrganizationApiMicroserviceBroken() {
        return getOrganizationApiMicroserviceBroken;
    }

    public void setGetOrganizationApiMicroserviceBroken(String getOrganizationApiMicroserviceBroken) {
        this.getOrganizationApiMicroserviceBroken = getOrganizationApiMicroserviceBroken;
    }

    public void setDeleteCartSuccessMessage(String deleteCartSuccessMessage) {
        this.deleteCartSuccessMessage = deleteCartSuccessMessage;
    }

    public String getDeleteCartBadRequestMessage() {
        return deleteCartBadRequestMessage;
    }

    public void setDeleteCartBadRequestMessage(String deleteCartBadRequestMessage) {
        this.deleteCartBadRequestMessage = deleteCartBadRequestMessage;
    }

    public String getDeleteCartInternalServerErrorMessage() {
        return deleteCartInternalServerErrorMessage;
    }

    public void setDeleteCartInternalServerErrorMessage(String deleteCartInternalServerErrorMessage) {
        this.deleteCartInternalServerErrorMessage = deleteCartInternalServerErrorMessage;
    }

    public String getUpdateOrganizationApiSuccess() {
        return updateOrganizationApiSuccess;
    }

    public void setUpdateOrganizationApiSuccess(String updateOrganizationApiSuccess) {
        this.updateOrganizationApiSuccess = updateOrganizationApiSuccess;
    }

    public String getUpdateOrganizationApiBadRequest() {
        return updateOrganizationApiBadRequest;
    }

    public void setUpdateOrganizationApiBadRequest(String updateOrganizationApiBadRequest) {
        this.updateOrganizationApiBadRequest = updateOrganizationApiBadRequest;
    }

    public String getUpdateOrganizationApiForbidden() {
        return updateOrganizationApiForbidden;
    }

    public void setUpdateOrganizationApiForbidden(String updateOrganizationApiForbidden) {
        this.updateOrganizationApiForbidden = updateOrganizationApiForbidden;
    }

    public String getUpdateOrganizationApiInternalServerError() {
        return updateOrganizationApiInternalServerError;
    }

    public void setUpdateOrganizationApiInternalServerError(String updateOrganizationApiInternalServerError) {
        this.updateOrganizationApiInternalServerError = updateOrganizationApiInternalServerError;
    }

    public String getUpdateOrganizationApiBrokenSqlConnection() {
        return updateOrganizationApiBrokenSqlConnection;
    }

    public void setUpdateOrganizationApiBrokenSqlConnection(String updateOrganizationApiBrokenSqlConnection) {
        this.updateOrganizationApiBrokenSqlConnection = updateOrganizationApiBrokenSqlConnection;
    }

    public String getUpdateOrganizationApiMicroserviceBroken() {
        return updateOrganizationApiMicroserviceBroken;
    }

    public void setUpdateOrganizationApiMicroserviceBroken(String updateOrganizationApiMicroserviceBroken) {
        this.updateOrganizationApiMicroserviceBroken = updateOrganizationApiMicroserviceBroken;
    }

    public String getUpdateOrganizationInvalidUserId() {
        return updateOrganizationInvalidUserId;
    }

    public void setUpdateOrganizationInvalidUserId(String updateOrganizationInvalidUserId) {
        this.updateOrganizationInvalidUserId = updateOrganizationInvalidUserId;
    }

    public String getUpdateOrganizationAlreadyExist() {
        return updateOrganizationAlreadyExist;
    }

    public void setUpdateOrganizationAlreadyExist(String updateOrganizationAlreadyExist) {
        this.updateOrganizationAlreadyExist = updateOrganizationAlreadyExist;
    }

}
