package com.novo.core.framework.site.core.servlets;

import org.jetbrains.annotations.NotNull;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import javax.servlet.Servlet;
import java.io.Serializable;


/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * <p>
 * It exposes two methods mainly
 * POST ,DELETE and GET method that can be used to get the cart
 * or delete the cart
 * or post cart to .NET API further
 * <p>
 * check the component annotations to understand the API signatures
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=novo-core-framework/site/components/content/educationcenter/diseaseTypes",
        "sling.servlet.selectors=alternateCartApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.extensions=json"})

public class CartDetailsServlet extends SlingAllMethodsServlet implements Serializable {

    /**
     * serialVersionUID of the servlet.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Used to inject cartService.
     */
    @Reference
    private transient CartService cartService;

    /**
     * Used to inject ContentDistributionMsgConfigService.
     */
    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;
    /**
     * GET method that gets cart data from the .NET API
     *
     * @param request  {@link CartRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doGet(@NotNull SlingHttpServletRequest request,@NotNull final SlingHttpServletResponse response) {
        final String publishPagePath = StringUtils.EMPTY;
        // Mapping servlet request with the bean
        final CartRequestEntity cartRequestEntity = CartUtils.createCartRequestEntityFromRequest(request);
        assert cartService != null;
        cartService.getCartDetails(response, cartRequestEntity, contentDistributionMsgConfigService, cartService, publishPagePath);
    }
}
