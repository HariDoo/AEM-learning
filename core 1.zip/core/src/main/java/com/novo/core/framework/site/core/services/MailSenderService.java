package com.novo.core.framework.site.core.services;

import com.novo.core.framework.site.core.entity.OrganizationDetailsRequestEntity;
import com.novo.core.framework.site.core.entity.Profile;
import com.novo.core.framework.site.core.exception.CartServletException;

import java.util.Map;

/**
 * The Interface MailSenderService allows to send mail.
 */
public interface MailSenderService {

    boolean isMailerEnabledFlag();

    /**
     * Send mail to the given sentTo Email ID with the given mail body.
     *
     * @param sendTo      String of email ID to which the mail is to be sent
     * @param body        {@link String} the body of the mail
     * @param emailParams {@link Map} Map of keys to value pair that are to be replaced in the given body. Ex: if the body contains the
     *                    place holder like ${fname}, the ${fname} will be replaced with value of the 'fname' key in map. Null in case no place
     *                    holders are to be replaced
     * @return true, if successful. If the body or sendTo  is blank or the sendTo is empty, mails are not sent and false is returned.
     */
    public boolean sendMailWithEmailString(final String sendTo, String body,
                                           final Map<String, String> emailParams);

    /**
     * Send mail to the given sentTo Email ID.
     *
     * @param profile   {@link Profile} the profile object for the mail
     * @param host   {@link String} string of host name
     * @return true, if successful. If the  sendTo is blank or the sendTo is empty.
     * Null in case no place holders are to be replaced found, mails are not sent and false is returned.
     */
    public boolean sendMailWithEmailTemplate(Profile profile, String host, OrganizationDetailsRequestEntity organizationDetailsRequest) throws CartServletException;
}
