package com.novo.core.framework.site.core.models;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import static com.novo.core.framework.site.core.utils.Utils.HASH;
import static com.novo.core.framework.site.core.utils.Utils.HTML_EXTENSION;
import static com.novo.core.framework.site.core.utils.Utils.HTTP;
import static com.novo.core.framework.site.core.utils.Utils.HTTPS;
import static com.novo.core.framework.site.core.utils.Utils.PDF;
import static com.novo.core.framework.site.core.utils.Utils.SLASH;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DropDownItem {

    private String itemName;
    private String itemLink;
    private String itemTarget;

    public static DropDownItem build(Resource item) {
        ValueMap map = item.getValueMap();
        if(!map.isEmpty()) {
            DropDownItem dropDownItem = new DropDownItem();
            dropDownItem.setItemName(map.get("itemName", String.class));
            dropDownItem.setItemTarget(map.get("itemTarget", String.class));
            String link = map.get("itemLink", String.class);
            if (link != null && (!"Modal Window".equalsIgnoreCase(dropDownItem.getItemTarget())) && (isNotEmpty(link)) && (!link.startsWith("javascript:"))) {
                link = addHtmlExtension(link);
            }
            dropDownItem.setItemLink(link);
            return dropDownItem;
        }

        return null;
    }

    public static String addHtmlExtension(final String path) {
        final StringBuilder finalPath = new StringBuilder();
        if (StringUtils.isNotEmpty(path)
                && !path.equals(HASH)
                && !path.startsWith(HASH)
                && !path.startsWith(HTTP)
                && !path.startsWith(HTTPS)
                && !path.toLowerCase().endsWith(HTML_EXTENSION)
                && !path.endsWith(SLASH)
                && !path.toLowerCase().endsWith(PDF)
                && !path.matches("^/(.)*\\.html#[\\w-]+$"))  //  starts /  and ends with .html#hashtag
        {
            finalPath.append(path).append(HTML_EXTENSION);
        } else {
            finalPath.append(path);
        }
        return finalPath.toString();
    }



    public String getItemTarget() {
        return itemTarget;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemLink() {
        return itemLink;
    }

    public void setItemTarget(String itemTarget) {
        this.itemTarget = itemTarget;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemLink(String link) {
        this.itemLink = link;
    }
}
