package com.novo.core.framework.site.core.exception;

/**
 * A custom exception class extends class {@code  Exception}
 * used for throw custom exception from service
 *
 * @version 1.0
 * @since 1.0
 */
public class CartServletException extends Exception {

    private final String errorMessage;
    private final boolean status;
    private final int statusCode;

    public CartServletException(boolean status, String errorMessage, int statusCode) {
        this.errorMessage = errorMessage;
        this.status = status;
        this.statusCode = statusCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public boolean isStatus() {
        return status;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
