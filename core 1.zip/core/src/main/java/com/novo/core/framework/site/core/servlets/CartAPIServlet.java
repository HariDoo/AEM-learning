package com.novo.core.framework.site.core.servlets;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.RestService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * <p>
 * It exposes two methods mainly
 * POST ,DELETE and GET method that can be used to get the cart
 * or delete the cart
 * or post cart to .NET API further
 * <p>
 * check the component annotations to understand the API signatures
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=novo-core-framework/site/components/content/educationcenter/carts",
        "sling.servlet.selectors=cartApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.extensions=json"})

public class CartAPIServlet extends SlingAllMethodsServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(CartAPIServlet.class);
    /**
     * Maximum number of items allowed in a shopping cart.
     */
    public static final String MAX_CART_NUMBER = "maxCartNumber";
    /**
     *  This constant is used to represent publishPagePath string.
     */
    public static final String PUBLISH_PAGE_PATH = "publishPagePath";

    @Reference
    private transient CartService cartService;

    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    @Reference
    private transient RestService restService;


    /**
     * POST method that posts cart data to the .NET API
     *
     * @param request  {@link CartRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doPost(@NotNull final SlingHttpServletRequest request, @NotNull final SlingHttpServletResponse response) {

        try {
            // Mapping servlet request with the bean
            CartRequestEntity cartRequestEntity;
            cartRequestEntity = CartUtils.getObjectFromRequest(request, CartRequestEntity.class);
            Resource resource = request.getResource();
            ValueMap vm;
            vm = resource.getValueMap();
            final String maxCount;
            maxCount = vm.get(MAX_CART_NUMBER, String.class);
            assert maxCount != null;
            int maxCountValue = Integer.parseInt(maxCount);
            cartRequestEntity.setMaxCount(maxCountValue);
            // validating the content of the mapped bean for fail fast approach
            CartUtils.validateRequestCreateCart(cartRequestEntity,contentDistributionMsgConfigService);

            ClientResponse clientResponse;
            // getting the user profile from novo server using the auth token passed in the request
            clientResponse = cartService.getUserProfile(cartRequestEntity.getAuthToken());
            long userId =CartUtils.getIdFromUserObj(clientResponse);

            if (userId == 0) {
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.POST_CART_USERID_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            cartRequestEntity.setUserId(userId);
            // creating cart by calling .NET APi endpoint
            clientResponse = cartService.createCart(cartRequestEntity);
            if(clientResponse!=null && StringUtils.isNotBlank(clientResponse.getData())){
                ResponseEntity<String> responseEntity ;
                ObjectMapper objectMapper = new ObjectMapper();
                responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                String message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                responseEntity.setMessage(message);
                CartUtils.sendAPIResponse(response, responseEntity, clientResponse.getStatusCode());
            }else{
                ResponseEntity<String> responseEntity = new ResponseEntity<>();
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.POST_CART_INTERNAL_SERVER_ERROR));
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            }
        } catch (IOException ioException) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException  :: CartAPIServlet() :: doPost {0}", ioException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.POST_CART_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        catch ( JSONException jsonException) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            LOGGER.error("JSONException :: CartAPIServlet() :: doPost {0}", jsonException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.POST_CART_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        catch (CartServletException ce) {
            ResponseEntity<String> responseEntity = new ResponseEntity<>();
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        }
    }

    /**
     * GET method that gets cart data from the .NET API
     *
     * @param request  {@link CartRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doGet(@NotNull final SlingHttpServletRequest request,@NotNull final SlingHttpServletResponse response) {
        // Mapping servlet request with the bean
        CartRequestEntity cartRequestEntity = CartUtils.createCartRequestEntityFromRequest(request);
        final ResourceResolver resolver = request.getResourceResolver();
        final PageManager pageManager = resolver.adaptTo(PageManager.class);
        if (pageManager != null){
            final Page page = pageManager.getContainingPage(request.getResource());
            // NOSONAR
            if (page != null) {
                final ValueMap valueMap = page.getProperties();
                final String publishPagePath = valueMap.get(PUBLISH_PAGE_PATH, String.class);
                cartService.getCartDetails(response, cartRequestEntity, contentDistributionMsgConfigService, cartService, publishPagePath);
            }
        }
    }
}
