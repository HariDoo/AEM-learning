package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.Page;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

/**
 * @author Klick
 *
 */
@Model(adaptables = SlingHttpServletRequest.class)
public class PageGlobalNavigationModel {

    private static final String HTML_EXTENSION = ".html";
    private static final String DAM_PATH = "/content/dam";
    private static final String GLOBAL_NAV = "jcr:content/globalNavigationList";
    private static final String GLOBAL_SECOND_ROW_NAV = "jcr:content/globalNavigationSecondRowList";

    @Inject
    private Page currentPage;

    @ValueMapValue
    @Default(values = "false")
    private Boolean readPageProperties;

    @ValueMapValue
    @Default(values = "")
    private String rootPath;

    @ValueMapValue
    @Default(values = "")
    private String secondaryRootPath;

    @ValueMapValue
    @Default(values = "false")
    private Boolean readGlobalNavLinksFromSecNav;

    @SlingObject
    private ResourceResolver resourceResolver;

    public List<GlobalNavigationList> globalNavigation = null;
    public List<GlobalNavigationList> globalNavigationSecondRow = null;

    @PostConstruct
    protected void init() {
        if (readPageProperties && Objects.nonNull(currentPage)) {
            Resource resource = currentPage.getContentResource();

            if (StringUtils.isNoneEmpty(rootPath)) {
                resource = resourceResolver.getResource(rootPath).adaptTo(Page.class).getContentResource();
                if (readGlobalNavLinksFromSecNav && isNotBlank(secondaryRootPath)){
                    resource = resourceResolver.getResource(secondaryRootPath).adaptTo(Page.class).getContentResource();
                }
            }

            final Resource inheritGlobalNavigationList = getParentGlobalNavigationList(resource, GLOBAL_NAV);
            final Resource inheritGlobalNavigationSecondRowList = getParentGlobalNavigationList(resource, GLOBAL_SECOND_ROW_NAV);

            List<Resource> navigationList = null;
            List<Resource> navigationSecondRowList = null;

            if (Objects.nonNull(inheritGlobalNavigationList)) {
                globalNavigation = new ArrayList<>();
                navigationList = IteratorUtils.toList(inheritGlobalNavigationList.listChildren());
            }

            if (Objects.nonNull(inheritGlobalNavigationSecondRowList)) {
                globalNavigationSecondRow = new ArrayList<>();
                navigationSecondRowList = IteratorUtils.toList(inheritGlobalNavigationSecondRowList.listChildren());
            }

            initialize(navigationList, navigationSecondRowList);
        }
    }

    public boolean isOverriding() {
        return Objects.nonNull(globalNavigation);
    }

    public boolean isSecondRowOverriding() {
        return Objects.nonNull(globalNavigationSecondRow);
    }

    public String getUrl(String link) {
        if (link != null) {
            Resource pathResource = resourceResolver.getResource(link);

            if (pathResource != null && link.indexOf(DAM_PATH) != 0) {
                return resourceResolver.map(link) + HTML_EXTENSION;
            }
        }
        return link;
    }

    public boolean getIsEmpty() {
        return globalNavigation.isEmpty();
    }

    public List<GlobalNavigationList> getGlobalNavigation() {
        return globalNavigation;
    }

    public void setGlobalNavigation(List<GlobalNavigationList> globalNavigation) {
        this.globalNavigation = globalNavigation;
    }

    public boolean isGlobalNavigationSecondRowNotEmpty() {
        return !globalNavigationSecondRow.isEmpty();
    }

    public List<GlobalNavigationList> getGlobalNavigationSecondRow() {
        return globalNavigationSecondRow;
    }

    public void setGlobalNavigationAlternative(final List<GlobalNavigationList> globalNavigationSecondRow) {
        this.globalNavigationSecondRow = globalNavigationSecondRow;
    }

    private Resource getParentGlobalNavigationList(final Resource current, final String propName) {
        if (Objects.isNull(current)) {
            return null;
        }

        final Resource inheritNavigationList = current.getChild(propName);

        if (Objects.nonNull(inheritNavigationList)) {
            return inheritNavigationList;
        }

        return getParentGlobalNavigationList(current.getParent(), propName);
    }

    private void initialize(final List<Resource> navigationList, final List<Resource> navigationSecondRowList) {
        if (CollectionUtils.isNotEmpty(navigationList)) {
            navigationList
                    .stream()
                    .filter(Objects::nonNull)
                    .map(resource -> resource.adaptTo(GlobalNavigationList.class))
                    .filter(Objects::nonNull)
                    .peek(navigationItem -> navigationItem.setLinkUrl(getUrl(navigationItem.getLinkUrl())))
                    .forEach(globalNavigation::add);
        }

        if (CollectionUtils.isNotEmpty(navigationSecondRowList)) {
            navigationSecondRowList
                    .stream()
                    .filter(Objects::nonNull)
                    .map(resource -> resource.adaptTo(GlobalNavigationList.class))
                    .filter(Objects::nonNull)
                    .peek(navigationItem -> navigationItem.setLinkUrl(getUrl(navigationItem.getLinkUrl())))
                    .forEach(globalNavigationSecondRow::add);
        }
    }

}
