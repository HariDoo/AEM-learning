package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.StringUtils;

/**
 * Represents a ContentDataEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class ContentDataEntity {
    private String path = StringUtils.EMPTY;
    private int order = 0;
    private String title;
    private String thumbnail;
    private String assetType;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String description;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String mobileImage;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String desktopImage;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String logoImage;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String configUrl;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String url;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMobileImage() {
        return mobileImage;
    }

    public void setMobileImage(String mobileImage) {
        this.mobileImage = mobileImage;
    }

    public String getDesktopImage() {
        return desktopImage;
    }

    public void setDesktopImage(String desktopImage) {
        this.desktopImage = desktopImage;
    }

    public String getLogoImage() {
        return logoImage;
    }

    public void setLogoImage(String logoImage) {
        this.logoImage = logoImage;
    }

    public String getConfigUrl() {
        return configUrl;
    }

    public void setConfigUrl(String configUrl) {
        this.configUrl = configUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
