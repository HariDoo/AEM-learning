package com.novo.core.framework.site.core.entity;

import com.google.gson.annotations.SerializedName;

/**
 * This is a public class called Data.
 * It has a private field called logoRequestEntity of type
 * @LogoRequestEntity
 *
 */
public class Data {

    /**
     * This line declares a private LogoRequestEntity
     * variable named logoRequestEntity
     */
    @SerializedName("data")
    private LogoRequestEntity logoRequestEntity;

    /**
     * This is a public method that returns the value of
     * logoRequestEntity.
     * @return LogoRequestEntity
     */
    public LogoRequestEntity getLogoRequestEntity() {
        return logoRequestEntity;
    }

    /**
     * This is a public method that sets the value of
     * logoRequestEntity.
     * It takes a parameter of type LogoRequestEntity
     *  and does not return anything.
     * @param logoRequestEntity
     */
    public void setLogoRequestEntity(LogoRequestEntity logoRequestEntity) {
        this.logoRequestEntity = logoRequestEntity;
    }
}
