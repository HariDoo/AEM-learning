package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents an organization details request entity,
 * which contains information about an organization's name,
 * department, customization name, address,
 * operational times, logo URL, published URL, and disease type.
 */
public class OrganizationDetailsRequestEntity {

    /**
     * The name of the organization associated with this object.
     * This field is serialized as "organizationName" in JSON format.
     * If the value of this field is null, it will not be included
     * in the serialized JSON output.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName("organizationName")
    private String organizationName = StringUtils.EMPTY;

    /**
     * The name of the department associated with this object.
     * This field is serialized as "department" in JSON format.
     * If the value of this field is null, it will not be included
     * in the serialized JSON output.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName("department")
    private String department = StringUtils.EMPTY;

    /**
     * The name of the customizationName associated with this object.
     * This field is serialized as "customizationName" in JSON format.
     * If the value of this field is null, it will not be included
     * in the serialized JSON output.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName("customizationName")
    private String customizationName = StringUtils.EMPTY;
    /**
     * Initialize phoneNumber to an empty string.
     */
    private String phoneNumber = StringUtils.EMPTY;

    /**
     * The address associated with this object.
     * The default value of this field is a new instance
     * of AddressRequestEntity.
     */
    private AddressRequestEntity address = new AddressRequestEntity();

    /**
     * The list of operational times associated with this object.
     * The default value of this field is an empty ArrayList of
     * OperationalTimeRequestEntity.
     */
    private List<OperationalTimeRequestEntity> operationalTimes = new ArrayList<>();
    /**
     * The logoUrl associated with this object.
     * This field is serialized as "logoUrl" in JSON format.
     * If the value of this field is null, it will not be included
     * in the serialized JSON output.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName("logoUrl")
    private String logoUrl = StringUtils.EMPTY;

    /**
     * Initialize publishedUrl to an empty string.
     */
    private String publishedUrl = StringUtils.EMPTY;

    /**
     * Initialize diseaseType to an empty string.
     */
    private String diseaseType = StringUtils.EMPTY;

    /**
     * Indicates whether this object is the default for the
     * cart it is associated with.
     * This field is serialized as "isDefaultForCart"
     * in JSON format.
     * The default value of this field is false.
     */
    @JsonProperty("isDefaultForCart")
    private Boolean isDefaultForCart = Boolean.FALSE;

    /**
     * Indicates whether this object is the default for the
     * cart it is associated with.
     * This field is serialized as "isDefaultCustomization"
     * in JSON format.
     * The default value of this field is false.
     */
    @JsonProperty("isDefaultCustomization")
    private Boolean isDefaultCustomization = Boolean.FALSE;

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getCustomizationName() {
        return customizationName;
    }

    public void setCustomizationName(String customizationName) {
        this.customizationName = customizationName;
    }

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public void setDiseaseType(String diseaseType) {
        this.diseaseType = diseaseType;
    }

    /**
     * Returns whether this object is the default
     * for its associated entity.
     * @return The value indicating whether
     * this object is the default for cart.
     */
    public Boolean getDefaultForCart() {
        return isDefaultForCart;
    }
    /**
     * Sets whether this object is the default for cart
     * for its associated entity.
     * @param defaultForCart The new value
     * indicating whether this object is the default cart.
     */
    public void setDefaultForCart(Boolean defaultForCart) {
        isDefaultForCart = defaultForCart;
    }

    /**
     * Returns whether this object is the default
     * customization for its associated entity.
     * @return The value indicating whether
     * this object is the default customization.
     */
    public Boolean getDefaultCustomization() {
        return isDefaultCustomization;
    }

    /**
     * Sets whether this object is the default customization
     * for its associated entity.
     * @param defaultCustomization The new value
     * indicating whether this object is the default customization.
     */
    public void setDefaultCustomization(Boolean defaultCustomization) {
        isDefaultCustomization = defaultCustomization;
    }

    public String getDiseaseType() {
        return diseaseType;
    }

    public List<OperationalTimeRequestEntity> getOperationalTimes() {
        return operationalTimes;
    }

    public void setOperationalTimes(List<OperationalTimeRequestEntity> operationalTimes) {
        this.operationalTimes = operationalTimes;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public AddressRequestEntity getAddress() { return address; }

    public void setAddress(AddressRequestEntity address) { this.address = address; }

    public String getPublishedUrl() {
        return publishedUrl;
    }

    public void setPublishedUrl(String publishedUrl) {
        this.publishedUrl = publishedUrl;
    }

    /**
     * Creates a copy of the given OrganizationDetailsRequestEntity object.
     * @param original the original object to be copied
     * @return a new instance of OrganizationDetailsRequestEntity
     * with the same data as the original object
     */

    public static OrganizationDetailsRequestEntity
    copyOf(OrganizationDetailsRequestEntity original) {
        return new OrganizationDetailsRequestEntity();
    }

}
