package com.novo.core.framework.site.core.services;
/**
 * Interface defining methods for interacting with the
 * RestService in .Net api layer
 */
public interface RestService {

    /**
     * Method to get, novo auth url
     *
     * @return {@link String} novo auth url
     */
    public String getRestNovoAuthUrl();

    /**
     * Method to get, base API url
     *
     * @return {@link String} base API url of .net
     */
    public String getRestAPIBaseUrl();


    /**
     * Method to get, update cart API url
     *
     * @return {@link String} update cart API url of .net
     */
    String getRestAPIUpdateCartAPIUrl();

    /**
     * Method to get, create cart API url
     *
     * @return {@link String} create cart API url of .net
     */
    public String getRestAPICreateCartAPIUrl();

    /**
     * Method to get, get cart API url
     *
     * @return {@link String} get cart API url of .net
     */
    public String getRestAPIGetCartAPIUrl();

    /**
     * Method to get, create cart content API url
     *
     * @return {@link String} create cart content API url of .net
     */
    public String getRestAPIPostCartContentAPIUrl();

    /**
     * Method to get, get cart content API url
     *
     * @return {@link String} get cart content API url of .net
     */
    public String getRestAPIGetCartContentAPIUrl();

    /**
     * Method to get, delete cart API url
     *
     * @return {@link String} delete cart API url of .net
     */
    public String getRestAPIDeleteCartAPIUrl();

    /**
     * Method to get, create organizations API url
     *
     * @return {@link String} create organization API url of .net
     */
    String getRestAPISubmitOrganization();

    /**
     * Method to get, create organization Details API url
     *
     * @return {@link String} organization details API url of .net
     */
    String getRestAPIGetOrganizationDetails();

    /**
     * Method to get, API auth key
     *
     * @return {@link String} API auth key of .net
     */
    public String getRestAPIAuthKey();
    /**
     * Returns the REST API URL for updating an organization.
     * @return the REST API URL for updating an organization
     */
    String getRestAPIUpdateOrganizationAPIUrl();

    /**
     * Method to get, publish url
     *
     * @return {@link String} publish url
     */
    public String getPublishUrl();

    /**
     * Method to get, service user name
     *
     * @return {@link String} service user
     */
    public String getServiceUser();
    /**
     * Returns the REST API URL for get a customization.
     * @return the REST API URL for get a customization
     */
    String getRestAPIGetCustomization();
}
