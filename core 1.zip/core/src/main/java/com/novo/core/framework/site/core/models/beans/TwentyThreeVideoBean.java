package com.novo.core.framework.site.core.models.beans;

public class TwentyThreeVideoBean {

    private String videoServer;
    private String videoIdProp;
    private String videoId;
    private String videoToken;
    private String treeId;
    private String title;
    private String description;
    private String duration;
    private String transcript;

    public String getVideoServer() {
        return videoServer;
    }

    public void setVideoServer(String videoServer) {
        this.videoServer = videoServer;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public String getTreeId() {
        return treeId;
    }

    public void setTreeId(String treeId) {
        this.treeId = treeId;
    }


    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getVideoToken() {
        return videoToken;
    }

    public void setVideoToken(String videoToken) {
        this.videoToken = videoToken;
    }

    public String getVideoIdProp() {
        return videoIdProp;
    }

    public void setVideoIdProp(String videoIdProp) {
        this.videoIdProp = videoIdProp;
    }

    public String getTranscript() {
        return transcript;
    }

    public void setTranscript(String transcript) {
        this.transcript = transcript;
    }
}
