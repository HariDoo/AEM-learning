package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import javax.inject.Inject;

@Model(adaptables = Resource.class)
public class FooterList {

    @Inject
    @Optional
    private String linkTitle;

    @Inject
    @Optional
    private String linkUrl;

    @Inject
    @Optional
    private String linkExitModal;

    public String getLinkTitle() {
        return linkTitle;
    }

    public void setLinkTitle(String linkTitle) {
        this.linkTitle = linkTitle;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getLinkExitModal() {
        return linkExitModal;
    }

    public void setLinkExitModal(String linkExitModal) {
        this.linkExitModal = linkExitModal;
    }
}
