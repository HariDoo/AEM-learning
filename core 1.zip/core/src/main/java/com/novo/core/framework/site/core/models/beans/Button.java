package com.novo.core.framework.site.core.models.beans;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class)
public class Button {
    @ValueMapValue
    private String buttonKey;
    @ValueMapValue
    private String ctaButtonValue;
    @ValueMapValue
    private String cardValue;

    public String getButtonKey() { return buttonKey; }

    public String getCtaButtonValue() { return ctaButtonValue;}

    public String getCardValue() { return cardValue;}


}
