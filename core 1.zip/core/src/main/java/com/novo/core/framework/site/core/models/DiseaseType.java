package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * Sling model to be used to map multi-field resource values by cart functionality
 *
 * @since 1.0
 * @version 1.0
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DiseaseType {

    @ValueMapValue
    private String diseaseTitle;
    @ValueMapValue
    private String diseaseDesktopImage;
    @ValueMapValue
    private String diseaseMobileImage;
    @ValueMapValue
    private String altText;
    @ValueMapValue
    private String buttonLabel;
    @ValueMapValue
    private String buttonCtaLink;
    @ValueMapValue
    private String diseaseTag;

    public String getDiseaseTitle() {
        return diseaseTitle;
    }

    public String getDiseaseDesktopImage() {
        return diseaseDesktopImage;
    }

    public String getDiseaseMobileImage() {
        return diseaseMobileImage;
    }

    public String getAltText() {
        return altText;
    }

    public String getButtonLabel() {
        return buttonLabel;
    }

    public String getButtonCtaLink() {
        return buttonCtaLink;
    }

    public String getDiseaseTag() { return diseaseTag; }

    public void setDiseaseTitle(String diseaseTitle) {
        this.diseaseTitle = diseaseTitle;
    }

    public void setDiseaseDesktopImage(String diseaseDesktopImage) {
        this.diseaseDesktopImage = diseaseDesktopImage;
    }

    public void setDiseaseMobileImage(String diseaseMobileImage) {
        this.diseaseMobileImage = diseaseMobileImage;
    }

    public void setAltText(String altText) {
        this.altText = altText;
    }

    public void setButtonLabel(String buttonLabel) {
        this.buttonLabel = buttonLabel;
    }

    public void setButtonCtaLink(String buttonCtaLink) {
        this.buttonCtaLink = buttonCtaLink;
    }

    public void setDiseaseTag(String diseaseTag) { this.diseaseTag = diseaseTag; }
}
