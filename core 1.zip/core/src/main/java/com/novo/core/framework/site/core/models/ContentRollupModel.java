package com.novo.core.framework.site.core.models;

import java.util.*;

import javax.annotation.PostConstruct;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.*;
import org.apache.sling.models.annotations.*;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;


@Model(adaptables = SlingHttpServletRequest.class)
public class ContentRollupModel {

    @Inject
    private Page currentPage;

    @Inject
    @Optional
    @Via("resource")
    private String parentPath;
    
    @Inject
    public String getParentPath() {
		return parentPath;
	}

	public void setParentPath(String parentPath) {
		this.parentPath = parentPath;
	}

	@Inject
    @Optional
    @Via("resource")
    private String[] parentTag;

	@Inject
    public String[] getParentTag() {
		return parentTag;
	}

	public void setParentTag(String[] parentTag) {
		this.parentTag = parentTag;
	}

	@Inject
    @Optional
    @Via("resource")
    private String[] secondaryTag;

    @Inject
    @Optional
    @Via("resource")
    private String[] teritiaryTag;

    @Inject
    @Optional
    @Via("resource")
    private List<Resource> categoryObjectList;

  

	public void setCategoryObjectList(List<Resource> categoryObjectList) {
		this.categoryObjectList = categoryObjectList;
	}
	
	@Inject
	public List<Resource> getCategoryObjectList() {
			return categoryObjectList;
		}

	@Inject
    @Optional
    @Via("resource")
    @Default(values = "buttons")
    private String filterStyle;
	
	@Inject
    public String getFilterStyle() {
		return filterStyle;
	}

	public void setFilterStyle(String filterStyle) {
		this.filterStyle = filterStyle;
	}

	@Inject
    @Optional
    @Via("resource")
    @Default(values="Select")
    private String primaryLabel;

    @Inject
    @Optional
    @Via("resource")
    @Default(values="Select")
    private String secondaryLabel;

    @Inject
    @Optional
    @Via("resource")
    @Default(values="Select")
    private String teritiaryLabel;

    @SlingObject
    private Resource currentResource;
    public Resource getCurrentResource() {
		return currentResource;
	}

	public void setCurrentResource(Resource currentResource) {
		this.currentResource = currentResource;
	}

	@SlingObject
    private ResourceResolver resourceResolver;

    public static class FilterItem{
        public FilterItem() {

        }


        public FilterItem(String path, String name) {
            this.path = path;
            this.name = name;
        }

        @Override
        public boolean equals(Object t) {
            boolean retVal = false;

            if (t instanceof FilterItem) {
                FilterItem ptr = (FilterItem) t;
                retVal = ptr.path.equals(this.path);
            }

            return retVal;
        }

        @Override
        public int hashCode() {
            return Objects.hash(path,name);
        }

        public String path;
        public String name;
    }

    public static class CardItem {
        public CardItem() {

        }

        public CardItem(String name, ArrayList<String> tagNames, ArrayList<String> tagPaths, String url, String description, String imgPath, String imgPathMobile, String thumbnailImage, String section, String mediaType, String mediaLink, String videoLink, Boolean hideDownloadLink, String linkOneLabel, String linkOnePath, String linkTwoLabel, String linkTwoPath, String linkOneTarget, String linkTwoTarget) {
            this.name = name;
            this.tagNames = tagNames;
            this.tagPaths = tagPaths;
            this.url = url;
            this.description = description;
            this.imgPath = imgPath;
            this.imgPathMobile = imgPathMobile;
            this.thumbnailImage = thumbnailImage;
            this.section = section;
            this.mediaType = mediaType;
            this.mediaLink = mediaLink;
            this.videoLink = videoLink;
            this.hideDownloadLink = hideDownloadLink;
            this.linkOneLabel = linkOneLabel;
            this.linkOnePath = linkOnePath;
            this.linkOneTarget = linkOneTarget;
            this.linkTwoLabel = linkTwoLabel;
            this.linkTwoPath = linkTwoPath;
            this.linkTwoTarget = linkTwoTarget;
        }

        public String name;
        public ArrayList<String> tagNames;
        public ArrayList<String> tagPaths;
        public String url;
        public String description;
        public String imgPath;
        public String imgPathMobile;
        public String thumbnailImage;
        public String section;
        public String mediaType;
        public String mediaLink;
        public String videoLink;
        public boolean downloadableLink;
        public boolean hideDownloadLink;
        public String linkOneLabel;
        public String linkOnePath;
        public String linkOneTarget;
        public String linkTwoLabel;
        public String linkTwoPath;
        public String linkTwoTarget;
    }

    public static class CardGroup {
        public CardGroup() {

        }

        public CardGroup(String groupName, String groupFilter, String groupHeading, ArrayList<CardItem> cardArray) {
            this.groupName = groupName;
            this.groupFilter = groupFilter;
            this.groupHeading = groupHeading;
            this.cardArray = cardArray;
        }

        public String groupName;
        public String groupFilter;
        public String groupHeading;
        public ArrayList<CardItem> cardArray = new ArrayList<CardItem>();
        public Integer cardArrayIndex = 0;

    }

    public ArrayList<FilterItem> filterList = new ArrayList<FilterItem>();
    public ArrayList<FilterItem> secondaryFilterList = new ArrayList<FilterItem>();
    public ArrayList<FilterItem> tertiaryFilterList = new ArrayList<FilterItem>();
    public ArrayList<String> groupTagList = new ArrayList<String> ();
    public ArrayList<String> groupHeadingList = new ArrayList<String> ();
    public ArrayList<FilterItem> categoryFilterList = new ArrayList<FilterItem>();
    public ArrayList<CardItem> cardsList = new ArrayList<CardItem>();
    public ArrayList<CardGroup> cardsGroup = new ArrayList<CardGroup>();
	public String diseaseTag;
    public String addToCartAlt;
    public String addToCartIcon;
    public String addToCartLabel;
    public String removeCartAlt;
    public String removeCartIcon;
    public String removeCartLabel;

    public TagManager tagManager;
    public Page homePage = null;

    Logger log = LoggerFactory.getLogger(this.getClass());

    @PostConstruct
    protected void init() {
        if (parentPath != null) {
            PageManager pageManager = resourceResolver.adaptTo(PageManager.class);
            homePage = pageManager.getPage(parentPath);
        } else {
            getTemplatePath(currentPage);
        }

        if (!ArrayUtils.isEmpty(parentTag)) {
            tagManager = resourceResolver.adaptTo(TagManager.class);
            filterList = createFilters(parentTag);
            if (filterStyle.equalsIgnoreCase("dropdowns")){
                if (!ArrayUtils.isEmpty(secondaryTag)) {
                    secondaryFilterList = createFilters(secondaryTag);
                }
                if (!ArrayUtils.isEmpty(teritiaryTag)) {
                    tertiaryFilterList = createFilters(teritiaryTag);
                }
            }

            String doSort = currentResource.getValueMap().get("filterAlphabetical", "false");

            if (doSort.equals("true")) {
                filterList = sortFilters(filterList);
                if (filterStyle.equalsIgnoreCase("dropdowns")){
                    secondaryFilterList = sortFilters(secondaryFilterList);
                    tertiaryFilterList = sortFilters(tertiaryFilterList);
                }
            }

            if (categoryObjectList != null) {
                if (!categoryObjectList.isEmpty()) {
                    for (Resource resource : categoryObjectList) {
                        ContentRollupCategoryListClass groupTag = resource.adaptTo(ContentRollupCategoryListClass.class);
                        groupTagList.add(groupTag.getGroupTag());
                        groupHeadingList.add(groupTag.getGroupHeading());
                    }
                    String[] groupTag = new String[categoryObjectList.size()];
                    groupTagList.toArray(groupTag);
                    categoryFilterList = createFilters(groupTag);
                }
            }

            if (homePage != null) {
                Iterator<Page> childPages = homePage.listChildren();
                ArrayList<FilterItem> totalList = new ArrayList<FilterItem>();
                totalList.addAll(filterList);
                if (!secondaryFilterList.isEmpty()){
                    //find better way to pass down iterator
                    totalList.addAll(secondaryFilterList);
                }
                if (!tertiaryFilterList.isEmpty()){
                    totalList.addAll(tertiaryFilterList);
                }
                if (!categoryFilterList.isEmpty()){
                    totalList.addAll(categoryFilterList);
                }

                getChildValues(childPages, totalList);

                if (doSort.equals("true")) {
                    cardsList = sortCards();
                }

                cardsGroup = categorizeCards(cardsList);

            } else {
                log.error("No parent page found.");
            }
        } else {
            log.error("'parentTag' property from the resource is empty.");
        }
    }

    protected ArrayList<FilterItem> sortFilters(ArrayList<FilterItem> tagList) {
        ArrayList<FilterItem> sortedFilters = tagList;

        Collections.sort(sortedFilters, new Comparator<FilterItem>() {
            @Override
            public int compare(FilterItem d1, FilterItem d2) {
                return d1.name.compareToIgnoreCase(d2.name);
            }
        });
        return sortedFilters;
    }

    protected ArrayList<CardItem> sortCards() {
        ArrayList<CardItem> sortedCards = cardsList;

        Collections.sort(sortedCards, new Comparator<CardItem>() {
            @Override
            public int compare(CardItem d1, CardItem d2) {
                return d1.name.compareToIgnoreCase(d2.name);
            }
        });
        return sortedCards;
    }

    public ArrayList<CardGroup> categorizeCards(ArrayList<CardItem> cards){
        ArrayList<CardGroup> groups = new ArrayList<CardGroup>();

        if (!categoryFilterList.isEmpty() && filterStyle.equalsIgnoreCase("dropdowns")){
            ArrayList<FilterItem> categoryList = new ArrayList<FilterItem>();
            if (!categoryFilterList.isEmpty()){
                categoryList = categoryFilterList;
            }

            if (categoryList.size() > 0){
                for (int i = 0; i < categoryList.size(); i ++){
                    CardGroup g = new CardGroup();
                    g.groupName = categoryList.get(i).name;
                    g.groupFilter = categoryList.get(i).path;
                    g.groupHeading = groupHeadingList.get(i);
                    groups.add(g);
                }
                for (CardItem c : cards) {
                    for (CardGroup g : groups){
                        if (c.tagNames.contains(g.groupName)) {
                            g.cardArray.add(c);
                        }
                    }
                }
                return groups;
            }

        }

        CardGroup g = new CardGroup("", "", "", cards);
        groups.add(g);
        return groups;
    }

    public void getTemplatePath(Page p) {
        try {
            if (p != null) {
                ValueMap props = p.getProperties();
                String templateType = props.get("sling:resourceType", StringUtils.EMPTY);
                if (templateType.contains("novo-home")) {
                    homePage = p;
                } else {
                    getTemplatePath(p.getParent());
                }
            }
        } catch (Exception ex) {
            log.error("Page value was null while trying to find the template path of the home page.");
        }
    }

    public void getChildValues(Iterator<Page> iterator, ArrayList<FilterItem> tagList) {
        try {
            while (iterator.hasNext()) {
                Page res = iterator.next();
                ValueMap map = res.getProperties();
                String templateType = map.get("sling:resourceType", StringUtils.EMPTY);
                if (templateType.contains("novo-content-rollup")) {
                    try {
                        String[] s = map.get("cq:tags", String[].class);

                        CardItem card = new CardItem();
                        ArrayList<String> tagNames = new ArrayList<String>();
                        ArrayList<String> tagPaths = new ArrayList<String>();

                        if (s.length > 0) {
                            for (String a : s) {
                                FilterItem t = new FilterItem();
                                t.path = a.replace(':', '/');
                                int i = tagList.indexOf(t);
                                if (i > -1) {
                                    tagNames.add(tagList.get(i).name);
                                    tagPaths.add(t.path);
                                }
                            }
                        }

                        if (!tagNames.isEmpty()) {
                            card.name = res.getTitle();
                            card.tagNames = tagNames;
                            card.tagPaths = tagPaths;
                            card.url = res.getPath();
                            card.description = map.get("rollupDescription", StringUtils.EMPTY);
                            card.imgPath = map.get("rollupImage", StringUtils.EMPTY);
                            card.imgPathMobile = map.get("rollupImageMobile", StringUtils.EMPTY);
                            card.thumbnailImage = map.get("thumbnailImage", StringUtils.EMPTY);
                            card.section = map.get("sectionTitle", StringUtils.EMPTY);
                            card.mediaType = map.get("rollupMedia", StringUtils.EMPTY);
                            card.mediaLink = map.get("rollupDownload", StringUtils.EMPTY);
                            card.downloadableLink = StringUtils.equals(card.mediaType, "Asset") && !StringUtils.endsWithAny(card.mediaLink, new String[]{".pdf", ".PDF"});
                            card.videoLink = map.get("rollupVideo", StringUtils.EMPTY);
                            card.hideDownloadLink = map.get("hideDownloadLink", Boolean.FALSE);
                            card.linkOneLabel = map.get("linkOneLabel", StringUtils.EMPTY);
                            card.linkOnePath = map.get("linkOnePath", StringUtils.EMPTY);
                            card.linkOneTarget = map.get("linkOneTarget", StringUtils.EMPTY);
                            card.linkTwoLabel = map.get("linkTwoLabel", StringUtils.EMPTY);
                            card.linkTwoPath = map.get("linkTwoPath", StringUtils.EMPTY);
                            card.linkTwoTarget = map.get("linkTwoTarget", StringUtils.EMPTY);
                            
                            cardsList.add(card);
                        }
                        // asset download path for videos/images/pdfs

                    } catch (Exception ex) {
                        log.error("Unable to retrieve the values of a content rollup page");
                    }
                }

                // Check the resource's children for additional entries
                try {
                    getChildValues(res.listChildren(),tagList);
                } catch (Exception ex) {
                    log.error("Unable to retrieve children of current page while looking for content rollup pages");
                }
            }

        } catch (Exception ex) {
            log.error(ex.getMessage());
        }
    }

    public ArrayList<FilterItem> createFilters(String[] tagList) {
        ArrayList<FilterItem> list = new ArrayList<FilterItem>();
        for (String s : tagList) {
            FilterItem t = new FilterItem();
            Tag tag = tagManager.resolve(s);
            t.path = s.replace(':', '/');
            t.name = "null";
            if (tag != null) {
                t.name = tag.getTitle();
            }
            list.add(t);
        }

        return list;

    }

    public ArrayList<FilterItem> getFilters() {
        return filterList;
    }

    public ArrayList<FilterItem> getSecondaryFilters() {
        return secondaryFilterList;
    }

    public ArrayList<FilterItem> getTertiaryFilters() {
        return tertiaryFilterList;
    }

	public String getDiseaseTag() {
		ValueMap props = currentPage.getProperties();
		String tagProperty = props.get("diseaseTag", StringUtils.EMPTY);
		Tag  tag= tagManager.resolve(tagProperty);
		return diseaseTag= tag.getName();
	}

    public String getAddToCartAlt() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return addToCartAlt= props.get("addToCartAlt", StringUtils.EMPTY);
    }

    public String getAddToCartIcon() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return addToCartIcon= props.get("addToCartIcon", StringUtils.EMPTY);
    }

    public String getAddToCartLabel() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return addToCartLabel= props.get("addToCartLabel", StringUtils.EMPTY);
    }

    public String getRemoveCartLabel() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return removeCartLabel= props.get("removeCartLabel", StringUtils.EMPTY);
    }

    public String getRemoveCartAlt() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return removeCartAlt= props.get("removeCartAlt", StringUtils.EMPTY);
    }

    public String getRemoveCartIcon() {
    	ValueMap props = currentResource.adaptTo(ValueMap.class);
		return removeCartIcon= props.get("removeCartIcon", StringUtils.EMPTY);
    }

    public ArrayList<CardGroup> getCards() {
        Integer count = 0;
        for (CardGroup g : cardsGroup){
            g.cardArrayIndex = count;
            count = count + g.cardArray.size();
        }
        return cardsGroup;
    }

    public String getPrimaryLabel() {
        return primaryLabel;
    }

    public String getSecondaryLabel() {
        return secondaryLabel;
    }

    public String getTeritiaryLabel() {
        return teritiaryLabel;
    }

    public boolean getValid(){
        if (homePage != null){
            return true;
        }

        return false;
    }

}
