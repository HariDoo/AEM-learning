package com.novo.core.framework.site.core.services;

import com.google.gson.JsonObject;

public interface TwentyThreeVideoService {

 JsonObject getTwentyThreeVideoObject(String videoId, String videoServer);
 String getTwentyThreeVideoHost();

}
