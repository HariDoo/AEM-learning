package com.novo.core.framework.site.core.models;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageFilter;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * @author klick
 *
 */
public class QuickLinks extends WCMUsePojo {

    private Page HomePage = null;

    private String defaultParentPath;

    private static final Logger LOGGER = LoggerFactory.getLogger(QuickLinks.class);
    private List<Map<String, Object>> items;

    public List<Map<String, Object>> getItems() {
        return items;
    }

    @Override
    public void activate() throws Exception {
        getHomePage(getCurrentPage());
        if(HomePage == null){
            defaultParentPath = getResource().getValueMap().get("parentPagePath", String.class);
            if(defaultParentPath != null && StringUtils.isNotBlank(defaultParentPath)){
                Page defaultParentPage =  getPageManager().getPage(defaultParentPath);
                getHomePage(defaultParentPage);
            }
        }

        loadContent();
    }

    public void getHomePage(Page parent) {
        if (parent != null) {
            ValueMap props = parent.getProperties();
            String templateType = props.get("sling:resourceType", StringUtils.EMPTY);
            if (templateType.contains("novo-home")) {
                HomePage = parent;
            } else {
                getHomePage(parent.getParent());
            }
        }
    }

    private void loadContent() {
        items = new ArrayList<>();
        Page page = HomePage;
        if (page != null) {
            Iterator<Page> ip = page.listChildren(new PageFilter(), false);
            while(ip.hasNext()) {
                Page child = ip.next();
                addPageToList(child, true);
            }
        }
    }

	private void addPageToList(Page page, Boolean includeChildren) {
		if (page.getContentResource() != null) {
			ValueMap valueMap = page.getContentResource().getValueMap();

			Boolean sectionTitles = getResource().getValueMap().get("useSectionTitles", false);

			Map<String, Object> item = new HashMap<>();
			Boolean hidden = valueMap.get("hideInNav", false);
			if (!hidden) {
				// fetch children
				List<Map<String, String>> children = new ArrayList<>();
				Map<String, String> obj = new HashMap<>();

				if (sectionTitles) {
					item.put("title", valueMap.get("sectionTitle", valueMap.get("jcr:title", StringUtils.EMPTY)));
				} else {
					item.put("title", valueMap.get("jcr:title", StringUtils.EMPTY));
				}

				item.put("url", page.getPath());
				item.put("link", page.getPath() + ".html");

				if (sectionTitles || !includeChildren) {
					obj.put("title", valueMap.get("jcr:title", StringUtils.EMPTY));
					obj.put("url", page.getPath());
					obj.put("link", page.getPath() + ".html");
					children.add(obj);
				}

				getIncludedChild(page, includeChildren, children);

				item.put("children", children);
				items.add(item);
			}
		}
	}

	private void getIncludedChild(Page page, Boolean includeChildren, List<Map<String, String>> children) {
		Map<String, String> obj;
		if (includeChildren) {
			Iterator<Page> childPages = page.listChildren();
			while (childPages.hasNext()) {
				Page childPage = childPages.next();
				if (childPage.getContentResource() != null) {
					ValueMap childMap = childPage.getContentResource().getValueMap();
					Boolean childHidden = childMap.get("hideInNav", false);
					if (!childHidden) {
						obj = new HashMap<>();
						obj.put("title", childPage.getTitle());
						obj.put("url", childPage.getPath());
						obj.put("link", childPage.getPath() + ".html");
						children.add(obj);
					}
				}
			}
		}
	}

    public String getPage(){
        return HomePage.getTitle();
    }

}
