package com.novo.core.framework.site.core.models;

import com.google.gson.Gson;
import com.novo.core.framework.site.core.services.LogoConfigService;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Model to be used to fetch the content from
 * components multi field node structure
 *
 * @since 1.0
 * @version 1.0
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CustomizationsModel {
    /**
     * This field represents the operational days of
     * the resource.
     * It is used to determine when the resource is
     * available for use.
     */
    @ChildResource
    private final transient  Resource operationalDays;

    /**
     * This field represents the state names of
     * the resource.
     */
    @ChildResource
    private final transient  Resource stateNames;

    @OSGiService
    private LogoConfigService logoConfigService;
    /**
     * This field stores a list of customizations
     */
    private  List<Customizations> customizationsList = new ArrayList<>();


    /**
     * This field is used to store the stateNames.
     */
    private  List<StateNamesEntity> stateNamesList = new ArrayList<>();
    /**
     *Add getter and setter methods for the comments field.
     */
    public CustomizationsModel() {
        operationalDays = null;
        stateNames = null;
    }
    /**
     * This field stores a list of customizations
     */


    public List<Customizations> getCustomizationsList() {
        return customizationsList;
    }

    public List<StateNamesEntity> getStateNamesList() {
        return stateNamesList;
    }

    private String formats = StringUtils.EMPTY;
    private Integer fieSize;

    public String getFormats() {
        return formats;
    }

    public Integer getFieSize() {
        return fieSize;
    }

    /**
     * Initializes the customizations list based on
     * the operational days' resource.
     */
    @PostConstruct
    protected void init() {
        formats = new Gson().toJson(logoConfigService.getFileFormat());
        fieSize = Integer.valueOf(new Gson().toJson(logoConfigService.getFileSize()));
        if (operationalDays != null && operationalDays.hasChildren()) {
            for (final Resource resource : operationalDays.getChildren()
            ) {
                if (resource != null) {
                    final Customizations customizations = resource.adaptTo(Customizations.class);
                    customizationsList.add(customizations);
                }
            }
        }

        if (stateNames != null && stateNames.hasChildren()) {
            for (final Resource resource1 : stateNames.getChildren()
            ) {
                if (resource1 != null) {
                    final StateNamesEntity stateNamesEntity = resource1.adaptTo(StateNamesEntity.class);
                    stateNamesList.add(stateNamesEntity);
                }
            }
        }
    }
}
