@Version("1.0")
package com.novo.core.framework.site.core.filters;

import org.osgi.annotation.versioning.Version;