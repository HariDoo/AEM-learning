package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.StringUtils;

/**
 * This class represents an organization entity and contains
 * information about the organization such as the ID,
 * customization name, and whether it is the default
 * organization.
 */
public class OrganizationsEntity {

    /**
     * This field represents the name of the customization.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String customizationName  = StringUtils.EMPTY;

    /**
     * This field represents the id of the organization.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer organizationId;

    /**
     * Indicates whether this object is the default.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("IsDefault")
    private Boolean isDefault;

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getCustomizationName() {
        return customizationName;
    }

    public void setCustomizationName(String customizationName) {
        this.customizationName = customizationName;
    }

}
