package com.novo.core.framework.site.core.entity;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * Represents a LogoRequestEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class LogoRequestEntity {
    /**
     * Include non-null values in JSON serialization and
     * initialize authToken to an empty string.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String authToken = StringUtils.EMPTY;
    /**
     * Initialize imageName to an empty string.
     */
    private String imageName  = StringUtils.EMPTY;

    /**
     * Initialize redirectUrl to an empty string.
     */
    private String redirectUrl  = StringUtils.EMPTY;
    /**
     * Initialize logo64bitString to an empty string.
     */
    private String logo64bitString  = StringUtils.EMPTY;
    /**
     * Initialize organizationId to an empty string.
     */
    private String organizationId = StringUtils.EMPTY;
    /**
     * Initialize fileDescription to an empty string.
     */
    private String fileDescription  = StringUtils.EMPTY;

    /**
     * Returns the authentication token associated with
     * this object.
     * @return The authentication token.
     */
    public String getAuthToken() {
        return authToken;
    }

    /**
     * Sets the authentication token associated with
     * this object.
     * @param authToken The new authentication token
     * to associate with the object.
     */
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
    /**
     * Returns the fileName associated with
     * this object.
     * @return The file name.
     */
    public String getFilename() {
        return imageName;
    }
    /**
     * Sets the file name associated with
     * this object.
     * @param imageName The new file name
     * to associate with the object.
     */
    public void setFilename(String imageName) {
        this.imageName = imageName;
    }
    /**
     * Returns the redirectUrl associated with
     * this object.
     * @return The redirect url.
     */
    public String getRedirectUrl() {
        return redirectUrl;
    }
    /**
     * Sets the redirect url associated with
     * this object.
     * @param redirectUrl The new redirect url
     * to associate with the object.
     */
    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    /**
     * Returns the logo64bitString associated with
     * this object.
     * @return The logo64bit String.
     */
    public String getBase64Image() {
        return logo64bitString;
    }

    /**
     * Sets the logo64bitString associated with
     * this object.
     * @param logo64bitString The new logo64bitString
     * to associate with the object.
     */
    public void setBase64Image(String logo64bitString) {
        this.logo64bitString = logo64bitString;
    }

    public String getFileDescription() {
        return fileDescription;
    }

    public void setFileDescription(String fileDescription) {
        this.fileDescription = fileDescription;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public AddressRequestEntity getAddressRequestEntity() {
        return addressRequestEntity;
    }

    public void setAddressRequestEntity(AddressRequestEntity addressRequestEntity) {
        this.addressRequestEntity = addressRequestEntity;
    }

    public String getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    public List<OperationalTimeRequestEntity> getOperationalTimeRequestEntityList() {
        return operationalTimeRequestEntityList;
    }

    public void setOperationalTimeRequestEntityList(List<OperationalTimeRequestEntity> operationalTimeRequestEntityList) {
        this.operationalTimeRequestEntityList = operationalTimeRequestEntityList;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCustomizationName() {
        return customizationName;
    }

    public void setCustomizationName(String customizationName) {
        this.customizationName = customizationName;
    }

    /**
     * Returns the boolean associated with
     * this object.
     * @return The boolean for IsDefaultCustomization.
     */
    public Boolean getDefaultCustomization() {
        return isDefaultCustomization;
    }

    /**
     * Sets the boolean associated with
     * this object.
     * @param defaultCustomization The new boolean
     * to associate with the object.
     */
    public void setDefaultCustomization(Boolean defaultCustomization) {
        isDefaultCustomization = defaultCustomization;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * Initialize organizationName to an empty string.
     */
    private String organizationName = StringUtils.EMPTY;
    /**
     * Initialize department to an empty string.
     */
    private String department = StringUtils.EMPTY;
    /**
     * This field represents the request entity of the address.
     */
    @SerializedName("address")
    private AddressRequestEntity addressRequestEntity;
    /**
     * This field represents the list of operationTimes
     * request entity
     */
    @SerializedName("operationaTimes")
    private List<OperationalTimeRequestEntity> operationalTimeRequestEntityList;
    /**
     * Initialize phoneNumber to an empty string.
     */
    private String phoneNumber = StringUtils.EMPTY;
    /**
     * Initialize customizationName to an empty string.
     */
    private String customizationName = StringUtils.EMPTY;
    /**
     * Initialize IsDefaultCustomization to a boolean.
     */
    private Boolean isDefaultCustomization;

    /**
     * Initialize userId to a long type.
     */
    private Long userId;

}
