package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.commons.lang3.StringUtils;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Model(adaptables = Resource.class)
public class HreflangList {

    @Inject
    @Optional
    private List<Resource> hreflangFields;

    public ArrayList<HreflangListClass> hreflangCodes = new ArrayList<HreflangListClass> ();

    @PostConstruct
    protected void init() {
    	if (hreflangFields != null && !hreflangFields.isEmpty()) {
            for (Resource resource : hreflangFields) {
                HreflangListClass hreflangCode = resource.adaptTo(HreflangListClass.class);
                hreflangCodes.add(hreflangCode);
            }
    	}
    }

    public ArrayList<HreflangListClass> getHreflangList() {
        return hreflangCodes;
    }

}

