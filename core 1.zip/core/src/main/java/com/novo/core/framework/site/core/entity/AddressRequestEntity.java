package com.novo.core.framework.site.core.entity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang3.StringUtils;

/**
 * Represents a request for an address,
 * with fields for address line 1, address line 2, city, state,
 * and postal code.
 *
 * It provides a simple and flexible way to represent
 * address requests in Java code.
 */
public class AddressRequestEntity {

    /**
     * The first line of the address.
     */
    private String addressLine1 = StringUtils.EMPTY;
    /**
     * The second line of the address.
     */
    private String addressLine2 = StringUtils.EMPTY;
    /**
     * The city of the address.
     */
    private String city  = StringUtils.EMPTY;
    /**
     * The state of the address.
     */
    private String state = StringUtils.EMPTY;
    /**
     * The postal code of the address.
     */
    @SerializedName("pincode")
    @JsonProperty("pincode")
    private String pinCode =  StringUtils.EMPTY;

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }
}
