package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang3.StringUtils;

/**
 * Represents a CartRequestEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class CartRequestEntity {
    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String authToken = StringUtils.EMPTY;
    private String diseaseType = StringUtils.EMPTY;
    /**
     * This field is used to represent the identifier of
     * an organization in the application's data model.
     */
    private String organizationId = StringUtils.EMPTY;

    private int maxCount =0;
    private String cartName = StringUtils.EMPTY;

    /**
     * This field is used to represent the identifier of
     * a cart in the application's data model.
     */
    private Integer cartId;
    private long userId =0L;

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getDiseaseType() {
        return diseaseType;
    }

    public void setDiseaseType(String diseaseType) {
        this.diseaseType = diseaseType;
    }

    public String getCartName() {
        return cartName;
    }

    public void setCartName(String cartName) {
        this.cartName = cartName;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public void setMaxCount(int maxCount) {
        this.maxCount = maxCount;
    }

    public String getOrganizationId() { return organizationId; }

    public void setOrganizationId(String organizationId) { this.organizationId = organizationId; }
}
