package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

/**
 * Sling model to be used to map multi-field resource values by cart functionality
 *
 * @since 1.0
 * @version 1.0
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class Customizations {
    /**
     *Day name of the week
     */
    @ValueMapValue
    private String dayName;
    /**
     *Label for "from" time
     */
    @ValueMapValue
    private String fromLabel;
    /**
     *Label for "to" time
     */
    @ValueMapValue
    private String toLabel;
    /**
     *Label for "pm" time
     */
    @ValueMapValue
    private String pmLabel;
    /**
     *Label for "am" time
     */
    @ValueMapValue
    private String amLabel;

    public String getPmLabel() { return pmLabel; }

    public void setPmLabel(String pmLabel) { this.pmLabel = pmLabel; }

    public String getAmLabel() { return amLabel; }

    public void setAmLabel(String amLabel) { this.amLabel = amLabel; }

    public String getDayName() {
        return dayName;
    }

    public void setDayName(String dayName) {
        this.dayName = dayName;
    }

    public String getFromLabel() {
        return fromLabel;
    }

    public void setFromLabel(String fromLabel) {
        this.fromLabel = fromLabel;
    }

    public String getToLabel() {
        return toLabel;
    }

    public void setToLabel(String toLabel) {
        this.toLabel = toLabel;
    }

}
