package com.novo.core.framework.site.core.services.impl;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.AddressRequestEntity;
import com.novo.core.framework.site.core.entity.OrganizationDetailsRequestEntity;
import com.novo.core.framework.site.core.entity.Profile;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.MailSenderService;
import com.novo.core.framework.site.core.services.RestService;
import com.novo.core.framework.site.core.services.ServletAPIUrlsService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Mail sender service impl that implements {@link MailSenderService}
 * provide mailer implementation for  <b>Education Center</b>
 * <p>
 * check the component and designate annotations for defining service
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = MailSenderService.class)
@Designate(ocd = MailSenderServiceImpl.MailConfiguration.class)
public class MailSenderServiceImpl implements MailSenderService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MailSenderServiceImpl.class);

    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private RestService restService;

    @Reference
    private ServletAPIUrlsService servletAPIUrlsService;

    @Reference
    private MessageGatewayService messageGatewayService;

    @Reference
    private ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    private String mailerSendFrom = StringUtils.EMPTY;
    private String mailerSubject = StringUtils.EMPTY;
    private String mailerTemplate = StringUtils.EMPTY;
    private boolean mailerEnabledFlag = Boolean.FALSE;

    @Override
    public boolean isMailerEnabledFlag() {
        return mailerEnabledFlag;
    }

    @Activate
    @Modified
    protected void activate(final MailConfiguration config) {
        mailerSendFrom = config.mailerSendFromConfig();
        mailerSubject = config.mailerSubjectConfig();
        mailerTemplate = config.mailerTemplateConfig();
        mailerEnabledFlag = config.mailerEnabledFlag();

        LOGGER.debug("MailSenderService Activate() contentdistribution mailer configuration sendFrom : {}", mailerSendFrom);
        LOGGER.debug("MailSenderService Activate() contentdistribution mailer configuration subject : {}", mailerSubject);
        LOGGER.debug("MailSenderService Activate() contentdistribution mailer configuration template : {}", mailerTemplate);
        LOGGER.debug("MailSenderService Activate() contentdistribution mailer configuration flag : {}", mailerEnabledFlag);
    }

    /**
     * Method send mail using email content string
     *
     * @param sendTo      String of email ID to which the mail is to be sent
     * @param body        {@link String} the body of the mail
     * @param emailParams {@link Map} Map of keys to value pair that are to be replaced in the given body. Ex: if the body contains the
     *                    place holder like ${fname}, the ${fname} will be replaced with value of the 'fname' key in map. Null in case no place
     *                    holders are to be replaced
     * @return
     */
    @Override
    public boolean sendMailWithEmailString(String sendTo, String body, Map<String, String> emailParams) {
        boolean isMailSent = false;
        try {
            if (null != sendTo && null != body) {
                MessageGateway<Email> messageGateway;
                HtmlEmail email = new HtmlEmail();

                email.setCharset(CommonConstants.UTF_8_ENCODING);

                if (null != emailParams)
                    body = StrSubstitutor.replace(body, emailParams);
                email.setHtmlMsg(body);

                List<InternetAddress> emailToList = new ArrayList<>();
                InternetAddress internetAddress = new InternetAddress(sendTo);
                emailToList.add(internetAddress);
                email.setTo(emailToList);

                if (StringUtils.isNotBlank(mailerSubject))
                    email.setSubject(mailerSubject);

                if (StringUtils.isNotBlank(mailerSendFrom))
                    email.setFrom(mailerSendFrom);

                messageGateway = messageGatewayService.getGateway(Email.class);
                messageGateway.send(email);
                isMailSent = true;
            } else {
                LOGGER.info(
                        "MailSenderService : sendMailWithEmailString() : Email not sent! Either sendTo is null or body is null or sendTo list is empty");
            }
        } catch (AddressException addressException) {
            LOGGER.info(
                    "MailSenderService : sendMailWithEmailString() : Exception occured while creating address from sendTo Array : {0}",
                    addressException);
        } catch (EmailException emailException) {
            LOGGER.info("MailSenderService : sendMailWithEmailString() : Exception occured while sending mail : {0}",
                    emailException);
        }
        return isMailSent;
    }

    /**
     * Method to map {@link Profile} with the email HTML template
     *
     * @param profile {@link Profile} the profile object for the mail
     * @return
     */
    @Override
    public boolean sendMailWithEmailTemplate(Profile profile, String host, OrganizationDetailsRequestEntity organizationDetailsRequest) throws CartServletException {
        boolean isMailSent = false;
        try{
            ResourceResolver resourceResolver = null;
            resourceResolver = CartUtils.getResourceResolver(resourceResolverFactory, restService.getServiceUser());
            if (resourceResolver == null)
                throw new CartServletException(false, contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.CREATE_CART_CONTENT_NULL_RESOLVER), HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            String body = CartUtils.getStringFromNodePath(mailerTemplate, resourceResolver.adaptTo(Session.class));
            final ObjectMapper mapper = new ObjectMapper();

            final Map<String, String> props = mapper.convertValue(profile, Map.class);
            props.put("host" , host);
            props.put("publishPageUrl", profile.getPublishUrl());
            props.put("logoImage", restService.getRestAPIBaseUrl()+organizationDetailsRequest.getLogoUrl());
            props.put("redirectUrl", organizationDetailsRequest.getPublishedUrl());
            props.put("organizationName", organizationDetailsRequest.getOrganizationName());
            props.put("department", organizationDetailsRequest.getDepartment());
            props.put("phoneNumber", organizationDetailsRequest.getPhoneNumber());
            final AddressRequestEntity address = organizationDetailsRequest.getAddress();
            props.put("addressLine1",address.getAddressLine1());
            props.put("addressLine2",address.getAddressLine2());
            props.put("state",address.getState());
            props.put("city",address.getCity());
            props.put("pinCode",address.getPinCode());
            if(organizationDetailsRequest.getOperationalTimes()!= null && organizationDetailsRequest.getOperationalTimes().size() > 0 ) {
                final String operationalTimes = organizationDetailsRequest.getOperationalTimes().stream()
                        .map(entity -> entity.getDay() + ":" + entity.getFrom() + "-" + entity.getTo())
                        .collect(Collectors.joining(","));
                props.put("operationalTimes", operationalTimes);
            }
            else {
                props.put("operationalTimes", "");
            }
            isMailSent = sendMailWithEmailString(profile.getEmail(), body, props);
            if (isMailSent) {             
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.info("Email sent successfully to: {}", profile.getEmail());
                }
            } else {
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.warn("Failed to send email to: {}", profile.getEmail());
                }
            }
            resourceResolver.close();
        }catch (Exception ex){
            LOGGER.info("MailSenderService : sendMailWithEmailTemplate() : Exception occured while sending mail : {0}", ex);
        }
        return isMailSent;
    }

    @ObjectClassDefinition(name = "Content Distribution Mail Configuration")
    public @interface MailConfiguration {

        /**
         * Attribute definition for mail send from address
         *
         * @return
         */
        @AttributeDefinition(
                name = "Mailer send from address",
                description = "Mailer send from address"
        )
        String mailerSendFromConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for Mailer subject
         *
         * @return
         */
        @AttributeDefinition(
                name = "Mailer subject",
                description = "Mailer subject"
        )
        String mailerSubjectConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for mailer template
         *
         * @return
         */
        @AttributeDefinition(
                name = "Mailer template path",
                description = "Mailer template path"
        )
        String mailerTemplateConfig() default StringUtils.EMPTY;

        /**
         * Attribute definition for mailer enabled flag
         *
         * @return
         */
        @AttributeDefinition(
                name = "Mailer enabled flag",
                description = "Mailer enabled flag"
        )
        boolean mailerEnabledFlag() default false;
    }
}
