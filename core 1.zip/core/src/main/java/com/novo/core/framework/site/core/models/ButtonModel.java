package com.novo.core.framework.site.core.models;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ButtonModel {

    @Inject
    private Resource file;
    @Inject
    private String ctaLink;
    @Inject
    private String backgroundColor;
    @Inject
    private String cssClassName;
    @Inject
    private String description;
    @Inject
    private boolean showArrowIcon;
    @Inject
    private Resource arrowIcon;
    @Inject
    private String openChat;
    @Inject
    private String hoverFontColor;
    @Inject
    private String hoverBackgroundColor;
    @Inject
    private String hoverDescription;
    @Inject
    private String arrowIconAltText;
    @Inject
    private String dropIconAltText;
    /**
     * flag indicating if the side image is for decorative purposes
     */
    @Inject
    @Default(booleanValues = false)
    private boolean sideImageIsDecorative;
    /**
     * flag indicating if the arrow image is for decorative purposes
     */
    @Inject
    @Default(booleanValues = false)
    private boolean arrowIconIsDecorative;

    private String imageSrc;
    private String iconSrc;

    @PostConstruct
    protected void init() {
        final Node image = file.adaptTo(Node.class);

        if (image != null) {
            try {
                imageSrc = image.getProperty("fileReference").getValue().toString();
            } catch (final Exception e) {
                System.out.println(e.getMessage());
            }
        }

        final Node icon = arrowIcon.adaptTo(Node.class);

        if (icon != null) {
            try {
                iconSrc = icon.getProperty("arrowIconReference").getValue().toString();
            } catch (final Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public String getFile() {
        return imageSrc;
    }

    public String getIcon() {
        return iconSrc;
    }

    public String getCtaLink() {
        return ctaLink;
    }

    public String getCssClassName() {
        return cssClassName;
    }

    public String getDescription() {
        return description;
    }

    public String getBackgroundColor() {
        String style = "";

        if (StringUtils.isNotEmpty(backgroundColor)) {
            style = "background-color: " + backgroundColor + ";";
        }

        return style;
    }

    public boolean getShowArrowIcon() {
        return showArrowIcon;
    }

    public String getOpenChat() {
        return openChat;
    }

    public String getHoverFontColor() {
        return hoverFontColor;
    }

    public String getHoverBackgroundColor() {
        return hoverBackgroundColor;
    }

    public String getHoverDescription() {
        return hoverDescription;
    }

    public String getArrowIconAltText() { return arrowIconAltText; }

    public String getDropIconAltText() { return dropIconAltText; }

    /**
     * Returns a boolean value to indicate if the side image is decorative
     * @return true/false value for the side image property
     */
    public boolean isSideImageDecorative() { return sideImageIsDecorative; }

    /**
     * Returns a boolean value to indicate if the arrow image is decorative
     * @return true/false value for the arrow image property
     */
    public boolean isArrowIconDecorative() { return arrowIconIsDecorative; }

    public String getHoverStyle() {
        return getHoverTextStyle() + getHoverBackgroundStyle();
    }

    public String getHoverTextStyle() {
        String style = "";

        if (StringUtils.isNotEmpty(hoverFontColor)) {
            style = "color: " + hoverFontColor + ";";
        }

        return style;
    }

    public String getHoverBackgroundStyle() {
        String style = "";

        if (StringUtils.isNotEmpty(hoverBackgroundColor)) {
            style = "background-color: " + hoverBackgroundColor + ";";
        }

        return style;
    }
}
