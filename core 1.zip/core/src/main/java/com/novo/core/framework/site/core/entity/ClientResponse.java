package com.novo.core.framework.site.core.entity;

import org.apache.commons.lang3.StringUtils;

/**
 * Represents a ClientResponse
 *
 * @version 1.0
 * @since 1.0
 */
public class ClientResponse {
    private int statusCode =0;
    private String data= StringUtils.EMPTY;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
