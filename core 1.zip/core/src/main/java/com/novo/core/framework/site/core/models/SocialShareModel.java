package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

@Model(adaptables = Resource.class)
public class SocialShareModel {

    @ValueMapValue(name = PROPERTY_RESOURCE_TYPE, injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "No resourceType")
    protected String resourceType;

    @Inject
    @Optional
    private List<Resource> socialShareList;

    public List<SocialShareList> socialShare = new ArrayList<>();

    @PostConstruct
    protected void init() {
    	if (socialShareList != null) {
	        if (!socialShareList.isEmpty()) {
	            for (Resource resource : socialShareList) {
	                SocialShareList item = resource.adaptTo(SocialShareList.class);
	                socialShare.add(item);
	            }
	        }
    	}
    }

    public boolean getIsEmpty() {
        return socialShare.isEmpty();
    }

    public List<SocialShareList> getSocialShare() {
        return socialShare;
    } 

    public void setSocialShare(List<SocialShareList> socialShare) {
        this.socialShare = socialShare;
    }

}
