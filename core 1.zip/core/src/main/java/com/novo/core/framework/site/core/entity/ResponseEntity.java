package com.novo.core.framework.site.core.entity;

import com.novo.core.framework.site.core.exception.CartServletException;

/**
 * Represents a ResponseEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class ResponseEntity<T> {

    private boolean success = false;
    private T data;

    private String message;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResponseEntity<Object> buildErrorResponse(CartServletException ce) {
        ResponseEntity<Object> responseEntity = new ResponseEntity<>();
        responseEntity.setSuccess(ce.isStatus());
        responseEntity.setMessage( ce.getErrorMessage());
        return responseEntity;
    }
}
