package com.novo.core.framework.site.core.entity;

import org.apache.commons.lang3.StringUtils;

/**
 * Represents a LogoProperties
 *
 * @version 1.0
 * @since 1.0
 */
public class LogoProperties {

    private String logoUrl = StringUtils.EMPTY;
    private String publishUrl;

    public String getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(String logoUrl) {
        this.logoUrl = logoUrl;
    }

    public String getPublishUrl() {
        return publishUrl;
    }

    public void setPublishUrl(String publishUrl) {
        this.publishUrl = publishUrl;
    }
}
