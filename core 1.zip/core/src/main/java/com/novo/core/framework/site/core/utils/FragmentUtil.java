package com.novo.core.framework.site.core.utils;

import com.adobe.cq.xf.ExperienceFragmentsConstants;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FragmentUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FragmentUtil.class);
    private static final String LIST_ITEMS = "listItems";
    private static final String RESOURCE_TYPE = "novo-core-framework/site/components/content/experiencefragment";
    private static final String FRAGMENT_PATH = "fragmentPath";
    private FragmentUtil() {}

    public static String getPath(String fragmentPath, Page page, ResourceResolver resolver) {
        return getFragmentPath(fragmentPath, page, resolver);
    }

    private static String getFragmentPath(String fragmentPath, Page page, ResourceResolver resolver) {
        if (StringUtils.isNotBlank(fragmentPath)) {
            // check for fragments assigned in the hierarchy
            String localisedFragmentPath = getLocalisedFragmentPath(page, resolver);
            //if there is no localistion, get the default fragment type, check for master variation.
            if (StringUtils.isEmpty(localisedFragmentPath)) {
                String masterFragmentPath = getMasterFragmentPath(fragmentPath, resolver);
                if (StringUtils.isNotEmpty(masterFragmentPath)) fragmentPath = masterFragmentPath;
            } else {
                fragmentPath = localisedFragmentPath;
            }
            if (StringUtils.isNotEmpty(fragmentPath)) fragmentPath += "/" + NameConstants.NN_CONTENT;
            if (resolver.getResource(fragmentPath) == null) return null;
        }
        return fragmentPath;
    }

    /**
     * get the localised fragment path based on the page properties
     * @return fragmentPath
     */
    private static String getLocalisedFragmentPath(Page page, ResourceResolver resolver) {
        String localisedFragmentPath = null;
        if (page != null) {
            LOGGER.debug("Checking page:" + page.getPath());
            Resource listItems = page.getContentResource(LIST_ITEMS);
            if (listItems != null) {
                Iterable<Resource> childItems = listItems.getChildren();
                for (Resource childItem : childItems) {
                    ValueMap childProperties = childItem.getValueMap();
                    localisedFragmentPath = childProperties.containsKey(FRAGMENT_PATH)? (String) childProperties.get(FRAGMENT_PATH) : null;
                    if (StringUtils.isNotEmpty(localisedFragmentPath)) {
                        //check if its master fragment path
                        localisedFragmentPath = getMasterFragmentPath(localisedFragmentPath, resolver);
                        LOGGER.debug("Found fragment path:" + localisedFragmentPath);
                        return localisedFragmentPath;
                    }
                }
            }
            //recursive logic
            if (page.getParent() != null && StringUtils.isEmpty(localisedFragmentPath)) {
                return getLocalisedFragmentPath(page.getParent(), resolver);
            } else {
                return null;
            }
        }
        return localisedFragmentPath;
    }

    /**
     * Sets the master variation path for the XF fragment
     * if fragment folder is mapped, it checks and maps the master variation of the fragment
     * @return
     */
    private static String getMasterFragmentPath(String masterFragmentPath, ResourceResolver resolver) {
        Resource fragment = resolver.getResource(masterFragmentPath);
        if (fragment != null) {
            Resource fragmentContent = fragment.getChild(NameConstants.NN_CONTENT);
            if (fragmentContent != null &&
                (fragmentContent.isResourceType(ExperienceFragmentsConstants.RT_EXPERIENCE_FRAGMENT_MASTER) || fragmentContent.isResourceType(RESOURCE_TYPE))
            ) {
                Iterable<Resource> variations = fragment.getChildren();
                for (Resource variation : variations) {
                    String variationPath = variation.getPath();
                    Resource variationContent = variation.getChild(NameConstants.NN_CONTENT);
                    if (variationContent != null && variationContent.getValueMap().containsKey((ExperienceFragmentsConstants.PN_XF_MASTER_VARIATION))) {
                        boolean isMaster = (boolean)variationContent.getValueMap().get((ExperienceFragmentsConstants.PN_XF_MASTER_VARIATION));
                        if (isMaster) {
                            masterFragmentPath = variationPath;
                            // Update with correct master variation path in repository
                            ModifiableValueMap modifiableProperties = resolver.adaptTo(ModifiableValueMap.class);
                            if (modifiableProperties != null) {
                                modifiableProperties.put(FRAGMENT_PATH, masterFragmentPath);
                            }
                            try {
                                resolver.commit();
                            } catch (PersistenceException e) {
                                LOGGER.error(e.getMessage(), e);
                            }
                        }
                    }
                }
            }
        }
        return masterFragmentPath;
    }
}
