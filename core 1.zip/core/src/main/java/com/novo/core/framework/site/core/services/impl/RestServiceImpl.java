package com.novo.core.framework.site.core.services.impl;

import com.novo.core.framework.site.core.services.RestService;
import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Rest service impl to implement configs for .net connection
 * implements {@link RestService}
 *
 * check the component and designate annotations for defining service
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = RestService.class, immediate = true)
@Designate(ocd = RestServiceImpl.RestServiceUrlConfiguration.class)
public class RestServiceImpl implements RestService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestServiceImpl.class);


    //CONSTANTS
    private String restAPIBaseUrl = StringUtils.EMPTY;
    private String restAPICreateCartAPIUrl = StringUtils.EMPTY;
    private String restAPIGetCartAPIUrl = StringUtils.EMPTY;
    private String restAPIPostCartContentAPIUrl = StringUtils.EMPTY;
    private String restAPIGetCartContentAPIUrl = StringUtils.EMPTY;
    private String restAPIDeleteCartAPIUrl = StringUtils.EMPTY;
    private String restAPIAuthKey = StringUtils.EMPTY;
    /**
     *This private instance variable holds the REST API
     *endpoint for submitting data related to an organization.
     */
    private transient String restAPISubmitOrganization = StringUtils.EMPTY;
    private String restNovoAuthUrl = StringUtils.EMPTY;
    private String publishUrl = StringUtils.EMPTY;
    private String serviceUser = StringUtils.EMPTY;
    /**
     *This private instance variable holds the REST API
     *endpoint for getting customization data.
     */
    private transient String restAPIGetCustomization = StringUtils.EMPTY;
    /**
     *This private instance variable holds the REST API
     *endpoint for getting organization details.
     */
    private transient String restAPIGetOrganizationDetails = StringUtils.EMPTY;
    /**
     *This private instance variable holds the REST API
     *endpoint for updating cart details.
     */
    private transient String restAPIUpdateCartAPIUrl = StringUtils.EMPTY;
    /**
     *This private instance variable holds the REST API
     *endpoint for updating organization details.
     */
    private transient String restAPIUpdateOrganizationAPIUrl = StringUtils.EMPTY;


    /**
     * This method initializes the REST service with the configuration
     * provided.
     * It sets up the base URL and endpoints for various API calls.
     * @param config the configuration object containing the API
     * endpoint URLs and other settings
     */
    @Activate
    @Modified
    protected void activateOrModified(final RestServiceUrlConfiguration config) {
        restAPIBaseUrl = config.apiBaseUrlConfig();
        restAPIGetCartAPIUrl = config.getCartApiUrlConfig();
        restAPICreateCartAPIUrl = config.createCartApiUrlConfig();
        restAPIPostCartContentAPIUrl = config.createCartContentApiUrlConfig();
        restAPIGetCartContentAPIUrl = config.getCartContentApiUrlConfig();
        restAPIDeleteCartAPIUrl = config.deleteApiUrlConfig();
        restAPISubmitOrganization = config.uploadLogoUrlConfig();
        restAPIAuthKey = config.apiKeyConfig();
        restNovoAuthUrl = config.novoAuthUrlConfig();
        publishUrl = config.publishPagePathConfig();
        serviceUser = config.serviceUserConfig();
        restAPIGetCustomization = config.customizationDetailsConfig();
        restAPIGetOrganizationDetails = config.organizationDetailsConfig();
        restAPIUpdateCartAPIUrl = config.updateApiUrlConfig();
        restAPIUpdateOrganizationAPIUrl = config.updateOrganizationUrlConfig();



        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API base URL : {}", restAPIBaseUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API cart CREATE End : {}", restAPICreateCartAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API cart GET End : {}", restAPIGetCartAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API Get Customization GET End : {}", restAPIGetCustomization);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API Update Organization End : {}", restAPIUpdateOrganizationAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API cart content ADD End : {}", restAPIPostCartContentAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API cart content GET End : {}", restAPIGetCartContentAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API cart DELETE End : {}", restAPIDeleteCartAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API customization POST End: {}", restAPISubmitOrganization);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API Get User Details End{}", restNovoAuthUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API Get Organization Details End{}", restAPIGetOrganizationDetails);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution Rest API Update cart PUT End{}", restAPIUpdateCartAPIUrl);
        LOGGER.debug("RestService Activate() "
                + "contentdistribution publish URL{}", publishUrl);


    }

    @Override
    public String getRestNovoAuthUrl() {
        return restNovoAuthUrl;
    }

    @Override
    public String getRestAPIBaseUrl() {
        return restAPIBaseUrl;
    }

    @Override
    public String getRestAPIUpdateCartAPIUrl() {
        return restAPIUpdateCartAPIUrl;
    }

    @Override
    public String getRestAPICreateCartAPIUrl() {
        return restAPICreateCartAPIUrl;
    }

    @Override
    public String getRestAPIGetCartAPIUrl() {
        return restAPIGetCartAPIUrl;
    }

    @Override
    public String getRestAPIPostCartContentAPIUrl() {
        return restAPIPostCartContentAPIUrl;
    }

    @Override
    public String getRestAPIGetCartContentAPIUrl() {
        return restAPIGetCartContentAPIUrl;
    }

    @Override
    public String getRestAPIDeleteCartAPIUrl() {
        return restAPIDeleteCartAPIUrl;
    }

    @Override
    public String getRestAPISubmitOrganization() {
        return restAPISubmitOrganization;
    }

    @Override
    public String getRestAPIGetOrganizationDetails() {
        return restAPIGetOrganizationDetails;
    }

    @Override
    public String getRestAPIAuthKey() {
        return restAPIAuthKey;
    }

    @Override
    public String getRestAPIUpdateOrganizationAPIUrl() {
        return restAPIUpdateOrganizationAPIUrl;
    }

    @Override
    public String getPublishUrl() {
        return publishUrl;
    }

    @Override
    public String getRestAPIGetCustomization() { return restAPIGetCustomization; }

    @Override
    public String getServiceUser() {
        return serviceUser;
    }




    @ObjectClassDefinition(name = "Content Distribution Core Rest Configuration")
    public @interface RestServiceUrlConfiguration {

        /**
         * Attribute definition for host name
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API base url",
                description = "The base URL of the contentdistribution "
                        + "Rest API that is of the form protocol://host:port(Eg: "
                        + "https://localhost:8081) or protocol://domain(Eg: https://contentdistribution-rest-api.com)"
        )
        String apiBaseUrlConfig() default "https://api-educationcenter-novomedlink.nnittest.com";


        /**
         * Attribute definition for create cart
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest api create cart request endpoint",
                description = "Rest api create cart request endpoint"
        )
        String createCartApiUrlConfig() default "/API/ContentDistribution/CreateCartForUser";

        /**
         * Attribute definition for get carts
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest api to get cart request endpoint",
                description = "Rest api to get cart request endpoint"
        )
        String getCartApiUrlConfig() default "/API/ContentDistribution/GetUsersCart";

        /**
         * Attribute definition for add cart contents
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest api to add cart content request endpoint",
                description = "Rest api to add cart content request endpoint"
        )
        String createCartContentApiUrlConfig() default "/API/ContentDistribution/PushCartItem";

        /**
         * Attribute definition for get cart contents
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to get cart content request endpoint",
                description = "Rest API to get cart content request endpoint"
        )
        String getCartContentApiUrlConfig() default "/API/ContentDistribution/v2/GetCartContents";

        /**
         * Attribute definition for delete cart
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to delete cart request endpoint",
                description = "Rest API to delete cart request endpoint"
        )
        String deleteApiUrlConfig() default "/API/ContentDistribution/DeleteCart";

        /**
         * Attribute defition for API Key
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API key for authorization purpose",
                description = "Rest API key for authorization purpose"
        )
        String apiKeyConfig() default StringUtils.EMPTY;


        /**
         * Attribute defition for API Key
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to update cart request endpoint",
                description = "Rest API to update cart request endpoint"
        )
        String updateApiUrlConfig() default "/API/ContentDistribution/Org/UpdateCartsNameAndOrganization";


        /**
         * Attribute definition for submit logo
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to submit logo",
                description = "Rest API to submit logo"
        )
        String uploadLogoUrlConfig() default "/API/ContentDistribution/Org/CreateCustomization";

        /**
         * Attribute definition to get customization details
         *
         * @return
         */
        @AttributeDefinition(
                name = "Customization Api Url",
                description = "Rest API to get customization details"
        )
        String customizationDetailsConfig() default "/API/ContentDistribution/Org/GetCustomization";


        /**
         * Attribute definition to get user details
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to get organization details",
                description = "Rest API to get organization details"
        )
        String organizationDetailsConfig() default "/API/ContentDistribution/Org/GetOrganization";


        /**
         * Attribute definition to get user details
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to get user details",
                description = "Rest API to get user details"
        )
        String novoAuthUrlConfig() default "https://account.novomedlink.nnittest.com/api/v2/users/me";

        /**
         * Attribute definition to get user details
         *
         * @return
         */
        @AttributeDefinition(
                name = "Publish Page Path prefix",
                description = "Publish Page Path prefix"
        )
        String publishPagePathConfig() default "/content/novomedlink-educationcenter/en/myresources.html";

        /**
         * Attribute definition to get user details
         *
         * @return
         */
        @AttributeDefinition(
                name = "Service user",
                description = "Service user name that will be used "
                        + "to retrieve resource information for content-distribution"
        )
        String serviceUserConfig() default "tools-read";

        /**
         * Attribute definition for submit logo
         *
         * @return
         */
        @AttributeDefinition(
                name = "Rest API to update organization details",
                description = "Rest API to update organization details"
        )
        String updateOrganizationUrlConfig() default "/API/ContentDistribution/Org/UpdateCustomization";

    }

}
