package com.novo.core.framework.site.core.models;

import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.policies.ContentPolicyManager;
import com.novo.core.framework.site.core.utils.FragmentUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @author klick
 *
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class},
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NovoPageModel {
    private static final Logger LOG = LoggerFactory.getLogger(NovoPageModel.class);
    private static final String PN_BRAND_STYLES = "brandStyles";
    private static final String PN_CONTINUE_BUTTON_TEXT = "continueButtonText";
    private static final String PN_RETURN_BUTTON_TEXT = "returnButtonText";
    private static final String PN_EXTERNAL_FRAGMENT_PATH = "externalFragmentPath";
    private static final String PN_GATED_ENTRY_FRAGMENT_PATH = "gatedEntryFragmentPath";
    private static final String PN_GATED_DENIAL_FRAGMENT_PATH = "gatedDenialFragmentPath";
    private static final String PN_PAYER_PATH = "payerPath";
    private static final String PN_FDM_PATH = "fdmPath";
    private static final String PN_COOKIES_QUERY_PARAM_LIST = "/cookiesQueryParamList";
    private static final String PN_COOKIE_KEY_NAME = "cookieKeyName";
    private static final String PN_EXPIRE_ON_SESSION = "expireOnsession";
    private static final String PN_INTERNAL_FRAGMENT_PATH = "internalFragmentPath";
    private static final String PN_GTMID = "gtmID";
    private static final String PN_SITENAME = "siteName";
    private static final String PN_OZEMPIC = "ozempic";
    private static final String PN_WEGOVY = "wegovy";
    private static final String PN_CHOOSE_SITE_SCRIPT = "chooseSiteScript";
    private static final String PN_SCRIPT_URL = "scriptURL";
    private static final String PN_SCRIPT_ID = "scriptID";
    private static final String PN_ENABLE_ASYNC = "enableAsync";

    /**
     * The thumbnail image on page properties
     */
    private static final String PN_FILE_REFERENCE = "fileReference";

    /**
     * The seoTitle property in current page properties
     */
    private static final String PN_SEO_TITLE = "seoTitle";
    private static final String CSS_SUFFIX = ".css";
    private final List<ExternalScript> externalScriptsHeader = new ArrayList<>();
    private final List<ExternalScript> externalScriptsFooter = new ArrayList<>();
    private final List<String> cookiesFromQueryParams = new ArrayList<>();
    @SlingObject
    private Resource currentResource;
    @SlingObject
    private ResourceResolver resourceResolver;
    @Inject
    private Page currentPage;

    private Page homePage;
    private String externalFragmentPath;
    private String internalFragmentPath;
    private String gatedEntryFragmentPath;
    private String gatedDenialFragmentPath;
    private String payerPath;
    private String fdmPath;

    @PostConstruct
    public void activate() {
        if (Objects.isNull(currentPage)) {
            Optional.ofNullable(resourceResolver)
                .map(res -> res.adaptTo(PageManager.class))
                .map(pm -> pm.getContainingPage(currentResource))
                .ifPresent(page -> currentPage = page);
        }
        populateHomePage(currentPage);
        populateInstanceVariables();
    }

    private void populateHomePage(Page parent) {
		if (Objects.nonNull(parent) && parent.getContentResource() != null) {
			final Resource resource = parent.getContentResource();
			if (resource != null) {
				final String resourceType = resource.getValueMap().get(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
						StringUtils.EMPTY);
				if (StringUtils.contains(resourceType, "novo-home")) {
					homePage = parent;
				} else {
					populateHomePage(parent.getParent());
				}
			}
		}
	}

    private void populateInstanceVariables() {
        if (Objects.nonNull(currentPage) && Objects.nonNull(homePage)) {
            this.externalFragmentPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_EXTERNAL_FRAGMENT_PATH, StringUtils.EMPTY))
                .map(propValue -> FragmentUtil.getPath(propValue, currentPage, resourceResolver))
                .filter(StringUtils::isNotEmpty)
                .orElseGet(() -> getInheritedFragmentProperty(currentPage, PN_EXTERNAL_FRAGMENT_PATH, resourceResolver, false));
            this.internalFragmentPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_INTERNAL_FRAGMENT_PATH, StringUtils.EMPTY))
                .map(propValue -> FragmentUtil.getPath(propValue, currentPage, resourceResolver))
                .filter(StringUtils::isNotEmpty)
                .map(internalFragPath -> getInternalFragmentPath(internalFragPath, resourceResolver))
                .orElseGet(() -> getInheritedFragmentProperty(currentPage, PN_INTERNAL_FRAGMENT_PATH, resourceResolver, true));
            this.gatedEntryFragmentPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_GATED_ENTRY_FRAGMENT_PATH, StringUtils.EMPTY))
                .map(propValue -> FragmentUtil.getPath(propValue, currentPage, resourceResolver))
                .filter(StringUtils::isNotEmpty)
                .orElseGet(() -> getInheritedFragmentProperty(currentPage, PN_GATED_ENTRY_FRAGMENT_PATH, resourceResolver, false));
            this.gatedDenialFragmentPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_GATED_DENIAL_FRAGMENT_PATH, StringUtils.EMPTY))
                .map(propValue -> FragmentUtil.getPath(propValue, currentPage, resourceResolver))
                .filter(StringUtils::isNotEmpty)
                .orElseGet(() -> getInheritedFragmentProperty(currentPage, PN_GATED_DENIAL_FRAGMENT_PATH, resourceResolver, false));
            Optional.ofNullable(resourceResolver.adaptTo(ContentPolicyManager.class))
                .map(man -> man.getPolicy(homePage.getContentResource()))
                .map(policy -> policy.getPath() + "/externalScripts")
                .map(resourceResolver::getResource)
                .map(Resource::getChildren)
                .ifPresent(iter -> iter.forEach(res -> {
                    ExternalScript extScript = res.adaptTo(ExternalScript.class);
                    if(currentPage.getPath().contains(PN_OZEMPIC) && extScript.getEnableOzempic() == true){
                        if (Objects.nonNull(extScript) && extScript.getHeaderScript()) {
                            externalScriptsHeader.add(extScript);
                        } else {
                            externalScriptsFooter.add(extScript);
                        }
                    }else if(currentPage.getPath().contains(PN_WEGOVY) && extScript.getEnableOzempic() == false){
                        if (Objects.nonNull(extScript) && extScript.getHeaderScript()) {
                            externalScriptsHeader.add(extScript);
                        } else {
                            externalScriptsFooter.add(extScript);
                        }
                    }else if(!currentPage.getPath().contains(PN_OZEMPIC) && !currentPage.getPath().contains(PN_WEGOVY) && extScript.getEnableOzempic() == false){
                        if (Objects.nonNull(extScript) && extScript.getHeaderScript()) {
                            externalScriptsHeader.add(extScript);
                        } else {
                            externalScriptsFooter.add(extScript);
                        }
                    }
                }));
            Optional.ofNullable(resourceResolver.adaptTo(ContentPolicyManager.class))
                    .map(res -> res.getPolicy(currentPage.getContentResource()))
                    .map(policy -> policy.getPath() + PN_COOKIES_QUERY_PARAM_LIST)
                    .map(resourceResolver::getResource)
                    .map(Resource::getChildren)
                    .ifPresent(iter -> iter.forEach(res -> {
                        final String cookieKey = res.getValueMap().get(PN_COOKIE_KEY_NAME).toString();
                        final String expireOnSession = res.getValueMap().get(PN_EXPIRE_ON_SESSION, StringUtils.EMPTY).toString();

                        if (StringUtils.isNotBlank(cookieKey)) {
                            cookiesFromQueryParams.add(cookieKey + "," + expireOnSession);
                        }
                    }));
            this.payerPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_PAYER_PATH, String.class))
                .filter(StringUtils::isNotEmpty)
                .orElseGet(() -> getInheritedProperty(currentPage, PN_PAYER_PATH, null));
            this.fdmPath = Optional.ofNullable(currentPage.getProperties())
                .map(vm -> vm.get(PN_FDM_PATH, String.class))
                .filter(StringUtils::isNotEmpty)
                .orElseGet(() -> getInheritedProperty(currentPage, PN_FDM_PATH, null));
        }
    }

    public String getBrandStyles() {
        return Optional.ofNullable(currentPage.getProperties())
            .map(vm -> vm.get(PN_BRAND_STYLES, String.class))
            .filter(StringUtils::isNotBlank)
            .filter(style -> StringUtils.endsWith(style, CSS_SUFFIX))
            .orElseGet(() -> getInheritedProperty(currentPage, PN_BRAND_STYLES, CSS_SUFFIX));
    }

    private String getInheritedProperty(Page page, String propertyName, String validationSuffix) {
        Page parent = page.getParent();
        if (parent != null) {
            ValueMap pageProperties = parent.getProperties();
            String propertyValue = pageProperties.get(propertyName, String.class);
            if (StringUtils.isNotEmpty(validationSuffix)) {
                return StringUtils.endsWith(propertyValue, validationSuffix) ? propertyValue : getInheritedProperty(parent, propertyName, validationSuffix);
            } else {
                return StringUtils.isNoneBlank(propertyValue) ? propertyValue : getInheritedProperty(parent, propertyName, validationSuffix);
            }
        } else {
            return StringUtils.EMPTY;
        }
    }

    public String getContinueButtonText() {
        return Optional.ofNullable(currentPage.getProperties())
            .map(vm -> vm.get(PN_CONTINUE_BUTTON_TEXT, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_CONTINUE_BUTTON_TEXT, null));
    }

    /**
     * Gets the seoTitle of the page
     * @return the seoTitle property of the page
     */
    public String getPageTitle() {
        return Optional.ofNullable(currentPage.getProperties())
            .map(vm -> vm.get(PN_SEO_TITLE, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> currentPage.getPageTitle());
    }

    public String getReturnButtonText() {
        return Optional.ofNullable(currentPage.getProperties())
            .map(vm -> vm.get(PN_RETURN_BUTTON_TEXT, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_RETURN_BUTTON_TEXT, null));
    }

    public String getExternalFragmentPath() {
        return externalFragmentPath;
    }

    private String getInheritedFragmentProperty(Page page, String propertyName, ResourceResolver resourceResolver, boolean isInternal) {
        Page parent = page.getParent();
        if (parent != null) {
            ValueMap pageProperties = parent.getProperties();
            String propertyValue = FragmentUtil.getPath(pageProperties.get(propertyName, String.class), currentPage, resourceResolver);
            if (isInternal) {
                propertyValue = getInternalFragmentPath(propertyValue, resourceResolver);
            }
            return StringUtils.isNoneBlank(propertyValue) ? propertyValue : getInheritedFragmentProperty(parent, propertyName, resourceResolver, isInternal);

        } else {
            return StringUtils.EMPTY;
        }
    }

    private String getInternalFragmentPath(String internalFragmentPath, ResourceResolver resolver) {
        Resource fragmentRes = resolver.getResource(internalFragmentPath);
        if (Objects.nonNull(fragmentRes)) {
            return Optional.ofNullable(Optional.ofNullable(fragmentRes.getChild("/root"))
                    .orElseGet(() -> Optional.ofNullable(fragmentRes.getChild("/jcr:content/root"))
                        .orElseGet(() -> fragmentRes.getChild("/jcr:content"))))
                .map(Resource::getPath)
                .orElse(internalFragmentPath);
        }
        return internalFragmentPath;
    }

    public String getInternalFragmentPath() {
        return internalFragmentPath;
    }

    /**
     * Gets the current page image set on page properties
     * @return the path of the image of the current page
     */
    public String getPageImageUrl() {

        String fileReference = StringUtils.EMPTY;

        if (null != resourceResolver && null != currentPage) {
            final Resource currResource = resourceResolver.getResource(currentPage.getPath()+"/jcr:content/image");
            if (null != currResource) {
                final ValueMap properties = currResource.adaptTo(ValueMap.class);
                if (null != properties) {
                    fileReference = properties.get(PN_FILE_REFERENCE, String.class);
                }
            }
        }

        return fileReference;
    }


    /**
     * Gets the jcr:description value as first option, if empty gets the seoTitle property. If seoTitle property is
     * empty then gets the page title
     * @return a string containing a description for the current page
     */
    public String getPageDescription() {
        String pageDescription = StringUtils.EMPTY;

        if (null != currentPage) {
            final ValueMap properties = currentPage.getProperties();
            if (null != properties) {
                pageDescription = properties.get(JcrConstants.JCR_DESCRIPTION, String.class);
                if (StringUtils.isBlank(pageDescription)) {
                    pageDescription = properties.get(PN_SEO_TITLE, String.class);
                    if (StringUtils.isBlank(pageDescription)) {
                        return currentPage.getTitle();
                    }
                }
            }
        }

        return pageDescription;
    }

    public String getWebsiteName() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_SITENAME, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_SITENAME, null));
    }

    public List<ExternalScript> getExternalScriptsFooter() {
        return externalScriptsFooter;
    }

    public List<ExternalScript> getExternalScriptsHeader() {
        return externalScriptsHeader;
    }

    public List<String> getCookiesFromQueryParams() {
        return cookiesFromQueryParams;
    }

    public String getGtmID() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_GTMID, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_GTMID, null));
    }

    public String getScriptID() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_SCRIPT_ID, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_SCRIPT_ID, null));
    }

    public String getScriptURL() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_SCRIPT_URL, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_SCRIPT_URL, null));
    }

    public String getChooseSiteScript() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_CHOOSE_SITE_SCRIPT, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_CHOOSE_SITE_SCRIPT, null));
    }

    public String getEnableAsync() {
        return Optional.ofNullable(currentPage)
            .map(Page::getProperties)
            .map(vm -> vm.get(PN_ENABLE_ASYNC, String.class))
            .filter(StringUtils::isNotBlank)
            .orElseGet(() -> getInheritedProperty(currentPage, PN_ENABLE_ASYNC, null));
    }

    public String getHtmlLanguage() {
        return Optional.ofNullable(homePage)
            .map(Page::getProperties)
            .map(vm -> vm.get("htmlLangCode", String.class))
            .orElse(StringUtils.EMPTY);
    }

    public String getGatedEntryFragmentPath() {
        return gatedEntryFragmentPath;
    }

    public String getGatedDenialFragmentPath() {
        return gatedDenialFragmentPath;
    }

    public String getPayerPath() {
        return payerPath;
    }

    public String getFdmPath() {
        return fdmPath;
    }
}
