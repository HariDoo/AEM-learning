package com.novo.core.framework.site.core.models;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.VariationDef;

import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.settings.SlingSettingsService;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;



@Model(adaptables=SlingHttpServletRequest.class)
public class FloatingISIContentModel {
	
    private Section tempSection;

    @Inject
    @Optional
    @Via("resource")
    @Named("isiList")
    public Resource isiList;

    @Inject
    @Optional
    @Via("resource")
    @Named("isiHeadlineOption")
    public String isiHeadlineOption;

    @Inject
    @Optional
    @Via("resource")
    @Named("headerText")
    public String headerText;

    @Inject
    @Optional
    @Via("resource")
    @Named("inlineHeaderText")
    public String inlineHeaderText;

    @OSGiService
    private SlingSettingsService settings;
    @SlingObject
    private Resource currentResource;
    @SlingObject
    private ResourceResolver resourceResolver;
    @Inject
    private Page currentPage;
    
    public class Section {
        public Section() {

        }

        public Section(String name, String content) {
            this.name = name;
            this.content = content;
        }

        public String name;
        public String content;
    }

    public class ISI {
        public ISI() {

        }

        public ISI(ArrayList<Section> sections, String drugName, String[] selectedSections, String path, String isiName, String isiStyles,
                Section indication, Section prescribing, String variation) {
            this.sections = sections;
            this.drugName = drugName;
            this.selectedSections = selectedSections;
            this.path = path;
            this.isiName = isiName;
            this.isiStyles = isiStyles;
            this.indication = indication;
            this.prescribing = prescribing;
            this.variation = variation;
        }

        public String isiName;
        public String isiStyles;
        public ArrayList<Section> sections;
        public Section indication = new Section();
        public Section prescribing = new Section();
        public String drugName;
        public String[] selectedSections;
        public String path;
        public String variation;
    }

    public ArrayList<ISI> allISIs = new ArrayList<ISI>();

    @PostConstruct
    protected void init() {
        if (isiList != null) {
            try {
                Iterator<Resource> iterator = isiList.listChildren();
                
                while (iterator.hasNext()) {
                    Resource res = iterator.next();
                    ValueMap map = res.getValueMap();
                    ISI newIsi = new ISI();
                    allISIs.add(newIsi);
                    newIsi.path = map.get("fragmentPath", String.class);
                    newIsi.variation = map.get("variationString", "master");
                    if (newIsi.path.length() > 0){
                        ContentFragment CF = resourceResolver.getResource(newIsi.path).adaptTo(ContentFragment.class);
                        Iterator<VariationDef> v = CF.listAllVariations();
                        Boolean variationExists = false;
                        while (v.hasNext()) {
                            VariationDef d = v.next();
                            if (d.getName().equalsIgnoreCase(newIsi.variation)) {
                                variationExists = true;
                            }
                        }
                        if (!variationExists) {
                            newIsi.variation = "master";
                        }

                        newIsi.isiName = createISIName(CF, newIsi.variation);
                        newIsi.isiStyles = createISIStyles(CF, newIsi.variation);
                        newIsi.selectedSections = map.get("isiSections", String[].class);
                        newIsi = createSectionList(CF, newIsi);
                        newIsi.drugName = parseDrugName(map.get("isiDrugName", String.class));
                        newIsi = setHeadlineText(newIsi);
                    }
                    
                }

            } catch (Exception ex) {

            }
        }
    }

    /*Content Parsing Methods */
    public String createISIName(ContentFragment CF, String variation) {
        String isiname = "";

        if (CF.hasElement("isiName")) {
            isiname = getContentFromVariation(CF, variation, "isiName");

            isiname = isiname.replaceAll(" ", "-");
            isiname = isiname.replaceAll("[^A-Za-z0-9-]", "");
        }
        return isiname;
    }

    public String createISIStyles(ContentFragment CF, String variation) {
        String isiStyles = "";
        if (CF.hasElement("isiStyles")) {
            isiStyles = getContentFromVariation(CF, variation, "isiStyles");
        }
        return isiStyles;
    }

    public ISI createSectionList(ContentFragment CF, ISI thisISI) {
        String[] selected = thisISI.selectedSections;
        String isiname = thisISI.isiName;

        ArrayList<Section> sections = new ArrayList<Section>();
        Integer count = 1;

        while (CF.hasElement("sectionName-" + count)) {
            String sectionName = getContentFromVariation(CF, thisISI.variation, "sectionName-" + count);
            String isIndication = getContentFromVariation(CF, thisISI.variation, "sectionIndication-" + count);
            String isPrescribing = getContentFromVariation(CF, thisISI.variation, "sectionPrescribing-" + count);

            if (!StringUtils.isEmpty(sectionName) && !isIndication.equalsIgnoreCase("true")) {
                tempSection = new Section(sectionName, "");
                if (selected == null || selected.length == 0){
                    if (isPrescribing.equalsIgnoreCase("true")){
                        thisISI.prescribing = tempSection;
                    }
                    else{
                        sections.add(tempSection);
                    }
                }
                else{
                    for (String s : selected) {
                        if (s.equals(sectionName)){
                            if (isPrescribing.equalsIgnoreCase("true")){
                                thisISI.prescribing = tempSection;
                            }
                            else{
                                sections.add(tempSection);
                            }
                            break;
                        }
                    }
                }                    
            }
            else if (!StringUtils.isEmpty(sectionName) && isIndication.equalsIgnoreCase("true")) {
                if (StringUtils.isEmpty(thisISI.indication.name)){
                    tempSection = new Section(sectionName, "");
                    thisISI.indication = tempSection;
                }
            }

            String sectionContent = getContentFromVariation(CF, thisISI.variation, "sectionContent-" + count);
            sectionContent = parseSection(sectionContent, isiname);

            String blackbox = getContentFromVariation(CF, thisISI.variation, "sectionBlackbox-" + count);
            if (blackbox.equalsIgnoreCase("true")) {
                tempSection.content = tempSection.content + "<div class='isi-blackbox'>"
                        + sectionContent + "</div>";
            } else {
                tempSection.content = tempSection.content + sectionContent;
            }

            count++;
        }
        thisISI.sections = sections;
        return thisISI;
    }

    public String parseSection(String s, String isiname){                
        s = s.replaceAll("<pre>([\\s\\n\\t]*)([\\s\\S]*?)([\\s\\n\\t]*)</pre>",
                "<a name='" + isiname + "-$2' class='isi-anchor'></a>");

        return s;
    }

    public String parseDrugName(String s){
        if (!StringUtils.isEmpty(s)){
            s = s.replaceAll("(?!<sup>)®(?!<\\/sup>)", "<sup>®</sup>");;
            s = s.trim();

            return s;
        }
        return "";
    }

    public ISI setHeadlineText(ISI isi){
        if(isiHeadlineOption.equalsIgnoreCase("first")){
            if (isi.sections.size() > 0){
                Section s = isi.sections.get(0);
                s.content = s.content.replaceFirst("<h1>", "<h1>" + isi.drugName + " ");
            }
            if (!StringUtils.isEmpty(isi.indication.content)){
                isi.indication.content = isi.indication.content.replaceFirst("<h1>", "<h1>" + isi.drugName + " ");
            }
            if (!StringUtils.isEmpty(isi.prescribing.content)){
                isi.prescribing.content = isi.prescribing.content.replaceFirst("<h1>", "<h1>" + isi.drugName + " ");
            }
        }
        else if (isiHeadlineOption.equalsIgnoreCase("primary")) {
            for (Section s : isi.sections) {
                s.content = s.content.replace("<h1>", "<h1>" + isi.drugName + " ");
            }
            if (!StringUtils.isEmpty(isi.indication.content)) {
                isi.indication.content = isi.indication.content.replace("<h1>", "<h1>" + isi.drugName + " ");
            }
            if (!StringUtils.isEmpty(isi.prescribing.content)) {
                isi.prescribing.content = isi.prescribing.content.replace("<h1>", "<h1>" + isi.drugName + " ");
            }
        }
        else if(isiHeadlineOption.equalsIgnoreCase("all")) {
            if (isi.sections.size() > 0){
                for (Section s : isi.sections) {
                    s.content = s.content.replace("<h1>", "<h1>" + isi.drugName + " ");
                    s.content = s.content.replace("<h2>", "<h2>" + isi.drugName + " ");                
                }
            }

            if (!StringUtils.isEmpty(isi.indication.content)){
                isi.indication.content = isi.indication.content.replace("<h1>", "<h1>" + isi.drugName + " ");
                isi.indication.content = isi.indication.content.replace("<h2>", "<h2>" + isi.drugName + " ");
            }

            if (!StringUtils.isEmpty(isi.prescribing.content)){
                isi.prescribing.content = isi.prescribing.content.replace("<h1>", "<h1>" + isi.drugName + " ");
                isi.prescribing.content = isi.prescribing.content.replace("<h2>", "<h2>" + isi.drugName + " ");
            }
        }

        return isi;
    }
    
    private String getContentFromVariation(ContentFragment CF, String variation, String element) {
        if (StringUtils.isNotEmpty(variation) && !variation.equalsIgnoreCase("master")) {
            return CF.getElement(element).getVariation(variation).getContent();
        }
        return CF.getElement(element).getContent();
    }

    /*Getter Methods */
    public ArrayList<ISI> getIsis() {
        return allISIs;
    }

    public String getHeadlineOption(){
        return isiHeadlineOption;
    }

    public Boolean getIsEmpty(){
        return allISIs.size() == 0;
    }

    public String getHeader() {
        if (!StringUtils.isEmpty(headerText)) {
            String s = headerText.replaceAll("(?!<sup>)®(?!<\\/sup>)", "<sup>®</sup>");
            s = s.trim();

            return s;
        }
        return "";
    }

    public String getInlineHeader() {
        if (!StringUtils.isEmpty(inlineHeaderText)) {
            String s = inlineHeaderText.replaceAll("(?!<sup>)®(?!<\\/sup>)", "<sup>®</sup>");
            s = s.trim();

            return s;
        }
        return "";
    }
   
}
