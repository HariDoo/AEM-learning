package com.novo.core.framework.site.core.entity;
/**
 * This class represents an entity for operational time
 * requests.
 */
public class OperationalTimeRequestEntity {
    /**
     * This variable stores the day of the week
     */
    private String day;
    /**
     * This variable stores the from time of the day
     */
    private String from;
    /**
     * This variable stores the to time of the day
     */
    private String to;

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }
}
