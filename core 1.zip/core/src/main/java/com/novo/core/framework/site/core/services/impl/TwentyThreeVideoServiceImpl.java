package com.novo.core.framework.site.core.services.impl;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.novo.core.framework.site.core.services.TwentyThreeVideoService;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


@Component(
        immediate = true,
        property = {
                Constants.SERVICE_DESCRIPTION + "= For configuring Node Listener Config",
                Constants.SERVICE_VENDOR + "= KLICK"
        })
@Designate(ocd = TwentyThreeVideoServiceImpl.TwentyThreeVideoConfig.class)
public class TwentyThreeVideoServiceImpl implements TwentyThreeVideoService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TwentyThreeVideoServiceImpl.class);
    TwentyThreeVideoConfig twentyThreeVideoConfig;
    
    
    /** The twenty three video host. */
    private  String twentyThreeVideoHost;
    @Activate
    @Modified
    protected final void activate(TwentyThreeVideoConfig config) {
        this.twentyThreeVideoConfig = config;
        this.twentyThreeVideoHost = config.twentyThreeVideoHost();
    }

    /**
     * Gets the twenty three video host.
     *
     * @return the twenty three video host
     */
    @Override
    public String getTwentyThreeVideoHost() {
		return twentyThreeVideoHost;
	}

	@Override
    public JsonObject getTwentyThreeVideoObject(String videoId, String videoServer) {
        CloseableHttpClient client = HttpClients.createDefault();
        String videoApiUrl = (StringUtils.isNotBlank(videoServer) ? videoServer : twentyThreeVideoConfig.twentyThreeVideoHost())
                        + twentyThreeVideoConfig.twentyThreeVideoListApi() + "?photo_id=" + videoId
                        + "&format=json&raw";
        URI uri = null;
        JsonObject jsonObject = null;
        try {
            uri = new URI(videoApiUrl);
            HttpRequestBase method = new HttpGet(uri);
            CloseableHttpResponse response = client.execute(method);
            if (response.getStatusLine().getStatusCode() == 200) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    String videoJsonResponse = EntityUtils.toString(entity);
                    jsonObject = new JsonParser().parse(videoJsonResponse).getAsJsonObject();
                }
            }
        } catch (URISyntaxException | IOException e) {
            LOGGER.error("error calling video api:", e);
        } finally {
            try {
                client.close();
            } catch (IOException e) {
                LOGGER.error("error closing httpclient:", e);
            }
        }

        return jsonObject;
    }

    @ObjectClassDefinition(name = "TwentyThreeVideo OSGI configuration")
    public @interface TwentyThreeVideoConfig {
        @AttributeDefinition(name = "twentyThreeVideo_host", description = "Default host url of Twenty Three Video")
        String twentyThreeVideoHost() default "https://nni-video.videomarketingplatform.co";

        @AttributeDefinition(name = "twentyThreeVideoList_api", description = "host url of Twenty Three Video")
        String twentyThreeVideoListApi() default "/api/photo/list";
    }
}
