package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.Page;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Klick
 *
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class},
    defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NovoContentPageModel {

    @Inject
    private Page currentPage;
    private Page homePage;

    @PostConstruct
    public void activate() throws Exception {
        Optional.ofNullable(currentPage).ifPresent(validPage -> getHomePage(validPage.getParent()));
    }
    
    /**
     * Get method for the home page by fetching property novo-home
     *
     */
	public void getHomePage(Page parent) {
		if (Objects.nonNull(parent)) {
			final Resource homeResource = parent.getContentResource();
			if (homeResource != null) {
				if (StringUtils.contains(homeResource.getResourceType(), "novo-home")) {
					homePage = parent;
				} else {
					getHomePage(parent.getParent());
				}
			}
		}
	}

    public String getPrbNumber() {
        return getHomePageProperty("prbNumber");
    }

    public String getBrand() {
        return getHomePageProperty("brand");
    }

    private String getHomePageProperty(String property) {
        return Optional.ofNullable(homePage)
            .map(Page::getProperties)
            .map(vm -> vm.get(property, String.class))
            .orElse(StringUtils.EMPTY);
    }
}