package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import javax.inject.Inject;

@Model(adaptables = Resource.class)
public class ExternalScript {

    @Inject
    @Optional
    private String scriptID;

    @Inject
    @Optional
    private String scriptURL;

    @Inject
    @Optional
    @Default(booleanValues=false)
    private Boolean enableAsync;

    @Inject
    @Optional
    @Default(booleanValues=false)
    private Boolean headerScript;

    @Inject
    @Optional
    @Default(booleanValues=false)
    private Boolean enableOzempic;



    @Inject
    @Optional
    private String[] cookieManager;

    public String getScriptID() {
        return scriptID;
    }

    public void setScriptID(String scriptID) {
        this.scriptID = scriptID;
    }

    public String getScriptURL() {
        return scriptURL;
    }

    public void setScriptURL(String scriptURL) {
        this.scriptURL = scriptURL;
    }

    public Boolean getHeaderScript() {
        return headerScript ? headerScript : false;
    }

    public void setHeaderScript(Boolean headerScript) {
        this.headerScript = headerScript;
    }

    public Boolean getEnableAsync() {
        return enableAsync;
    }

    public void setEnableAsync(Boolean enableAsync) {
        this.enableAsync = enableAsync;
    }
    public Boolean getEnableOzempic() {
        return enableOzempic;
    }

    public void setEnableOzempic(Boolean enableOzempic) {
        this.enableOzempic = enableOzempic;
    }

    public String[] getCookieManager() {
        return cookieManager;
    }

    public void setCookieManager(String[] cookieManager) {
        this.cookieManager = cookieManager;
    }
}
