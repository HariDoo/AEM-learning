package com.novo.core.framework.site.core.models;

import com.day.crx.JcrConstants;
import com.novo.core.framework.site.core.constants.CommonConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

/**
 * Model to fetch properties from the added resource urls
 *
 * @version 1.0
 * @since 1.0
 */
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ContentModel extends PublishContentModel{

    public static final String SLASH = "/";
    public static final String HTML = ".html";
    @Inject
    private Resource resource;

    @ValueMapValue
    @Named(value = "rollupDescription")
    private String description;

    @ValueMapValue
    @Named(value = "rollupImageMobile")
    private String mobileImage;

    @ValueMapValue
    @Named(value = "rollupImage")
    private String desktopImage;

    @ValueMapValue
    @Optional
    private String rollupVideo;

    @ValueMapValue
    @Optional
    private String rollupDownload;

    private String configUrl;

    @PostConstruct
    protected void init(){
        setPath(resource.getPath().replace(SLASH+ JcrConstants.JCR_CONTENT, StringUtils.EMPTY));
        if(getAssetType().equalsIgnoreCase(CommonConstants.VIDEO))
            configUrl = rollupVideo;
        if(getAssetType().equalsIgnoreCase(CommonConstants.ASSET))
            configUrl = rollupDownload;
        if(getAssetType().equalsIgnoreCase(CommonConstants.PAGE))
            configUrl = getPath().concat(HTML);
    }

    public String getDescription() {
        return description;
    }

    public String getMobileImage() {
        return mobileImage;
    }

    public String getDesktopImage() {
        return desktopImage;
    }

    public String getConfigUrl() {
        return configUrl;
    }

}
