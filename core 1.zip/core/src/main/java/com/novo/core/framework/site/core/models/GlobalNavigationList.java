package com.novo.core.framework.site.core.models;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@Model(adaptables = Resource.class)
public class GlobalNavigationList {

    /**
     * Object to output log messages
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalNavigationList.class);

    @Inject
    @Optional
    private String linkClassName;

    @Inject
    @Optional
    private String linkTitle;

    @Inject
    @Optional
    private String linkUrl;

    @Inject
    @Optional
    private String linkExitModal;

    @Inject
    @Optional
    private String linkTargetValue;

    /**
     * List of NavigationItem with a set of configuration to override the current link url and link target
     * when matches with the current brand
     */
    @Inject
    @Optional
    private List<NavigationItem> overrideGlobalNavLinks;

    @Inject
    @Optional
    private List<DropDownItem> dropdownItems;

    @Inject
    Resource resource;

    public String getLinkClassName() {
        return linkClassName;
    }

    public void setLinkClassName(String linkClassName) {
        this.linkClassName = linkClassName;
    }

    public String getLinkTitle() {
        return linkTitle;
    }

    public void setLinkTitle(String linkTitle) {
        this.linkTitle = linkTitle;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getLinkExitModal() {
        return linkExitModal;
    }

    public void setLinkExitModal(String linkExitModal) {
        this.linkExitModal = linkExitModal;
    }

    public String getLinkTargetValue() {
        return linkTargetValue;
    }

    public List<DropDownItem> getDropdownItems() {
        if (null != resource && resource.hasChildren()) {
            Resource dropdownResource = resource.getChild("dropdownItems");
            if(dropdownResource != null && dropdownResource.hasChildren()) {
                dropdownItems = new ArrayList<>();
                dropdownResource.getChildren().forEach(e -> {
                    DropDownItem item = DropDownItem.build(e);
                    if(item != null) {
                        dropdownItems.add(item);
                    }
                });
            }
        }
        return dropdownItems;
    }

    /**
     * Gets the the list of configurations to override the title and target of the current link
     * @return a String containing the list of configurations to override the title and target of
     * the current link element
     */
    public String getOverrideGlobalNavLinks() {

        String overrideNavLinkValues = StringUtils.EMPTY;

        if (null != resource && resource.hasChildren()) {
            final Resource overrideNavLinksRes = resource.getChild("overrideGlobalNavLinks");
            if(overrideNavLinksRes != null && overrideNavLinksRes.hasChildren()) {
                overrideGlobalNavLinks = new ArrayList<>();
                overrideNavLinksRes.getChildren().forEach(e -> {
                    final NavigationItem item = NavigationItem.build(e);
                    if(item != null) {
                        overrideGlobalNavLinks.add(item);
                    }
                });
            }

            try {
                overrideNavLinkValues = new ObjectMapper().writeValueAsString(overrideGlobalNavLinks);
            } catch (JsonProcessingException e) {
                LOGGER.info("Error while getting navigation items, {}", e.getMessage());
            }
        }

        return overrideNavLinkValues;
    }

    public void setLinkTargetValue(String linkTargetValue) {
        this.linkTargetValue = linkTargetValue;
    }

    public void setDropdownItems(List<DropDownItem> dropdownItems) {
        this.dropdownItems = dropdownItems;
    }

    /**
     * Sets a list of configurations for the current link element
     * @param overrideGlobalNavLinks a list of configurations to override the current link
     */
    public void setOverrideGlobalNavLinks(List<NavigationItem> overrideGlobalNavLinks) {
        this.overrideGlobalNavLinks = overrideGlobalNavLinks;
    }
}
