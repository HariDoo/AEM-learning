package com.novo.core.framework.site.core.entity;

import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.services.impl.ContentDistributionMsgConfigServiceImpl;

import java.util.HashMap;
import java.util.Map;

/**
 * Map methods that contains enum to messages mapping from
 * OSGI config so that those can be used by servlet message mapping
 *
 * @since 1.0
 * @version 1.0
 */
public class ApiRequestResponseMap {
    /**
     * A string format specifier for formatting strings with
     * two placeholders.
     * The placeholders can be replaced by any two string values.
     */
    public static final String S_S = "%s:%s";

    private ApiRequestResponseMap() {
        throw new IllegalStateException("Utility class");
    }

    private static final String DOT = ".";
    /**
     * This field is a constant string used in various parts of the application
     * to indicate the start of a base64-encoded image string.
     */
    public static final String BASESTRING = "-64_";

    /**
     * Returns a map of API messages for various requests.
     * @param apiMessage the ApiMessage object containing the messages
     * @return a map of API messages
     */
    public static Map<String, String> getMessageMap(ApiMessage apiMessage) {
        final ApiRequestEnum[] requestEnums = ApiRequestEnum.values();
        final ApiResponseEnum[] responseEnums = ApiResponseEnum.values();
        final int initialCapacity = requestEnums.length * responseEnums.length;
        final Map<String, String> apiMessageMap = new HashMap<>(initialCapacity);
        // Create cart api messages
        apiMessageMap.put(String.format(S_S, ApiRequestEnum.CREATE_CART, ApiResponseEnum.CART_CREATE_SUCCESS), apiMessage.getCreateCartSuccessMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART, ApiResponseEnum.INVALID_REQUEST),apiMessage.getCreateCartBadRequestMessage());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.FORBIDDEN, apiMessage.getCreateCartsForbiddenMessage());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INTERNAL_SERVER_ERROR, apiMessage.getCreateCartInternalServerErrorMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART, ApiResponseEnum.INVALID_USER_ID), apiMessage.getCreateCartInvalidAuthToken());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.MICROSERVICE_BROKEN, apiMessage.getCreateCartBrokenMicroservice());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_CART_NAME, apiMessage.getCreateCartMoreThanFiftyChar());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART , ApiResponseEnum.INVALID_MAX_COUNT), apiMessage.getCreateCartMaxLimitReach());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.DB_CONNECT_FAILED, apiMessage.getCreateCartBrokenSqlConnection());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_DISEASE_TYPE, apiMessage.getCreateCartInvalidDiseaseType());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.EMPTY_CART_NAME, apiMessage.getCreateCartEmptyCartName());


        // Get cart api message
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.SUCCESS, apiMessage.getGetCartsSuccessMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.CART_NOT_EXIST, apiMessage.getGetCartsSuccessMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_DISEASE_TYPE, apiMessage.getGetCartForUserInvalidDiseaseType());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.DB_CONNECT_FAILED, apiMessage.getGetCartContentBrokenSqlConnection());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.BAD_REQUEST, apiMessage.getGetCartsBadRequestMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.FORBIDDEN, apiMessage.getGetCartsForbiddenMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INTERNAL_SERVER_ERROR, apiMessage.getGetCartsInternalServerErrorMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.MICROSERVICE_BROKEN, apiMessage.getGetCartBrokenMicroservice());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CART , ApiResponseEnum.INVALID_USER_ID), apiMessage.getGetCartInvalidAuthToken());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CART , ApiResponseEnum.CARTITEM_NOT_EXISTS_FOR_GIVEN_REQUEST + DOT), apiMessage.getGetCartsBadRequestMessage());

        //Delete cart api message
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.SUCCESS, apiMessage.getDeleteCartSuccessMessage());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.BAD_REQUEST, apiMessage.getDeleteCartBadRequestMessage());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.FORBIDDEN, apiMessage.getDeleteCartForbiddenMessage());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INTERNAL_SERVER_ERROR, apiMessage.getDeleteCartInternalServerErrorMessage());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_CART_ID, apiMessage.getDeleteCartInvalidCartId());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.DB_CONNECT_FAILED, apiMessage.getDeleteCartBrokenSqlConnection());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.MICROSERVICE_BROKEN, apiMessage.getDeleteCartBrokenConnection());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.CART_NOT_EXIST, apiMessage.getDeleteCartCartNotExist());
        apiMessageMap.put(ApiRequestEnum.DELETE_CART + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_AUTH_TOKEN, apiMessage.getDeleteCartInvalidAuthToken());

        // Create cart content api message
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.SUCCESS, apiMessage.getCreateCartContentSuccessMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART_CONTENT, ApiResponseEnum.INVALID_USER_ID), apiMessage.getCreateCartContentInvalidUser());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART_CONTENT , ApiResponseEnum.INVALID_CART_ID), apiMessage.getCreateCartContentInvalidCart());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CART_CONTENT ,ApiResponseEnum.INVALID_REQUEST), apiMessage.getCreateCartContentBadRequestMessage());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.FORBIDDEN, apiMessage.getCreateCartContentForbiddenMessage());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INTERNAL_SERVER_ERROR, apiMessage.getCreateCartContentInternalServerErrorMessage());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.DB_CONNECT_FAILED, apiMessage.getCreateCartContentBrokenSqlConnection());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.CART_NOT_CREATED_FOR_GIVEN_DISEASE_TYPE, apiMessage.getCreateCartContentOfNotCreatedDiseaseType());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_PATH, apiMessage.getCreateCartContentBlankPath());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.OBJECT_REFERENCE_NOT_SET_TO_AN_INSTANCE_OF_AN_OBJECT + DOT, apiMessage.getCreateCartContentBlankPath());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_ORDER, apiMessage.getCreateCartContentEmptyOrder());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_RESOLVER, apiMessage.getCreateCartContentWithNullResolver());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.MICROSERVICE_BROKEN, apiMessage.getCreateCartContentBrokenConnection());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_DISEASE_TYPE, apiMessage.getCreateCartInvalidDiseaseType());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_DATA, apiMessage.getCreateCartContentInvalidContent());
        apiMessageMap.put(ApiRequestEnum.CREATE_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.CART_NOT_CREATED, apiMessage.getCreateCartContentOfNotCreatedDiseaseType());

        // Get cart content api messages
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.SUCCESS, apiMessage.getGetCartContentSuccessMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.BAD_REQUEST, apiMessage.getGetCartContentBadRequestMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.FORBIDDEN, apiMessage.getGetCartContentForbiddenMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INTERNAL_SERVER_ERROR, apiMessage.getGetCartContentInternalServerErrorMessage());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.DB_CONNECT_FAILED, apiMessage.getGetCartContentBrokenSqlConnection());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.INVALID_UNIQUEKEY_OR_USERID, apiMessage.getGetCartContentInvalidUniqueKey());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.MICROSERVICE_BROKEN, apiMessage.getGetCartContentBrokenConnection());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.RESOLVER_NOT_FOUND, apiMessage.getGetCartContentWithNullResolver());
        apiMessageMap.put(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + ApiResponseEnum.CARTITEM_NOT_EXISTS_FOR_GIVEN_REQUEST+ DOT ,apiMessage.getGetCartContentApiNotCartAvailable());

        // Upload organization api messages
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.SUCCESS), apiMessage.getUploadLogoSuccessMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.ORGANIZATION_CREATE_SUCCESS), apiMessage.getUploadLogoSuccessMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.BAD_REQUEST), apiMessage.getUploadLogoBadRequestMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_REQUEST), apiMessage.getUploadLogoBadRequestMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.FORBIDDEN), apiMessage.getUploadLogoForbiddenMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INTERNAL_SERVER_ERROR), apiMessage.getUploadLogoInternalServerErrorMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.FILE_FORMAT_INVALID), apiMessage.getUploadLogoFileFormatInvalidMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.FILE_SIZE_EXCEED), apiMessage.getUploadLogoFileSizeExceedMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.MICROSERVICE_BROKEN), apiMessage.getUploadLogoBrokenConnection());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_FILE_NAME), apiMessage.getUploadLogoInvalidFileName());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_IMAGE_FILE), apiMessage.getUploadLogoInvalidImageFile());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_REDIRECT_URL), apiMessage.getUploadLogoInvalidRedirectUrl());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_USER_ID), apiMessage.getUploadLogoInvalidUserId());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.INVALID_LENGTH_FOR_A_BASE + BASESTRING) + ApiResponseEnum.CHAR_ARRAY_OR_STRING, apiMessage.getUploadLogoInvalidLengthBase64());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.CREATE_CUSTOMIZATION , ApiResponseEnum.CUSTOMIZATION_NAME_ALREADY_EXIST), apiMessage.getUploadLogoOrganizationAlreadyExist());


        // Get organization api messages
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.SUCCESS), apiMessage.getGetOrganizationApiSuccess());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.BAD_REQUEST), apiMessage.getGetOrganizationApiBadRequest());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.DB_CONNECT_FAILED), apiMessage.getGetOrganizationApiBrokenSqlConnection());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.FORBIDDEN), apiMessage.getGetOrganizationApiForbidden());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.INTERNAL_SERVER_ERROR), apiMessage.getGetOrganizationApiInternalServerError());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.MICROSERVICE_BROKEN), apiMessage.getGetOrganizationApiMicroserviceBroken());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.GET_CUSTOMIZATION , ApiResponseEnum.INVALID_USER_ID), apiMessage.getGetOrganizationApiInvalidUser());


        //GetOrganization Details
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.SUCCESS), apiMessage.getGetOrganizationDetailApiSuccess());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.BAD_REQUEST), apiMessage.getGetOrganizationDetailApiBadRequest());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.DB_CONNECT_FAILED), apiMessage.getGetOrganizationDetailApiBrokenSqlConnection());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.FORBIDDEN), apiMessage.getGetOrganizationDetailApiForbidden());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.INTERNAL_SERVER_ERROR), apiMessage.getGetOrganizationDetailApiInternalServerError());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.MICROSERVICE_BROKEN), apiMessage.getGetOrganizationDetailApiMicroserviceBroken());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.ORGANIZATION_DETAILS , ApiResponseEnum.INVALID_USER_ID), apiMessage.getGetOrganizationDetailApiResourceNotFound());

        //Update Cart
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.SUCCESS), apiMessage.getUpdateCartApiSuccess());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.BAD_REQUEST), apiMessage.getUpdateCartApiBadRequest());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.DB_CONNECT_FAILED), apiMessage.getUpdateCartApiBrokenSqlConnection());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.FORBIDDEN), apiMessage.getUpdateCartApiForbidden());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.INTERNAL_SERVER_ERROR), apiMessage.getUpdateCartApiInternalServerError());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.MICROSERVICE_BROKEN), apiMessage.getUpdateCartApiMicroserviceBroken());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_CART , ApiResponseEnum.INVALID_USER_ID), apiMessage.getUpdateCartApiResourceNotFound());

        //Update organization

        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.ORGANIZATION_UPDATED_SUCCESSFULLY), apiMessage.getUpdateOrganizationApiSuccess());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.BAD_REQUEST), apiMessage.getCreateCartBadRequestMessage());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.DB_CONNECT_FAILED), apiMessage.getUpdateOrganizationApiBrokenSqlConnection());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.FORBIDDEN), apiMessage.getUpdateOrganizationApiForbidden());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.INTERNAL_SERVER_ERROR), apiMessage.getUpdateOrganizationApiInternalServerError());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.MICROSERVICE_BROKEN), apiMessage.getUpdateOrganizationApiMicroserviceBroken());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.INVALID_USER_ID), apiMessage.getUpdateOrganizationInvalidUserId());
        apiMessageMap.put(String.format(S_S,ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS , ApiResponseEnum.ORGANIZATION_NOT_EXIST), apiMessage.getUpdateOrganizationAlreadyExist());


        return apiMessageMap;
    }

    /**
     * Sets all messages in ApiMessage object based on provided
     * ContentDistributionMsgConfigServiceImpl.
     * @param config the configuration object to set the messages from
     * @return the updated ApiMessage object
     */
    public static ApiMessage setMessages(final ContentDistributionMsgConfigServiceImpl.ContentDistributionApiMsgConfig config) {
        ApiMessage apiMessage = new ApiMessage();

        apiMessage.setGetCartsSuccessMessage(config.getCartApiSuccessMessageConfig());
        apiMessage.setGetCartsBadRequestMessage(config.getCartApiBadRequestMessageConfig());
        apiMessage.setGetCartsForbiddenMessage(config.getCartApiForbiddenMessageConfig());
        apiMessage.setGetCartsInternalServerErrorMessage(config.getCartApiInternalServerErrorMessageConfig());
        apiMessage.setGetCartInvalidAuthToken(config.getCartApiInvalidAuthToken());
        apiMessage.setGetCartBrokenMicroservice(config.getCartApiBrokenMicroservice());
        apiMessage.setGetCartForUserInvalidDiseaseType(config.getCartApiForUserInvalidDiseaseType());
        apiMessage.setGetCartBrokenSqlConnection(config.getCartApiBrokenSqlConnection());


        apiMessage.setGetCartContentSuccessMessage(config.getCartContentApiSuccessMessageConfig());
        apiMessage.setGetCartContentBadRequestMessage(config.getCartContentApiBadRequestMessageConfig());
        apiMessage.setGetCartContentForbiddenMessage(config.getCartContentApiForbiddenMessageConfig());
        apiMessage.setGetCartContentInternalServerErrorMessage(config.getCartContentApiInternalServerErrorMessageConfig());
        apiMessage.setGetCartContentBrokenSqlConnection(config.getCartContentApiBrokenSqlConnection());
        apiMessage.setGetCartContentBrokenConnection(config.getCartContentApiBrokenMicroserviceConnection());
        apiMessage.setGetCartContentInvalidUniqueKey(config.getCartContentApiInvalidUniqueKey());
        apiMessage.setGetCartContentWithNullResolver(config.getCartContentApiWithNullResolver());
        apiMessage.setGetCartContentApiNotCartAvailable(config.getCartContentApiNotCartAvailable());

        apiMessage.setCreateCartContentSuccessMessage(config.createCartContentApiSuccessMessageConfig());
        apiMessage.setCreateCartContentInvalidUser(config.getCartContentApiInvalidUserIdConfig());
        apiMessage.setCreateCartContentBadRequestMessage(config.createCartContentApiBadRequestMessageConfig());
        apiMessage.setCreateCartContentForbiddenMessage(config.createCartContentApiForbiddenMessageConfig());
        apiMessage.setCreateCartContentInternalServerErrorMessage(config.createCartContentApiInternalServerErrorMessageConfig());
        apiMessage.setCreateCartContentBrokenSqlConnection(config.createCartContentApiBrokenSqlConnection());
        apiMessage.setCreateCartContentBlankPath(config.createCartContentApiBlankPath());
        apiMessage.setCreateCartContentEmptyOrder(config.createCartContentApiEmptyOrder());
        apiMessage.setCreateCartContentWithNullResolver(config.createCartContentApiWithNullResolver());
        apiMessage.setCreateCartInvalidDiseaseType(config.createCartApiInvalidDiseaseType());
        apiMessage.setCreateCartEmptyCartName(config.createCartApiEmptyCartName());
        apiMessage.setCreateCartContentBrokenConnection(config.createCartContentApiMicroserviceBrokenConnection());
        apiMessage.setCreateCartContentOfNotCreatedDiseaseType(config.createCartContentApiOfNotCreatedDiseaseType());
        apiMessage.setCreateCartContentInvalidContent(config.createCartContentApiInvalidContent());


        apiMessage.setCreateCartSuccessMessage(config.createCartApiSuccessMessageConfig());
        apiMessage.setCreateCartBadRequestMessage(config.createCartApiBadRequestMessageConfig());
        apiMessage.setCreateCartsForbiddenMessage(config.createCartApiForbiddenMessageConfig());
        apiMessage.setCreateCartInternalServerErrorMessage(config.createCartApiInternalServerErrorMessageConfig());
        apiMessage.setCreateCartInvalidAuthToken(config.createCartApiInvalidAuthToken());
        apiMessage.setCreateCartBrokenMicroservice(config.createCartApiBrokenMicroservice());
        apiMessage.setCreateCartMoreThanFiftyChar(config.createCartApiMoreThanFiftyChar());
        apiMessage.setCreateCartBrokenSqlConnection(config.createCartApiBrokenSqlConnection());
        apiMessage.setCreateCartMaxLimitReach(config.createCartApiMaxLimitReach());

        apiMessage.setDeleteCartSuccessMessage(config.deleteCartApiSuccessMessageConfig());
        apiMessage.setDeleteCartBadRequestMessage(config.deleteCartApiBadRequestMessageConfig());
        apiMessage.setDeleteCartForbiddenMessage(config.deleteCartApiForbiddenMessageConfig());
        apiMessage.setDeleteCartInternalServerErrorMessage(config.deleteCartApiInternalServerErrorMessageConfig());
        apiMessage.setDeleteCartBrokenConnection(config.deleteCartApiBrokenConnection());
        apiMessage.setDeleteCartBrokenSqlConnection(config.deleteCartApiBrokenSqlConnection());
        apiMessage.setDeleteCartInvalidCartId(config.deleteCartApiInvalidCartId());
        apiMessage.setDeleteCartCartNotExist(config.deleteCartApiCartNotExist());
        apiMessage.setDeleteCartInvalidAuthToken(config.deleteCartApiInvalidAuthToken());

        apiMessage.setUploadLogoSuccessMessage(config.uploadLogoApiSuccessMessageConfig());
        apiMessage.setUploadLogoBadRequestMessage(config.uploadLogoApiBadRequestMessageConfig());
        apiMessage.setUploadLogoInternalServerErrorMessage(config.uploadLogoApiInternalServerErrorMessageConfig());
        apiMessage.setUploadLogoForbiddenMessage(config.uploadLogoApiForbiddenMessageConfig());
        apiMessage.setUploadLogoFileSizeExceedMessage(config.uploadLogoApiFileSizeExceedMessageConfig());
        apiMessage.setUploadLogoFileFormatInvalidMessage(config.uploadLogoApiFileFormatErrorMessageConfig());
        apiMessage.setUploadLogoBrokenConnection(config.uploadLogoApiBrokenConnection());
        apiMessage.setUploadLogoInvalidFileName(config.uploadLogoApiInvalidFileNameMessageConfig());
        apiMessage.setUploadLogoInvalidImageFile(config.uploadLogoApiInvalidImageFileMessageConfig());
        apiMessage.setUploadLogoInvalidRedirectUrl(config.uploadLogoApiInvalidRedirectUrlMessageConfig());
        apiMessage.setUploadLogoInvalidUserId(config.uploadLogoApiInvalidUserIdMessageConfig());
        apiMessage.setUploadLogoInvalidLengthBase64(config.uploadLogoApiInvalidLengthBase64());
        apiMessage.setUploadLogoOrganizationAlreadyExist(config.uploadLogoApiOrganizationAlreadyExist());


        apiMessage.setGetOrganizationApiBadRequest(config.getOrganizationApiBadRequestMessageConfig());
        apiMessage.setGetOrganizationApiSuccess(config.getOrganizationApiSuccessMessageConfig());
        apiMessage.setGetOrganizationApiForbidden(config.getOrganizationApiForbiddenMessageConfig());
        apiMessage.setGetOrganizationApiMicroserviceBroken(config.getOrganizationApiMicroserviceBrokenConnection());
        apiMessage.setGetOrganizationApiBrokenSqlConnection(config.getOrganizationApiBrokenSqlConnection());
        apiMessage.setGetOrganizationApiInternalServerError(config.getOrganizationApiInternalServerErrorMessageConfig());
        apiMessage.setGetOrganizationApiInvalidUser(config.getOrganizationApiInvalidUserConfig());

        apiMessage.setGetOrganizationDetailApiBadRequest(config.getOrganizationDetailApiBadRequestMessageConfig());
        apiMessage.setGetOrganizationDetailApiSuccess(config.getOrganizationDetailApiSuccessMessageConfig());
        apiMessage.setGetOrganizationDetailApiForbidden(config.getOrganizationDetailApiForbiddenMessageConfig());
        apiMessage.setGetOrganizationDetailApiMicroserviceBroken(config.getOrganizationDetailApiMicroserviceBrokenConnection());
        apiMessage.setGetOrganizationDetailApiBrokenSqlConnection(config.getOrganizationDetailApiBrokenSqlConnection());
        apiMessage.setGetOrganizationDetailApiInternalServerError(config.getOrganizationDetailApiInternalServerErrorMessageConfig());
        apiMessage.setGetOrganizationDetailApiResourceNotFound(config.getOrganizationDetailApiResourceNotFoundConfig());

        apiMessage.setUpdateCartApiBadRequest(config.getUpdateCartApiBadRequestMessageConfig());
        apiMessage.setUpdateCartApiSuccess(config.getUpdateCartApiSuccessMessageConfig());
        apiMessage.setUpdateCartApiForbidden(config.getUpdateCartApiForbiddenMessageConfig());
        apiMessage.setUpdateCartApiMicroserviceBroken(config.getUpdateCartApiMicroserviceBrokenConnection());
        apiMessage.setUpdateCartApiBrokenSqlConnection(config.getUpdateCartApiBrokenSqlConnection());
        apiMessage.setUpdateCartApiInternalServerError(config.getUpdateCartApiInternalServerErrorMessageConfig());
        apiMessage.setUpdateCartApiResourceNotFound(config.getUpdateCartApiResourceNotFoundConfig());

        apiMessage.setUpdateOrganizationApiBadRequest(config.getUpdateOrganizationApiBadRequestMessageConfig());
        apiMessage.setUpdateOrganizationApiSuccess(config.getUpdateOrganizationApiSuccessMessageConfig());
        apiMessage.setUpdateOrganizationApiForbidden(config.getUpdateOrganizationApiForbiddenMessageConfig());
        apiMessage.setUpdateOrganizationApiMicroserviceBroken(config.getUpdateOrganizationApiMicroserviceBrokenConnection());
        apiMessage.setUpdateOrganizationApiBrokenSqlConnection(config.getUpdateOrganizationApiBrokenSqlConnection());
        apiMessage.setUpdateOrganizationApiInternalServerError(config.getUpdateOrganizationApiInternalServerErrorMessageConfig());
        apiMessage.setUpdateOrganizationAlreadyExist(config.getUpdateOrganizationApiNotExistConfig());
        apiMessage.setUpdateOrganizationInvalidUserId(config.getUpdateOrganizationApiInvalidUserConfig());

        return apiMessage;
    }
}
