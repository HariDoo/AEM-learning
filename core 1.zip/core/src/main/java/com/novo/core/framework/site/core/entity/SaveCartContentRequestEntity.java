package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * Represents a SaveCartContentRequestEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class SaveCartContentRequestEntity {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String authToken;
    private String diseaseType;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer cartId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long userId;
    private List<ContentDataEntity> contentData;
    /**
     *This field holds the details of the
     * organization for the request entity
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private OrganizationDetailsRequestEntity organizationDetails;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getDiseaseType() {
        return diseaseType;
    }

    public void setDiseaseType(String diseaseType) {
        this.diseaseType = diseaseType;
    }

    public OrganizationDetailsRequestEntity getOrganizationDetails() {
        return organizationDetails;
    }

    public void setOrganizationDetails(OrganizationDetailsRequestEntity organizationDetails) {
        this.organizationDetails = organizationDetails;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public List<ContentDataEntity> getContentData() {
        return contentData;
    }

    public void setContentData(List<ContentDataEntity> contentData) {
        this.contentData = contentData;
    }

}

