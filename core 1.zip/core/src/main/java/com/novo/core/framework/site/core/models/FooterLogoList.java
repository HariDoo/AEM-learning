package com.novo.core.framework.site.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;

import javax.inject.Inject;

@Model(adaptables = Resource.class)
public class FooterLogoList {

    @Inject
    @Optional
    private String icon;

    @Inject
    @Optional
    private String iconAltText;

    @Inject
    @Optional
    private Boolean imageIsDecorative;

    @Inject
    @Optional
    private String logoWidth;

    @Inject
    @Optional
    private String logoWidthMobile;

    @Inject
    @Optional
    private String linkUrl;

    @Inject
    @Optional
    private String linkExitModal;

    public String getLinkLogo() {
        return icon;
    }

    public void setLinkLogo(String icon) {
        this.icon = icon;
    }

    public String getLinkLogoAltText() {
        return iconAltText;
    }

    public void setLinkLogoAltText(String iconAltText) {
        this.iconAltText = iconAltText;
    }

    public void setImageIsDecorative(Boolean imageIsDecorative) { this.imageIsDecorative = imageIsDecorative; }

    public Boolean getImageIsDecorative() { return this.imageIsDecorative; }

    public String getLinkWidth() {
        return logoWidth;
    }

    public void setLinkWidth(String logoWidth) {
        this.logoWidth = logoWidth;
    }

    public String getLinkWidthMobile() {
        return logoWidthMobile;
    }

    public void setLinkWidthMobile(String logoWidthMobile) {
        this.logoWidthMobile = logoWidthMobile;
    }

    public String getLinkUrl() {
        return linkUrl;
    }

    public void setLinkUrl(String linkUrl) {
        this.linkUrl = linkUrl;
    }

    public String getLinkExitModal() {
        return linkExitModal;
    }

    public void setLinkExitModal(String linkExitModal) {
        this.linkExitModal = linkExitModal;
    }

}
