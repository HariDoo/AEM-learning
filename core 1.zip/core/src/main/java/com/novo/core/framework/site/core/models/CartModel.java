package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.Page;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;


@Model(adaptables = SlingHttpServletRequest.class)
public class CartModel {

    Logger log = LoggerFactory.getLogger(this.getClass());
    @Inject
    private Page currentPage;

    @Inject
    @Optional
    @Via("resource")
    private String cartIcon;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "alt")
    private String cartIconAlt;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "Carts Summary")
    private String cartTitle;

    @Inject
    @Optional
    @Via("resource")
    private String staticMsg;

    @Inject
    @Optional
    @Via("resource")
    private String defaultThumbnail;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "You have successfully saved the cart. Please use this link: <a href='publishedLink'>Link to cart</a>")
    private String saveSuccess;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "There are no items in your cart")
    private String emptyCartMsg;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "Clear Cart")
    private String clearCartText;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "Save Cart")
    private String saveButtonText;

    @Inject
    @Optional
    @Via("resource")
    @Default(values = "Remove from Cart")
    private String removeFromCartText;

    @Inject
    @Optional
    @Via("resource")
    private String attestationMessage;

    @Inject
    @Optional
    @Via("resource")
    private String attCheckBoxText;

    @Inject
    @Optional
    @Via("resource")
    private String attValidationMessage;

    @SlingObject
    private Resource currentResource;

    @SlingObject
    private ResourceResolver resourceResolver;

    private Boolean enableCart = Boolean.FALSE;

    @PostConstruct
    protected void init() {
        log.info("Inside the Cart model");
        ValueMap valueMap = currentPage.getProperties();
        if(currentPage.getPath().contains("/content/experience-fragments/")){
            enableCart = Boolean.TRUE;
        }
        if(null!=valueMap.get("enableCart")){
            enableCart = valueMap.get("enableCart",String.class).equalsIgnoreCase("false") ? Boolean.TRUE : Boolean.FALSE;
        }
    }

    public String getCartIcon() {
        return cartIcon;
    }

    public String getCartIconAlt() {
        return cartIconAlt;
    }

    public Boolean getEnableCart() {
        return enableCart;
    }

    public String getCartTitle() {
        return cartTitle;
    }

    public String getStaticMsg() {
        return staticMsg;
    }

    public String getDefaultThumbnail() {
        return defaultThumbnail;
    }

    public String getSaveSuccess() {
        return saveSuccess;
    }

    public String getEmptyCartMsg() {
        return emptyCartMsg;
    }

    public String getClearCartText() {
        return clearCartText;
    }

    public String getSaveButtonText() {
        return saveButtonText;
    }

    public String getRemoveFromCartText() {
        return removeFromCartText;
    }

    public String getAttestationMessage() {
        return attestationMessage;
    }

    public String getAttCheckBoxText() {
        return attCheckBoxText;
    }

    public String getAttValidationMessage() {
        return attValidationMessage;
    }
}