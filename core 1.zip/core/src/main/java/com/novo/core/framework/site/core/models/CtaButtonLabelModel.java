package com.novo.core.framework.site.core.models;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.models.beans.Button;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

/**
 * Model used to get the button labels for publish cart functionality
 * 
 * @since 1.0
 * @version 1.0
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CtaButtonLabelModel {
    @Inject
    private SlingHttpServletRequest request;

    @ChildResource
    private Resource ctaButtonLabel;

    List<Button> buttonList = new ArrayList<>();

    private String btnRes = StringUtils.EMPTY;
    @PostConstruct
    protected void init(){
      if(ctaButtonLabel != null && ctaButtonLabel.hasChildren()){
          for (Resource resource: ctaButtonLabel.getChildren()
               ) {if(resource!= null){
                   Button buttonObj = resource.adaptTo(Button.class);
                   buttonList.add(buttonObj);
             }
          }
          btnRes = new Gson().toJson(buttonList);
      }
    }
    public String getBtnRes() { return btnRes; }

}
