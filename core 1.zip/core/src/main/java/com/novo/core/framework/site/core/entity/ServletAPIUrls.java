package com.novo.core.framework.site.core.entity;

/**
 * Represents a ServletAPIUrls
 *
 * @version 1.0
 * @since 1.0
 */
public class ServletAPIUrls {
    private String cartAPI;

    private String updateCartAPI;
    private String cartContentAPI;
    private String publishCartContentAPI;
    private String resourceType;
    private String uploadLogoAPI;

    /**
     * This field stores the API endpoint for
     *  organization details
     */
    private String organizationDetailsAPI;
    private String deleteCartApi;
    /**
     * This field stores the API endpoint for
     *  update OrganizationDetails Api details
     */
    private String updateOrganizationDetailsApi;

    /**
     * This field stores the API endpoint for
     *  get cart details Api details
     */
    private String cartDetailsDetailsApi;

    public String getCartAPI() {
        return cartAPI;
    }

    public void setCartAPI(String cartAPI) {
        this.cartAPI = cartAPI;
    }

    public String getCartContentAPI() {
        return cartContentAPI;
    }

    public void setCartContentAPI(String cartContentAPI) {
        this.cartContentAPI = cartContentAPI;
    }

    public String getPublishCartContentAPI() {
        return publishCartContentAPI;
    }

    public void setPublishCartContentAPI(String publishCartContentAPI) {
        this.publishCartContentAPI = publishCartContentAPI;
    }

    public String getResourceType() {
        return resourceType;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public String getUploadLogoAPI() {
        return uploadLogoAPI;
    }

    public void setUploadLogoAPI(String uploadLogoAPI) {
        this.uploadLogoAPI = uploadLogoAPI;
    }

    public String getOrganizationDetailsAPI() {
        return organizationDetailsAPI;
    }

    public void setOrganizationDetailsAPI(String organizationDetailsAPI) {
        this.organizationDetailsAPI = organizationDetailsAPI;
    }

    public String getDeleteCartApi() { return deleteCartApi; }

    public void setDeleteCartApi(String deleteCartApi) { this.deleteCartApi = deleteCartApi; }

    public String getUpdateOrganizationDetailsApi() {
        return updateOrganizationDetailsApi;
    }

    public void setUpdateOrganizationDetailsApi(String updateOrganizationDetailsApi) {
        this.updateOrganizationDetailsApi = updateOrganizationDetailsApi;
    }

    public String getUpdateCartAPI() {
        return updateCartAPI;
    }

    public void setUpdateCartAPI(String updateCartAPI) {
        this.updateCartAPI = updateCartAPI;
    }

    public String getCartDetailsDetailsApi() {
        return cartDetailsDetailsApi;
    }

    public void setCartDetailsDetailsApi(String cartDetailsDetailsApi) {
        this.cartDetailsDetailsApi = cartDetailsDetailsApi;
    }
}
