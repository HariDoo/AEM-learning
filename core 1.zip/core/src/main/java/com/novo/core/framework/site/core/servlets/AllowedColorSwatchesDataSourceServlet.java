package com.novo.core.framework.site.core.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.policies.ContentPolicy;
import com.day.cq.wcm.api.policies.ContentPolicyManager;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.jetbrains.annotations.NotNull;
import org.osgi.service.component.annotations.Component;

/**
 * Get the color swatches as a SimpleDataSource Object.
 * 
 * This is a custom implementation of <a href="https://git.io/JvTBQ">AllowedColorSwatchesDataSourceServlet.java</a>,
 * that give us compatibility with the colorfield as a RTE plugin.
 *
 */
@Component(service = { Servlet.class }, property = {
        "sling.servlet.resourceTypes=" + AllowedColorSwatchesDataSourceServlet.RESOURCE_TYPE,
        "sling.servlet.methods=GET", "sling.servlet.extensions=html" })
public class AllowedColorSwatchesDataSourceServlet extends SlingSafeMethodsServlet {

    private static final long serialVersionUID = 1L;
    private static final String PN_COLOR_VALUE = "value";
    private static final String CONTENTPATH = "content-path";
    private static final String PN_ALLOWED_COLOR_SWATCHES = "allowedColorSwatches";

    protected static final String RESOURCE_TYPE = "novo-core-framework/site/datasources/allowedcolorswatches";

    @Override
    protected void doGet(@NotNull SlingHttpServletRequest request, @NotNull SlingHttpServletResponse response)
            throws ServletException, IOException {
        SimpleDataSource allowedColorSwatchesDataSource = new SimpleDataSource(
                getAllowedColorSwatches(request).iterator());
        request.setAttribute(DataSource.class.getName(), allowedColorSwatchesDataSource);
    }

    protected List<Resource> getAllowedColorSwatches(@NotNull SlingHttpServletRequest request) {
        final List<Resource> colors = new ArrayList<>();
        final ResourceResolver resolver = request.getResourceResolver();
        final String contentPath = (String) request.getParameter(CONTENTPATH);

        if (contentPath == null || contentPath.isEmpty()) {
            return colors;
        }

        final Resource contentResource = resolver.getResource(contentPath);
        final ContentPolicyManager policyManager = resolver.adaptTo(ContentPolicyManager.class);

        if (contentResource == null || policyManager == null) {
            return colors;
        }

        final ContentPolicy policy = policyManager.getPolicy(contentResource);

        if (policy == null) {
            return colors;
        }

        ValueMap color = null;
        final ValueMap properties = policy.getProperties();

        if (properties == null) {
            return colors;
        }

        final String[] allowedColorSwatches = properties.get(PN_ALLOWED_COLOR_SWATCHES, new String[0]);

        for (String allowedColorSwatch : allowedColorSwatches) {
            color = new ValueMapDecorator(new HashMap<String, Object>());
            color.put(PN_COLOR_VALUE, allowedColorSwatch);
            colors.add(new ValueMapResource(resolver, new ResourceMetadata(), JcrConstants.NT_UNSTRUCTURED, color));
        }

        return colors;
    }
}