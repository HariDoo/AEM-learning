package com.novo.core.framework.site.core.models;

import org.apache.commons.collections.CollectionUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static org.apache.sling.api.resource.ResourceResolver.PROPERTY_RESOURCE_TYPE;

@Model(adaptables = Resource.class)
public class GlobalNavigationModel {

    @ValueMapValue(name = PROPERTY_RESOURCE_TYPE, injectionStrategy = InjectionStrategy.OPTIONAL)
    @Default(values = "No resourceType")
    protected String resourceType;

    @Inject
    @Optional
    private List<Resource> globalNavigationList;

    @Inject
    @Optional
    private List<Resource> globalNavigationSecondRowList;

    @Inject
    @Optional
    private List<Resource> dropdownLinksList;

    @SlingObject
    private ResourceResolver resourceResolver;

    public List<GlobalNavigationList> globalNavigation = new ArrayList<>();
    public List<GlobalNavigationList> globalNavigationSecondRow = new ArrayList<>();
    public List<GlobalNavigationList> dropdownLinks = new ArrayList<>();


    @PostConstruct
    protected void init() {
    	if (globalNavigationList != null) {
	        if (!globalNavigationList.isEmpty()) {
	            for (Resource resource : globalNavigationList) {
	                GlobalNavigationList navigationItem = resource.adaptTo(GlobalNavigationList.class);
                    navigationItem.setLinkUrl(getUrl(navigationItem.getLinkUrl()));
	                globalNavigation.add(navigationItem);
	            }

	        }
    	}

        if (CollectionUtils.isNotEmpty(globalNavigationSecondRowList)) {
            globalNavigationSecondRowList
                    .stream()
                    .map(resource -> resource.adaptTo(GlobalNavigationList.class))
                    .peek(navigationItem -> navigationItem.setLinkUrl(getUrl(navigationItem.getLinkUrl())))
                    .forEach(globalNavigationSecondRow::add);
        }

        if (CollectionUtils.isNotEmpty(dropdownLinksList)) {
            dropdownLinksList
                    .stream()
                    .map(resource -> resource.adaptTo(GlobalNavigationList.class))
                    .peek(navigationItem -> navigationItem.setLinkUrl(getUrl(navigationItem.getLinkUrl())))
                    .forEach(dropdownLinks::add);
        }
    }

    public String getUrl(String link) {
        if (link != null) {
            Resource pathResource = resourceResolver.getResource(link);
            // check if resource exists and resource is not a dam object
            if (pathResource != null && link.indexOf("/content/dam") != 0) {
                // append .html
                return resourceResolver.map(link) + ".html";
            }
        }
        return link;
    }

    public boolean getIsEmpty() {
        return globalNavigation.isEmpty();
    }

    public List<GlobalNavigationList> getGlobalNavigation() {
        return globalNavigation;
    } 

    public void setGlobalNavigation(List<GlobalNavigationList> globalNavigation) {
        this.globalNavigation = globalNavigation;
    }

    public boolean isGlobalNavigationSecondRowNotEmpty() {
        return !globalNavigationSecondRow.isEmpty();
    }

    public List<GlobalNavigationList> getGlobalNavigationSecondRow() {
        return globalNavigationSecondRow;
    }

    public void setGlobalNavigationAlternative(final List<GlobalNavigationList> globalNavigationSecondRow) {
        this.globalNavigationSecondRow = globalNavigationSecondRow;
    }

    public List<GlobalNavigationList> getDropdownLinks() {
        return dropdownLinks;
    }

    public void setDropdownLinks(final List<GlobalNavigationList> dropdownLinks) {
        this.dropdownLinks = dropdownLinks;
    }

}
