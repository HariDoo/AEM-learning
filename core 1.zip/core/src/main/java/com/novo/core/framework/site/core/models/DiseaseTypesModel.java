package com.novo.core.framework.site.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Model to be used to fetch the content from
 * components multi field node structure
 *
 * @since 1.0
 * @version 1.0
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class DiseaseTypesModel {

    @ChildResource
    private Resource diseaseTypes;

    @ValueMapValue
    private String[] hideDiseaseTag;

    public String[] getHideDiseaseTag() {
        return hideDiseaseTag;
    }

    private List<DiseaseType> diseaseTypesList = new ArrayList<>();


    @PostConstruct
    protected void init() {
        if (diseaseTypes != null && diseaseTypes.hasChildren()) {
            for (Resource resource : diseaseTypes.getChildren()
            ) {
                if (resource != null) {
                    DiseaseType diseaseType = resource.adaptTo(DiseaseType.class);
                    diseaseTypesList.add(diseaseType);
                }
            }
        }
    }

    public List<DiseaseType> getDiseaseTypesList() {
        return diseaseTypesList;
    }
}
