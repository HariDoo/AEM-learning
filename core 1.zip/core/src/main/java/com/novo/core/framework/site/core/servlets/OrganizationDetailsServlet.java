package com.novo.core.framework.site.core.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * GET method that can be used to get the organization details
 * check the component annotations to understand the API signatures.
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=novo-core-framework/site/components/content/educationcenter/createCustomization",
        "sling.servlet.selectors=organizationDetailsApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.extensions=json"})
public class OrganizationDetailsServlet extends SlingSafeMethodsServlet {
    /**
     * This is a logger for the OrganizationDetailsServlet class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(OrganizationDetailsServlet.class);

    /**
     * This is a serialVersionUID for properly serialization and deserialization in different environments.
     */
    private static final long serialVersionUID = 1L;

    /**
     * Service for managing configuration of content
     * distribution messages.
     */
    @Reference
    private  ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    /**
     * This field represents a reference to the CartService.
     */
    @Reference
    private  CartService cartService;

    /**
     * GET method that fetch organization data from the .NET API
     *
     * @param request  {@link CartRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doGet(@NotNull SlingHttpServletRequest request, @NotNull SlingHttpServletResponse response)
            throws ServletException, IOException {
        final  CartRequestEntity cartRequestEntity = CartUtils.getOrganizationDetailsEntityFromRequest(request);
        ClientResponse clientResponse;
        try {
            // validating servlet request
            CartUtils.validateRequestGetCustomizations(cartRequestEntity, contentDistributionMsgConfigService);
            clientResponse = cartService.getUserProfile(cartRequestEntity.getAuthToken());
            final long userId = CartUtils.getIdFromUserObj(clientResponse);

            if (userId == 0) {
                ResponseEntity<OrganizationDetailsRequestEntity> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Not able to get the successful profile object created");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_ORGANIZATION_DETAIL_USERID_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            cartRequestEntity.setUserId(userId);
            clientResponse = cartService.getOrganizationDetails(cartRequestEntity);
            if(clientResponse!=null && StringUtils.isNotBlank(clientResponse.getData())){

                final ObjectMapper objectMapper = new ObjectMapper();
                ResponseEntity<OrganizationDetailsRequestEntity> responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                final String  message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.ORGANIZATION_DETAILS + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                if(clientResponse.getStatusCode() != HttpServletResponse.SC_OK){
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                    return;
                }
                final OrganizationDetailsRequestEntity organizationDetails = CartUtils.getOrganizationDetailsData(clientResponse);
                responseEntity.setData(organizationDetails);
                responseEntity.setMessage(message);
                // sending back the API response
                CartUtils.sendAPIResponse(response, responseEntity, clientResponse.getStatusCode());
            }

        }catch (CartServletException ce) {
            ResponseEntity<OrganizationDetailsRequestEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error("Error getting request parameters :: OrganizationDetailsServlet() :: doGet {0}", ce);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        } catch (IOException ioException) {
            ResponseEntity<OrganizationDetailsRequestEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException  :: OrganizationDetailsServlet() :: doGet {0}", ioException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_ORGANIZATION_DETAIL_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        catch (JSONException ioJSONe) {
            ResponseEntity<OrganizationDetailsRequestEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error(" JSONException :: OrganizationDetailsServlet() :: doGet {0}", ioJSONe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_ORGANIZATION_DETAIL_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
