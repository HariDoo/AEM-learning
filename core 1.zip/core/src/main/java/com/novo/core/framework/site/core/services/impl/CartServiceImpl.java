package com.novo.core.framework.site.core.services.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.RestService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletResponse;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static com.novo.core.framework.site.core.constants.MessageConstant.*;
import static com.novo.core.framework.site.core.constants.MessageConstant.GET_CART_INTERNAL_SERVER_ERROR;

/**
 * Cart service impl containing methods related to cart level
 * implements {@link CartService}
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = CartService.class,immediate = true)
public class CartServiceImpl implements CartService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);
    public static final String DISEASE_TYPE_PARAM = "&diseaseType=";
    /**
     * This variable represents a parameter or key used
     * to identify a user in the system.
     */
    public static final String USER_ID_PARAM_OR_KEY = "?cartIdOruniqueKey=";
    /**
     * This variable represents a parameter or key used
     * to identify a unique record or object in
     */
    public static final String   UNIQUE_KEY =  "?uniqueKey=";
    public static final String USER_ID_PARAM = "?userId=";
    public static final String CART_ID_PARAM = "?cartId=";
    /**
     * This variable represents a parameter or key used
     * to identify a unique organization record or object in
     */
    public static final String ORGANIZATION_ID = "?organizationId=";
    /**
     * This variable represents a log message printed
     * when the getCart method of the CartServiceImpl class
     * is called, indicating a composed URL and including
     * information about the method and class.
     */
    public static final String COMPOSED_URL_CART_SERVICE_IMPL_GET_CART = "Composed url :: CartServiceImpl() :: getCart {}";
    /**
     * This variable represents a regular expression that
     * matches any newline or carriage return character
     * in a string, and can be used for cleaning up text.
     */
    public static final String REGEX = "[\n\r]";

    @Reference
    RestService restService;

    final Map<String,String> headers = new HashMap<>();


    /**
     * This field is used to store the value of parameterKey
     */
    private String parameterKey;

    @Override
    public ClientResponse createCart(final CartRequestEntity cartRequestEntity) throws  IOException {
        String url = restService.getRestAPIBaseUrl()+restService.getRestAPICreateCartAPIUrl();
        LOGGER.debug("Composed url :: CartServiceImpl() :: createCart {}",url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendPOST(url, new Gson().toJson(cartRequestEntity),headers);
    }

    @Override
    public ClientResponse updateCart(final CartRequestEntity cartRequestEntity) throws  IOException {
        final  String cartName = getEncodedCartName(cartRequestEntity.getCartName());
        final  String url = restService.getRestAPIBaseUrl()+restService.getRestAPIUpdateCartAPIUrl() + ORGANIZATION_ID + cartRequestEntity.getOrganizationId()
                + "&cartId=" + cartRequestEntity.getCartId()
                + "&cartName=" + cartName;
        LOGGER.debug("Composed url :: CartServiceImpl() :: updateCart {}",url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendPUT(url, new Gson().toJson(cartRequestEntity),headers);
    }

    private String getEncodedCartName(final String cartName) throws UnsupportedEncodingException {
        String encodedString = null;
        encodedString = URLEncoder.encode(cartName, StandardCharsets.UTF_8.name())
                .replace("+", "%20");
        return encodedString;
    }

    @Override
    public ClientResponse getCart(final CartRequestEntity cartRequestEntity) throws  IOException {
        String url = restService.getRestAPIBaseUrl() + restService.getRestAPIGetCartAPIUrl() + USER_ID_PARAM + cartRequestEntity.getUserId() + DISEASE_TYPE_PARAM + cartRequestEntity.getDiseaseType();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Composed url :: CartServiceImpl() :: GetCart {}",  "***REDACTED***");
        }
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendGET(url,headers);
    }

    @Override
    public ClientResponse getCustomization(final CartRequestEntity cartRequestEntity) throws  IOException {
        final String url =  restService.getRestAPIBaseUrl()+restService.getRestAPIGetCustomization()+ USER_ID_PARAM +cartRequestEntity.getUserId();
        LOGGER.debug(COMPOSED_URL_CART_SERVICE_IMPL_GET_CART,url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendGET(url,headers);
    }

    @Override
    public ClientResponse getOrganizationDetails(final CartRequestEntity cartRequestEntity) throws  IOException {
        final String url =  restService.getRestAPIBaseUrl()+restService.getRestAPIGetOrganizationDetails() + ORGANIZATION_ID + cartRequestEntity.getOrganizationId();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Composed url :: CartServiceImpl() :: getOrganizationDetails {}",  "***REDACTED***");
        }
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendGET(url,headers);
    }

    @Override
    public ClientResponse getCartContent(final SaveCartContentRequestEntity cartContentRequestEntity) throws IOException {

        if (cartContentRequestEntity.getCartId() != null) {
            final Integer cartId = cartContentRequestEntity.getCartId();
            parameterKey = cartId.toString();
        } else {
            parameterKey = cartContentRequestEntity.getAuthToken();
        }
        String url = restService.getRestAPIBaseUrl()+restService.getRestAPIGetCartContentAPIUrl()+ USER_ID_PARAM_OR_KEY +parameterKey;
        final String composedUrl = url.matches(REGEX) ? url.replaceAll(REGEX, "_") : url;
        LOGGER.debug("Composed url :: CartServiceImpl() :: getCartContent {}", composedUrl);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendGET(url,headers);
    }

    @Override
    public ClientResponse createCartContent(final SaveCartContentRequestEntity cartContentRequestEntity) throws IOException {
        String url = restService.getRestAPIBaseUrl()+restService.getRestAPIPostCartContentAPIUrl();
        LOGGER.debug("Composed url :: CartServiceImpl() :: createCartContent {}",url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendPOST(url, new Gson().toJson(cartContentRequestEntity),headers);
    }

    @Override
    public ClientResponse deleteCart(final CartEntity cartEntity) throws IOException {
        String url = restService.getRestAPIBaseUrl()+restService.getRestAPIDeleteCartAPIUrl()+ CART_ID_PARAM +cartEntity.getCartId();
        LOGGER.debug(COMPOSED_URL_CART_SERVICE_IMPL_GET_CART,url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendDELETE(url,headers);
    }

    @Override
    public ClientResponse getUserProfile(final String authToken) throws IOException {
        String url =restService.getRestNovoAuthUrl();
        LOGGER.debug("Composed url :: CartServiceImpl() :: createCartContent {}",url);
        final Map<String,String> authHeader = new HashMap<>();
        authHeader.put(CommonConstants.AUTHORIZATION,CommonConstants.TOKEN_STR+authToken);
        return CartUtils.sendGET(url,authHeader);
    }

    @Override
    public ClientResponse uploadLogo(final Object data) throws JSONException, IOException {
        final String url = restService.getRestAPIBaseUrl()+restService.getRestAPISubmitOrganization();
        LOGGER.debug("Composed url :: CartServiceImpl() :: uploadLogo {}",url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendPOST(url, new Gson().toJson(data),headers);
    }

    @Override
    public ClientResponse updateOrganization(final Object data) throws JSONException, IOException {
        final String url = restService.getRestAPIBaseUrl()+restService.getRestAPIUpdateOrganizationAPIUrl();
        LOGGER.debug("Composed url :: CartServiceImpl() :: updateOrganization {}",url);
        headers.put(CommonConstants.API_KEY, restService.getRestAPIAuthKey());
        return CartUtils.sendPUT(url, new Gson().toJson(data),headers);
    }

    @Override
    public void getCartDetails(@NotNull final SlingHttpServletResponse response,
                               CartRequestEntity cartRequestEntity, ContentDistributionMsgConfigService contentDistributionMsgConfigService,
                               CartService cartService,String publishPagePath) {

        try {
            // validating servlet request
            CartUtils.validateRequestGetCart(cartRequestEntity, contentDistributionMsgConfigService );
            ClientResponse clientResponse;

            // getting user profile from novo endpoint
            clientResponse = cartService.getUserProfile(cartRequestEntity.getAuthToken());
            final long userId  = CartUtils.getIdFromUserObj(clientResponse);

            if (userId == 0) {
                final ResponseEntity<CartResponseEntity> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Not able to get the successful profile object created");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_USERID_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            cartRequestEntity.setUserId(userId);
            // getting the carts from .net service

            clientResponse = cartService.getCart(cartRequestEntity);
            if(clientResponse!=null && StringUtils.isNotBlank(clientResponse.getData())){
                ResponseEntity<CartResponseEntity>  responseEntity ;
                final ObjectMapper objectMapper = new ObjectMapper();
                responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                final String  message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.GET_CART + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                if(clientResponse.getStatusCode() != HttpServletResponse.SC_OK){
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                    return;
                }
                final CartResponseEntity cartResponseEntity = CartUtils.getCartsResponseEntity(clientResponse,publishPagePath);
                responseEntity.setData(cartResponseEntity);
                responseEntity.setMessage(message);
                // sending back the API response
                CartUtils.sendAPIResponse(response, responseEntity, clientResponse.getStatusCode());
            }else{
                final ResponseEntity<CartResponseEntity> responseEntity = new ResponseEntity<>();
                LOGGER.debug("Cart is null :: CartAPIServlet() :: doGet {}", "Cart Not Found");
                responseEntity.setSuccess(false);
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_INTERNAL_SERVER_ERROR));
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            }
        } catch (CartServletException ce) {
            final ResponseEntity<CartResponseEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error("Error getting request parameters :: CartAPIServlet() :: doGet {0}", ce);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        } catch (IOException ioException) {
            final ResponseEntity<CartResponseEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error("IOException  :: CartAPIServlet() :: doGet {0}", ioException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
        catch (JSONException ioJSONe) {
            final ResponseEntity<CartResponseEntity> responseEntity = new ResponseEntity<>();
            LOGGER.error(" JSONException :: CartAPIServlet() :: doGet {0}", ioJSONe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(GET_CART_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }

    }
}
