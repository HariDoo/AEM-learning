package com.novo.core.framework.site.core.models;

import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.novo.core.framework.site.core.utils.FragmentUtil;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * model for site experiencefragment component
 */
@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ExperienceFragment {

    /**
     * logger
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ExperienceFragment.class);

    /**
     * the current resource
     */
    @SlingObject
    private Resource currentResource;

    /**
     * the resourceResolver
     */
    @SlingObject
    private ResourceResolver resourceResolver;

    /**
     * the current Page
     */
    @SlingObject
    private Page currentPage;

    /**
     * id
     */
    @ValueMapValue
    private String id;

    /**
     * className
     */
    @ValueMapValue
    private String className;

    /**
     * initially hidden
     */
    @ValueMapValue
    private boolean initiallyHidden;

    /**
     * experience fragmentPath
     */
    private String fragmentPath;

    /**
     * title
     */
    private String title;

    /**
     * adContent
     */
    private String adContent;

    /**
     * triggerValue
     */
    private String triggerValue;

    public String getId(){
        return id;
    }

    public String getClassName(){
        return className;
    }

    public boolean isInitiallyHidden(){
        return initiallyHidden;
    }

    public String getFragmentPath() {
        return fragmentPath;
    }

    public String getTitle() {
        return title;
    }

    public String getAdContent() {
        return adContent;
    }

    public String getTriggerValue() {
        return triggerValue;
    }

    /**
     * initilizes the model, populates the title, adcontent and triggerValue
     * from the referred xf
     */
    @PostConstruct
    public void init() {
        fragmentPath = FragmentUtil.getPath(
                currentResource.getValueMap().get("fragmentPath", StringUtils.EMPTY),
                currentPage,
                resourceResolver);
        if (fragmentPath != null) {
            final Resource resource = resourceResolver.getResource(
                    fragmentPath + (fragmentPath.endsWith(NameConstants.NN_CONTENT) ? "" : NameConstants.NN_CONTENT));
            if (resource != null) {
                title = resource.getValueMap().get(NameConstants.PN_TITLE, String.class);
                adContent = resource.getValueMap().get("adContent", StringUtils.EMPTY);
                triggerValue = resource.getValueMap().get("triggerValue", StringUtils.EMPTY);
            }
        }
        LOGGER.debug("init-end");
    }
}
