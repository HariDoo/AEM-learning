package com.novo.core.framework.site.core.servlets;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.CartService;
import com.novo.core.framework.site.core.services.ContentDistributionMsgConfigService;
import com.novo.core.framework.site.core.services.LogoConfigService;
import com.novo.core.framework.site.core.services.RestService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestParameter;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;


/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * POST method that can be used to update the customizations
 * or post cart to .NET API further
 * check the component annotations to understand the API signatures.
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=novo-core-framework/site/components/content/educationcenter/createCustomization",
        "sling.servlet.selectors=updateOrganizationApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.extensions=json"})
public class UpdateOrganizationDetailsServlet extends SlingAllMethodsServlet {
    /**
     * This is a logger for the UpdateOrganizationDetailsServlet class.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateOrganizationDetailsServlet.class);

    /**
     *Unique identifier for the organization.
     */
    public static final String ORGANIZATION_ID = "organizationId";
    /**
     *Authentication token for accessing API.
     */
    public static final String AUTH_TOKEN = "authToken";
    /**
     *URL to redirect user after authentication.
     */
    public static final String REDIRECT_URL = "redirectUrl";
    /**
     *Logo image for the organization.
     */
    public static final String LOGO_IMAGE = "logoImage";
    /**
     *Address of the organization.
     */
    public static final String ADDRESS = "address";
    /**
     *Operational times of the organization.
     */
    public static final String OPERATIONAL_TIME = "operationaTimes";
    /**
     *Logo image for Novo Med Link.
     */
    public static final String LOGO_IMAGE_FOR_NOVO_MED_LINK = "logo image for novo med link";
    /**
     *Name of the organization.
     */
    public static final String ORGANIZATION_NAME = "organizationName";
    /**
     *Department of the organization.
     */
    public static final String DEPARTMENT = "department";
    /**
     *Phone number of the organization.
     */
    public static final String PHONE_NUMBER = "phoneNumber";
    /**
     *Determines if customization is default.
     */
    public static final String IS_DEFAULT_CUSTOMIZATION = "IsDefaultCustomization";
    /**
     *Name of the customization.
     */
    public static final String CUSTOMIZATION_NAME = "customizationName";
    /**
     * Service for managing configuration of content
     * distribution messages.
     */
    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;
    /**
     * Service for managing configuration of restServices.
     */
    @Reference
    private transient RestService restService;
    /**
     * This field represents a reference to the CartService.
     */
    @Reference
    private transient CartService cartService;
    /**
     * Service for managing configuration of logo.
     */
    @Reference
    private transient LogoConfigService logoConfigService;

    /**
     * POST method that updates organization data to the .NET API
     *
     * @param request  {@link LogoRequestEntity}
     * @param response {@link ResponseEntity}
     */
    @Override
    protected void doPost(@NotNull SlingHttpServletRequest request, @NotNull SlingHttpServletResponse response) {
        ResponseEntity<String> responseEntity = new ResponseEntity<>();
        try {
            if (ServletFileUpload.isMultipartContent(request)) {
                final Data data = new Data();
                final LogoRequestEntity logoRequestEntity = new LogoRequestEntity();
                ClientResponse clientResponse;
                final Map<String, RequestParameter[]> params = request.getRequestParameterMap();
                validateLogoRequest(params, logoRequestEntity);
                clientResponse = cartService.getUserProfile(logoRequestEntity.getAuthToken());
                final long userId = CartUtils.getIdFromUserObj(clientResponse);

                if (userId == 0) {
                    responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPDATE_ORGANIZATION_PROFILE_NOT_FOUND));
                    CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_FORBIDDEN);
                    return;
                }

                logoRequestEntity.setUserId(userId);
                data.setLogoRequestEntity(logoRequestEntity);
                clientResponse = cartService.updateOrganization(data);

                if (clientResponse != null && StringUtils.isNotBlank(clientResponse.getData())) {
                    responseEntity = new Gson().fromJson(clientResponse.getData(), ResponseEntity.class);
                    final String  message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.UPDATE_ORGANIZATION_DETAILS + CommonConstants.COLON_CHAR + responseEntity.getMessage());

                    if (clientResponse.getStatusCode() != HttpServletResponse.SC_OK) {
                        responseEntity.setMessage(message);
                        CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                        return;
                    }
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                } else {
                    LOGGER.debug("Organization not Updated :: UpdateOrganizationDetailsServlet() :: doPost {}", "Organization Not updated");
                    responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPDATE_ORGANIZATION_INTERNAL_SERVER_ERROR));
                    CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                }
            }
        } catch (CartServletException ce) {
            LOGGER.error("Error getting request parameters :: UpdateOrganizationDetailsServlet() :: doPost {0}", ce);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPDATE_ORGANIZATION_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        } catch (JSONException ioJSONe) {
            LOGGER.error(" JSONException :: UpdateOrganizationDetailsServlet() :: doPost {0}", ioJSONe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPDATE_ORGANIZATION_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (IOException ioException) {
            LOGGER.error("IOException  :: UpdateOrganizationDetailsServlet() :: doPost {0}", ioException);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.UPDATE_ORGANIZATION_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    /**
     * Method to validate logo request
     *
     * @param params
     * @param logoRequestEntity
     * @throws IOException
     * @throws CartServletException
     */
    public void validateLogoRequest(Map<String, RequestParameter[]> params, LogoRequestEntity logoRequestEntity) throws IOException, CartServletException{

        setLogoRequestEntityValue(params.get(AUTH_TOKEN), logoRequestEntity::setAuthToken);
        setLogoRequestEntityValue(params.get(REDIRECT_URL), logoRequestEntity::setRedirectUrl);
        setLogoRequestEntityValue(params.get(ORGANIZATION_NAME), logoRequestEntity::setOrganizationName);
        setLogoRequestEntityValue(params.get(DEPARTMENT), logoRequestEntity::setDepartment);
        setLogoRequestEntityValue(params.get(PHONE_NUMBER), logoRequestEntity::setPhoneNumber);
        setLogoRequestEntityValue(params.get(IS_DEFAULT_CUSTOMIZATION), value -> logoRequestEntity.setDefaultCustomization(Boolean.valueOf(value)));
        setLogoRequestEntityValue(params.get(CUSTOMIZATION_NAME), logoRequestEntity::setCustomizationName);
        setLogoRequestEntityValue(params.get(ORGANIZATION_ID), logoRequestEntity::setOrganizationId);

        final RequestParameter[] logoImageArr = params.get(LOGO_IMAGE);
        if(logoImageArr != null) {
            final RequestParameter logoImage = logoImageArr[0];
            logoRequestEntity.setFilename(logoImage.getFileName());
            final InputStream stream = logoImage.getInputStream();
            final byte[] bytes = IOUtils.toByteArray(stream);
            final String encoded = Base64.getEncoder().encodeToString(bytes);
            logoRequestEntity.setBase64Image(encoded);
            logoRequestEntity.setFileDescription(LOGO_IMAGE_FOR_NOVO_MED_LINK);
        }

        final RequestParameter[] addresses = params.get(ADDRESS);
        if(addresses != null && addresses.length > 0) {
            final String data = addresses[0].getString();
            final ObjectMapper mapper = new ObjectMapper();
            final AddressRequestEntity address = mapper.readValue(data, new TypeReference<AddressRequestEntity>() {
            });
            logoRequestEntity.setAddressRequestEntity(address);
        }

        final RequestParameter[] operationalTimes = params.get(OPERATIONAL_TIME);
        if(operationalTimes != null && operationalTimes.length > 0) {
            final String data = operationalTimes[0].getString();
            final ObjectMapper mapper = new ObjectMapper();
            final List<OperationalTimeRequestEntity> operationalTimeRequestEntityList = mapper.readValue(data, new TypeReference<List<OperationalTimeRequestEntity>>() {
            });
            logoRequestEntity.setOperationalTimeRequestEntityList(operationalTimeRequestEntityList);
        }

        CartUtils.validateUpdateOrganizationRequest(logoRequestEntity,contentDistributionMsgConfigService);
        if(!StringUtils.isBlank(logoRequestEntity.getFilename())) {
            CartUtils.validateFileSizeAndFormat(logoRequestEntity, logoConfigService, contentDistributionMsgConfigService);
        }
    }

    /**
     * Sets the value of the logo request entity using the
     * specified array of request parameters and a consumer function.
     * @param values An array of request parameters.
     * @param setter A consumer function used to set
     * the value of the logo request entity.
     */
    private void setLogoRequestEntityValue(RequestParameter[] values, Consumer<String> setter) {
        if (values != null && values.length > 0) {
            setter.accept(values[0].toString());
        }
    }
}
