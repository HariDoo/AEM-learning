package com.novo.core.framework.site.core.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.SerializedName;

/**
 * Represents a cartEntity
 *
 * @version 1.0
 * @since 1.0
 */
public class CartEntity {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName(value="cartName", alternate="CartName")
    private String cartName;
    /**
     * This field is used to represent the name of a
     * customization option in the application's data model.
     * The field is also annotated with @JsonInclude(JsonInclude.Include.NON_NULL)
     * and @SerializedName(value="customizationName", alternate="CustomizationName"),
     * indicating that it should be included in serialized JSON output and its name
     * should be either "customizationName" or "CustomizationName".
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName(value="customizationName", alternate="CustomizationName")
    private String customizationName;

    /**
     * This field is used to represent the id of an
     * organization option in the application's data model.
     * The field is also annotated with @JsonInclude(JsonInclude.Include.NON_NULL)
     * and @SerializedName(value="organizationId", alternate="OrganizationId"),
     * indicating that it should be included in serialized JSON output and its name
     * should be either "organizationId" or "OrganizationId".
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName(value="organizationId", alternate="OrganizationId")
    private Integer organizationId;

    /**
     * This field is used to represent the identifier of
     * a user's  cart in the application's data model.
     * The field is also annotated with @JsonInclude(JsonInclude.Include.NON_NULL)
     * and @SerializedName(value="cartId", alternate="CartId"),
     * indicating that it should be included in serialized JSON
     * output and its name should be either "cartId" or "CartId".
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName(value="cartId", alternate="CartId")
    private Integer cartId;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @SerializedName(value="uniqueId", alternate="CartUniqueKey")
    private String uniqueId;

    private String publishUrl;

    public Integer getOrganizationId() {
        return organizationId;
    }

    public void setOrganizationId(Integer organizationId) {
        this.organizationId = organizationId;
    }

    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public String getCustomizationName() {
        return customizationName;
    }

    public void setCustomizationName(String customizationName) {
        this.customizationName = customizationName;
    }


    public String getCartName() {
        return cartName;
    }

    public void setCartName(String cartName) {
        this.cartName = cartName;
    }



    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getPublishUrl() {
        return publishUrl;
    }

    public void setPublishUrl(String publishUrl) {
        this.publishUrl = publishUrl;
    }
}
