package com.novo.core.framework.site.core.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.novo.core.framework.site.core.constants.CommonConstants;
import com.novo.core.framework.site.core.constants.MessageConstant;
import com.novo.core.framework.site.core.entity.*;
import com.novo.core.framework.site.core.exception.CartServletException;
import com.novo.core.framework.site.core.services.*;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.json.JSONException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.Servlet;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;

/**
 * An AEM service component that extends to servlet
 * provides API's to be consumed at front-end
 * <p>
 * It exposes two methods mainly
 * POST and GET method that can be used to get the cart content
 * or post urls to .NET API further
 * <p>
 * check the component annotations to understand the API signatures
 *
 * @version 1.0
 * @since 1.0
 */
@Component(service = {Servlet.class}, property = {
        "sling.servlet.resourceTypes=cq/Page",
        "sling.servlet.selectors=publishCartContentApi",
        "sling.servlet.methods=" + HttpConstants.METHOD_POST,
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.extensions=json"})
public class PublishCartContentServlet extends SlingAllMethodsServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishCartContentServlet.class);

    @Reference
    private transient ResourceResolverFactory resourceResolverFactory;

    @Reference
    private transient CartService cartService;

    @Reference
    private transient MailSenderService mailSenderService;

    @Reference
    private transient RestService restService;

    @Reference
    private transient ContentDistributionMsgConfigService contentDistributionMsgConfigService;

    @Reference
    private transient ServletAPIUrlsService servletAPIUrlsService;

    /**
     * GET method that get urls from the .NET API
     *
     * @param request  {@link SaveCartContentRequestEntity}
     * @param response {@link ResponseEntity }
     */
    @Override
    protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response) {

        // step to map request with the desired bean
        SaveCartContentRequestEntity saveCartContentRequestEntity = CartUtils.getSaveCartContentRequestEntityFromRequest(request);
        ResponseEntity<Object> responseEntity = new ResponseEntity<>();
        ClientResponse clientResponse;
        ResourceResolver resourceResolver = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // validating the request
            CartUtils.validateRequestGetCartContent(saveCartContentRequestEntity, contentDistributionMsgConfigService);

            // Getting the resolver using service user that is configurable using the service username in config
            resourceResolver = CartUtils.getResourceResolver(resourceResolverFactory, restService.getServiceUser());
            if (resourceResolver == null) {
                LOGGER.debug("Not able to get the successful profile object created");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_RESOLVER_NOT_FOUND));
                CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                return;
            }

            // Getting cart content from .NET API call
            clientResponse = cartService.getCartContent(saveCartContentRequestEntity);
            if (clientResponse != null && StringUtils.isNotBlank(clientResponse.getData())) {
                responseEntity = objectMapper.readValue(clientResponse.getData(), ResponseEntity.class);
                String message = contentDistributionMsgConfigService.getApiResponseMessage(ApiRequestEnum.GET_CART_CONTENT + CommonConstants.COLON_CHAR + responseEntity.getMessage());
                if (clientResponse.getStatusCode() != HttpServletResponse.SC_OK) {
                    responseEntity.setMessage(message);
                    CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
                    return;
                }
                SaveCartContentRequestEntity[] saveCartContentRequestEntities = CartUtils.responseEntityForGetCartContent(clientResponse, resourceResolver, false);
                CartContentResponseEntity cartContentResponseEntity = CartUtils.publishCartContentResponse(saveCartContentRequestEntities, clientResponse);
                responseEntity.setData(cartContentResponseEntity);
                responseEntity.setSuccess(true);
                responseEntity.setMessage(message);

                // Mapping the urls with AEM resource to fetch the props out of them
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            } else {
                LOGGER.debug("Cart Content is null :: AEMCartContentServlet() :: doGet {}", "Content Not Found");
                responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_MICROSERVICE_BROKEN));
                CartUtils.sendAPIResponse(response, responseEntity, CartUtils.getValidStatusCode(clientResponse));
            }
        } catch (CartServletException ce) {
            LOGGER.error("Error getting request parameters", ce);
            CartUtils.sendAPIResponse(response, responseEntity.buildErrorResponse(ce), ce.getStatusCode());
        } catch (JSONException e) {
            LOGGER.error("JSONException:: AEMCartContentServlet() :: doGet {0}", e);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_INTERNAL_SERVER_ERROR));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } catch (IOException ioe) {
            LOGGER.error("IOException:: AEMCartContentServlet() :: doGet {0}", ioe);
            responseEntity.setMessage(contentDistributionMsgConfigService.getApiResponseMessage(MessageConstant.GET_CART_CONTENT_MICROSERVICE_BROKEN));
            responseEntity.setSuccess(false);
            CartUtils.sendAPIResponse(response, responseEntity, HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            if (Objects.nonNull(resourceResolver))
                resourceResolver.close();
        }
    }
}
