package com.novo.core.framework.site.core.servlets;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.StreamSupport;

import javax.servlet.Servlet;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.xss.XSSAPI;
import org.jetbrains.annotations.NotNull;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;
import com.day.cq.commons.jcr.JcrConstants;

@Component(service = {Servlet.class}, property = {
    "sling.servlet.resourceTypes=" + LabeledOptionsDataSourceServlet.RESOURCE_TYPE,
    "sling.servlet.methods=GET",
    "sling.servlet.extensions=html",
})
public class LabeledOptionsDataSourceServlet extends SlingSafeMethodsServlet {

    @Reference
    private XSSAPI xssapi;

    protected static final String RESOURCE_TYPE = "novo-core-framework/iva/datasources/labeledOptions";

    private static final String PROPERTY_ID = "id";
    private static final String PROPERTY_LABEL = "label";
    private static final String PROPERTY_OPTIONS = "options";

    @Override
    protected void doGet(
        @NotNull final SlingHttpServletRequest request,
        @NotNull final SlingHttpServletResponse response
    ) {
        final Resource resource = request.getResource();
        final ResourceResolver resourceResolver = resource.getResourceResolver();
        final Map<String, String> options = getOptions(resource, resourceResolver);
        request.setAttribute(DataSource.class.getName(), createDataSource(options, resourceResolver));
    }

    private Map<String, String> getOptions(
        final Resource resource,
        final ResourceResolver resourceResolver
    ) {
        final String optionsPath = resource.getValueMap().get(PROPERTY_OPTIONS, StringUtils.EMPTY);
        final Resource optionsResource = resourceResolver.getResource(optionsPath);
        final Map<String, String> options = new LinkedHashMap<String, String>();
        if (optionsResource == null) {
            return options;
        }

        StreamSupport
            .stream(optionsResource.getChildren().spliterator(), false)
            .map(r -> r.adaptTo(ContentFragment.class))
            .filter(cf -> cf != null && cf.hasElement(PROPERTY_ID) && cf.hasElement(PROPERTY_LABEL))
            .sorted(
                Comparator.comparing(
                    cf -> cf.getElement(PROPERTY_LABEL).getContent().toLowerCase()
                )
            )
            .forEach(
                cf -> {
                    options.put(
                        cf.getElement(PROPERTY_ID).getContent(),
                        cf.getElement(PROPERTY_LABEL).getContent()
                    );
                }
            );

        return options;
    }

    private DataSource createDataSource(
        final Map<String, String> options,
        final ResourceResolver resourceResolver
    ) {
        final Iterator<Resource> iterator = options
            .keySet()
            .stream()
            .map(
                key -> (Resource) new ValueMapResource(
                    resourceResolver,
                    new ResourceMetadata(),
                    JcrConstants.NT_UNSTRUCTURED,
                    new ValueMapDecorator(new HashMap<String, Object>() {{
                        put("value", key);
                        put("text", xssapi.encodeForHTML(options.get(key)));
                    }})
                )
            )
            .iterator();
        return iterator != null
            ? new SimpleDataSource(iterator)
            : EmptyDataSource.instance();
    }

}
