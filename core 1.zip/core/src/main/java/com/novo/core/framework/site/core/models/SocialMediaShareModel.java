package com.novo.core.framework.site.core.models;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.Page;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.RepositoryException;


/**
 * Sling model to process the backend data and to be consumed by the FE by calling the methods provided.
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class SocialMediaShareModel {

    /** Variable to write out error messages. */
    private static final Logger LOG = LoggerFactory.getLogger(SocialMediaShareModel.class);

    /** ResourceResolver to inject. */
    @SlingObject
    private ResourceResolver resourceResolver;

    /** Injects the current page object. */
    @Inject
    private Page currentPage;

    /** Property to validate to hide or not the facebook button. */
    @ValueMapValue
    private String hideFacebook;

    /** Property to validate to hide or not the Twitter button. */
    @ValueMapValue
    private String hideTwitter;

    /** Property to validate to hide or not the LinkedIn button. */
    @ValueMapValue
    private String hideLinkedin;

    /** Property to validate to hide or not the mail button. */
    @ValueMapValue
    private String hideMail;

    /** Property to validate to hide or not the copy button. */
    @ValueMapValue
    private String hideCopy;


    /**  Property to the Copy icon. */
    @ValueMapValue
    private String copyFileReference;


    /** Property to the copy icon alt text. */
    @ValueMapValue
    private String copyIconAltText;


    /** Property to validate whether Copy icon is decorative. */
    @ValueMapValue
    private String copyIconIsDecorative;

    /** The modal content for copy message. */
    @ValueMapValue
    private String modalContent;

   /** Property to add custom vanity url. */
    @ValueMapValue
    private  String customOgUrl;

    /** Property to validate custom share url. */
    @ValueMapValue
    private  String customShareUrl;

    /** Injects the request object. */
    @Self
    private SlingHttpServletRequest request;

    /** Page property storing the page SEO title. */
    private static final String PN_SEO_TITLE = "seoTitle";

    /** Page property for custom vanity url. */
    private static final String CUSTOM_OG_URL = "customOgUrl";


    /** Stores the computed page title. */
    private String pageTitle = StringUtils.EMPTY;


    /** Stores the current encoded page description. */
    private String pageDescription = StringUtils.EMPTY;

    /** Stores the current encoded page URL. */
    private String pageURL = StringUtils.EMPTY;

    /**
     * Initializing class fields.
     */
    @PostConstruct
    protected void init() {

        if (null != resourceResolver && null != currentPage) {
            Resource resource = resourceResolver.getResource(currentPage.getPath() + "/" + JcrConstants.JCR_CONTENT);
            if(null != resource){
                Node node = resource.adaptTo(Node.class);
                try {
                    node.setProperty(CUSTOM_OG_URL, customOgUrl);
                    node.getSession().save();
                } catch (RepositoryException e) {
                    LOG.error(e.getMessage(), e);
                }
            }

            final ValueMap pageProperties = currentPage.getProperties();

            String seoTitle = pageProperties.get(PN_SEO_TITLE, String.class);
            if (StringUtils.isBlank(seoTitle)) {
                seoTitle = currentPage.getTitle();
            }

            String pageDesc = pageProperties.get(JcrConstants.JCR_DESCRIPTION, String.class);
            if (StringUtils.isBlank(pageDesc)) {
                pageDesc = currentPage.getTitle();
            }

            String fullPageURL = null;
            if (request != null) {
                fullPageURL = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + currentPage.getPath() + ".html";
            }

            try {
                seoTitle = encodeValue(seoTitle);
                pageTitle = seoTitle.replace("+", "%20");
                pageDesc = encodeValue(pageDesc);
                pageDescription = pageDesc.replace("+", "%20");
                fullPageURL = encodeValue(fullPageURL);
                pageURL = fullPageURL.replace("+", "%20");
            } catch (UnsupportedEncodingException e) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Errow while trying to encode the seoTitle and page description text. {}", e.getMessage());
                }
            }
        }

    }

    /**
     * Gets the link url including the domain.
     * @param link the current link
     * @return an absolute url which includes the site domain
     */
    public String getFullUrl(String link) {
        if (link != null) {
            final Resource pathResource = resourceResolver.getResource(link);
            // check if resource exists and resource is not a dam object
            if (pathResource != null && link.indexOf("/content/dam") != 0) {
                // append .html
                return resourceResolver.map(link) + ".html";
            }
        }
        return link;
    }


    /**
     * Gets the current page absolute url including the site domain.
     *
     * @return the current page absolute url
     */
    public String getPageAbsoluteUrl() {
        String pagePathUrl = StringUtils.EMPTY;

        if (Objects.nonNull(resourceResolver) && Objects.nonNull(currentPage)) {
            pagePathUrl = getFullUrl(currentPage.getPath());
            if (StringUtils.isNotBlank(pagePathUrl)) {
                try {
                    pagePathUrl = encodeValue(pagePathUrl);
                } catch (UnsupportedEncodingException e) {
                    LOG.debug("Error while trying to encode the url {}", pagePathUrl);
                }
            }
        }

        return pagePathUrl;
    }

    /**
     * Encodes eny value get as parameter.
     *
     * @param value the value
     * @return a String whith te value encoded
     * @throws UnsupportedEncodingException the unsupported encoding exception
     */
    private String encodeValue(String value) throws UnsupportedEncodingException {
        return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
    }

    /**
     * Gets the page URL.
     *
     * @return the page URL
     */
    public String getPageURL() {
        return pageURL;
    }

    /**
     * Gets the page description.
     *
     * @return the page description
     */
    public String getPageDescription() {
        return pageDescription;
    }

    /**
     * Gets the page title.
     *
     * @return the page title
     */
    public String getPageTitle() {
        return pageTitle;
    }

	/**
	 * Gets the hide copy.
	 *
	 * @return the hide copy
	 */
	public String getHideCopy() {
		return hideCopy;
	}

	/**
	 * Gets the copy file reference.
	 *
	 * @return the copy file reference
	 */
	public String getCopyFileReference() {
		return copyFileReference;
	}

	/**
	 * Gets the copy icon alt text.
	 *
	 * @return the copy icon alt text
	 */
	public String getCopyIconAltText() {
		return copyIconAltText;
	}

	/**
	 * Gets the copy icon is decorative.
	 *
	 * @return the copy icon is decorative
	 */
	public String getCopyIconIsDecorative() {
		return copyIconIsDecorative;
	}

	/**
	 * Gets the modal content.
	 *
	 * @return the modal content
	 */
	public String getModalContent() {
		return modalContent;
	}

    public String getCustomOgUrl(){

        return customOgUrl; }

    public String getCustomShareUrl(){

        return customShareUrl; }

}
