package com.novo.core.framework.site.core.services;

import com.novo.core.framework.site.core.entity.ApiMessage;

public interface ContentDistributionMsgConfigService {
    /**
     * Method to get API's messages for response
     *
     * @return {@link ApiMessage}
     */
    public String getApiResponseMessage(String resReqType);

}
