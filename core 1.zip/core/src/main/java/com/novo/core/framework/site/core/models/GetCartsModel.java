package com.novo.core.framework.site.core.models;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.inject.Inject;

@Model(adaptables = SlingHttpServletRequest.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class GetCartsModel {

    private static final String DISEASE_TAG = "diseaseTag";
    @Inject
    private Page currentPage;
    @SlingObject
    private ResourceResolver resourceResolver;

    public String getDiseaseTag() {
        ValueMap props = currentPage.getProperties();
        String tagProperty = StringUtils.EMPTY;
        if (props.containsKey(DISEASE_TAG))
            tagProperty = props.get(DISEASE_TAG, StringUtils.EMPTY);
        TagManager tagManager = resourceResolver.adaptTo(TagManager.class);
        Tag tag= tagManager.resolve(tagProperty);
        if (tag!= null)
            return tag.getName();
        else
            return StringUtils.EMPTY;
    }

}
