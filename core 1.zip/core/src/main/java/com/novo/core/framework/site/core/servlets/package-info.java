@Version("1.0")
package com.novo.core.framework.site.core.servlets;

import org.osgi.annotation.versioning.Version;