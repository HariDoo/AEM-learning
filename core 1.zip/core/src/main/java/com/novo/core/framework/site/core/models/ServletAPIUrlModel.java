package com.novo.core.framework.site.core.models;

import com.google.gson.Gson;
import com.novo.core.framework.site.core.services.ServletAPIUrlsService;
import com.novo.core.framework.site.core.utils.CartUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;

/**
 * Represents ServletAPIUrls
 * <b>Education Center</b> project implementation
 *
 * @version 1.0
 * @since 1.0
 */
@Model(adaptables = SlingHttpServletRequest.class)
public class ServletAPIUrlModel {

    @OSGiService
    ServletAPIUrlsService restAPIUrlsService;

    @ScriptVariable
    private SlingHttpServletRequest request;

    public String getApiResourcePath(){
        return request.getResourceResolver().map(request,request.getResource().getPath());
    }

    public String getApiUrls(){
        return new Gson().toJson(restAPIUrlsService.getRestAPIUrls());
    }
}
