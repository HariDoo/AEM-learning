package com.novo.core.framework.site.core.models;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = { SlingHttpServletRequest.class, Resource.class })
public class VoteUp {

    /**
     *
     * Article ID
     */
	@ValueMapValue(name = "articleID")
    @Optional
	private String articleID;

    /**
     *
     * Vote up Label
     */
	@ValueMapValue(name = "voteUpLabel")
    @Optional
	private String voteUpLabel;

    /**
     *
     * Path for the Icon
     */
	@ValueMapValue(name = "iconPath")
    @Optional
	private String iconPath;

	public String getVoteUpLabel() {
		return voteUpLabel;
	}

	public String getIconPath() {
		return iconPath;
	}

	public String getArticleID() {
		return articleID;
	}

}
