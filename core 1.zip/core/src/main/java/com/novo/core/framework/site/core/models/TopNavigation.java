package com.novo.core.framework.site.core.models;

import com.day.cq.commons.Externalizer;
import com.day.cq.commons.inherit.HierarchyNodeInheritanceValueMap;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.novo.core.framework.site.core.utils.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.IteratorUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.isBlank;


/**
 * The Class TopNavigation.
 */
@Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class TopNavigation {
    
    /** The Constant URL. */
    private static final String URL = "url";
    
    /** The Constant TITLE. */
    private static final String TITLE = "title";
    
    /** The Constant BRAND_LOGO. */
    private static final String BRAND_LOGO = "brandLogo";
    
    /** The Constant BRAND_LOGO_MOBILE. */
    private static final String BRAND_LOGO_MOBILE = "brandMobile";
    
    /** The Constant BRAND_LOGO_ALT_TEXT. */
    private static final String BRAND_LOGO_ALT_TEXT = "brandLogoAltText";
    
    /** The Constant ACTIVE. */
    private static final String ACTIVE = "active";
    
    /** The Constant LINK. */
    private static final String LINK = "link";
    
    /** The Constant HTML_EXTENSION. */
    private static final String HTML_EXTENSION = ".html";
    
    /** The Constant HIDE_IN_NAV. */
    private static final String HIDE_IN_NAV = "hideInNav";
    
    /** The Constant HIDE_IN_NAV. */
    private static final String HIDE_IN_PRIME_NAV = "hidePrimeNavigation";
    
    /** The Constant DISPLAY_DROPDOWN_ICON. */
    private static final String DISPLAY_DROPDOWN_ICON = "displayDropdownIcon";
    
    /** The Constant HIDE_IN_NAV_DESK. */
    private static final String HIDE_IN_NAV_DESK = "hideInNavDesk";
    
    /** The Constant JCR_TITLE. */
    private static final String JCR_TITLE = "jcr:title";
    
    /** The Constant SECTION_TITLE. */
    private static final String SECTION_TITLE = "sectionTitle";
    
    /** The Constant ICON. */
    private static final String ICON = "icon";
    
    /** The Constant SECTION_ICON. */
    private static final String SECTION_ICON = "sectionIcon";
    
    /** The Constant BANNER_SECTION_FRAGMENT_PATH. */
    private static final String BANNER_SECTION_FRAGMENT_PATH = "bannerSectionFragmentPath";
    
    /** The Constant GROUP_NESTED_CHILD_PAGES. */
    private static final String GROUP_NESTED_CHILD_PAGES = "groupNestedChildPages";
    
    /** The Constant GROUP_NESTED_CHILD_PAGES_ROWS. */
    private static final String GROUP_NESTED_CHILD_PAGES_ROWS = "groupNestedChildPagesRows";
    
    /** The Constant DYNAMIC_MOBILE_DEEP_LEVEL. */
    private static final String DYNAMIC_MOBILE_DEEP_LEVEL = "dynamicMobileDeepLevel";
    
    /** The Constant PARENT_REGEX. */
    private static final String PARENT_REGEX = "%s/";
    
    /** The Constant SEPARATOR. */
    private static final String SEPARATOR = "/";
    
    /** The Constant NESTED_CHILDREN. */
    private static final String NESTED_CHILDREN = "nestedChildren";
    
    /** The Constant CHILDREN. */
    private static final String CHILDREN = "children";
    
    /** The Constant DISPALY_SECONDARY_NAVIGATION. */
    private static final String DISPALY_SECONDARY_NAVIGATION = "displaySecondaryNavigation";
    
    /** The Constant HIDE_SUB_NAVIGATION. */
    private static final String HIDE_SUB_NAVIGATION = "hideSubNavigation";
    
    /** The Constant HIDE_DROPDOWN_PANEL. */
    private static final String HIDE_DROPDOWN_PANEL = "hideDropdownPanel";
    
    /** The Constant HIDE_NAV_ITEM. */
    private static final String HIDE_NAV_ITEM = "hideNavItem";
    
    /** The Constant HIDE_SUB_NAVIGATION_CURRENT_PAGE. */
    private static final String HIDE_SUB_NAVIGATION_CURRENT_PAGE = "hideSubNavigationCurrentPage";
    
    /** The Constant NOVO_HOME_TYPE. */
    private static final String NOVO_HOME_TYPE = "novo-home";
    
    /** The Constant USE_PAGE_AS_ROOT. */
    private static final String USE_PAGE_AS_ROOT = "usePageAsRoot";
    
    /** The Constant RESOURCE_TYPE. */
    private static final String RESOURCE_TYPE = "sling:resourceType";
    
    /** The Constant USE_CONDITION_NAVIGATION_MOBILE. */
    private static final String USE_CONDITION_NAVIGATION_MOBILE = "useConditionNavigationMobile";
    
    /** The Constant CONDITION_FRAGMENT_PATH. */
    private static final String CONDITION_FRAGMENT_PATH = "conditionFragmentPath";
    
    /** The Constant BANNER_TEXT. */
    private static final String BANNER_TEXT = "bannerText";
    
    /** The Constant MOBILE_CONDITION_TEXT. */
    private static final String MOBILE_CONDITION_TEXT = "mobileConditionText";
    
    /** The Constant MOBILE_OPENED_CONDITION_TEXT. */
    private static final String MOBILE_OPENED_CONDITION_TEXT = "mobileOpenedConditionText";

    /** Constant OVERRIDE_MAIN_LOGO_DESKTOP_PN representing the path field to override the main logo in desktop view */
    private static final String OVERRIDE_MAIN_LOGO_DESKTOP_PN = "overrideMainLogoDesktop";

    /** Constant OVERRIDE_MAIN_LOGO_MOBILE_PN representing the path field to override the main logo in mobile view */
    private static final String OVERRIDE_MAIN_LOGO_MOBILE_PN = "overrideMainLogoMobile";

    /** Const MAIN_LOGO_ALTERNATIVE_TEXT_PN representing the alternative text for the main logo image */
    private static final String OVERRIDE_MAIN_LOGO_ALTERNATIVE_TEXT_PN = "overrideMainLogoAltText";

    /** Constant representing the new link target to override the main logo one */
    private static final String OVERRIDE_MAIN_LOGO_LINK_TARGET_PN = "overrideMainLogoLinkTarget";

    /** constant indicating the deep content level corresponding to the language page */
    private static final int LANGUAGE_PAGE_DEPTH_LEVEL = 3;

    /** Constant DISPLAY_BRAND_LOGO_BANNER_FOR_MOBILE_PN representing the displayBrandLogoBannerForMobile property */
    private static final String DISPLAY_BRAND_LOGO_BANNER_FOR_MOBILE_PN = "displayBrandLogoBannerForMobile";

    /** Constant BRAND_LOGO_BANNER_FOR_MOBILE_ONLY_PN representing the brandLogoBannerForMobileOnly property */
    private static final String BRAND_LOGO_BANNER_FOR_MOBILE_ONLY_PN = "brandLogoBannerForMobileOnly";

    /** Constant BAND_LOGO_BANNER_FOR_MOBILE_ONLY_ALT_TEXT representing the 
     * brandLogoBannerForMobileOnlyAltText property */
    private static final String BAND_LOGO_BANNER_FOR_MOBILE_ONLY_ALT_TEXT = "brandLogoBannerForMobileOnlyAltText";

    /** SlingHttpServletRequest to inject. */
    @Self
    private SlingHttpServletRequest slingRequest;

    /** ResourceResolver to inject. */
    @SlingObject
    private ResourceResolver resourceResolver;

    /** The current page. */
    @Inject
    private Page currentPage;

    /** The home path. */
    @ValueMapValue
    private String homePath;

    /** The read page properties. */
    @ValueMapValue
    @Default(booleanValues = false)
    private Boolean readPageProperties;

    /** dialog property readPagePropsWOGlobalNav. */
    @ValueMapValue
    @Default(booleanValues = false)
    private Boolean readPagePropsWOGlobalNav;

    /** The use dynamic mobile navigation. */
    @ValueMapValue
    @Default(booleanValues = false)
    private Boolean useDynamicMobileNavigation;

    /** The root path. */
    @ValueMapValue
    private String rootPath;

    /** The active page. */
    @ValueMapValue
    private String activePage;

    /** The secondary root path. */
    @ValueMapValue
    private String secondaryRootPath;

    /** Header main logo */
    @ValueMapValue
    private String logo;

    /** Header logo mobile */
    @ValueMapValue
    private String logoMobile;

    /** Header logo alternative text */
    @ValueMapValue
    private String logoAltText;

    /** Property holding the header logo path for desktop */
    private String homeLogoPathDesktop;

    /** Property holding the header logo path for mobile */
    private String homeLogoPathMobile;

    /** Property holding the header logo alternative text */
    private String homeLogoAltText;

    /** The display secondary navigation. */
    private Boolean displaySecondaryNavigation;

    /** The use condition navigation mobile. */
    private Boolean useConditionNavigationMobile;

    /** The condition fragment path. */
    @ValueMapValue
    private String conditionFragmentPath;

    /** The banner text. */
    private String bannerText;

    /** The mobile condition text. */
    private String mobileConditionText;

    /** The brand logo. */
    private String brandLogo;

    /** The brand logo alt text. */
    private String brandLogoAltText;

    /** The mobile opened condition text. */
    private String mobileOpenedConditionText;

    /** The Home page. */
    public Page HomePage = null;

    /** The secondary navigation home page. */
    public Page secondaryNavigationHomePage = null;

    /** The condition mobile navgiation. */
    public Page conditionMobileNavgiation = null;

    /** Checkbox to enable the brand logo banner for mobile */
    private Boolean displayBrandLogoBannerForMobile;

    /** The brand logo banner for mobile */
    private String brandLogoBannerForMobileOnly;

    /** An alternative text for the brand logo banner for mobile */
    private String brandLogoBannerForMobileOnlyAltText;

    /** The Constant LOGGER. */
    public static final Logger LOGGER = LoggerFactory.getLogger(TopNavigation.class);

    /** The items. */
    public List<Map<String, Object>> items;
    
    /**
     * Gets the items.
     *
     * @return the items
     */
    public List<Map<String, Object>> getItems() {
        return items;
    }

    /** The secondary items. */
    public List<Map<String, Object>> secondaryItems;

    /**
     * Gets the secondary items.
     *
     * @return the secondary items
     */
    public List<Map<String, Object>> getSecondaryItems() {
        return secondaryItems;
    }

    /**
     * Server name is calculated using externalizer, this will be used by java script in runtime to build dynamic mobile navigation menu.
     */
    private String serverName;

    /**
     * Gets the secondar navigation home path.
     *
     * @return the secondar navigation home path
     */
    public String getSecondarNavigationHomePath() {
        if (secondaryNavigationHomePage == null) {
            return StringUtils.EMPTY;
        }

        return secondaryNavigationHomePage.getPath();
    }

    /** The mobile items. */
    public List<Map<String, Object>> mobileItems;

    /** The condition mobile items. */
    public List<Map<String, Object>> conditionMobileItems;

    /**
     * Gets the mobile items JSON.
     *
     * @return the mobile items JSON
     */
    public String getMobileItemsJSON() {
        return new Gson().toJson(mobileItems);
    }

    /**
     * Gets the condition mobile items JSON.
     *
     * @return the condition mobile items JSON
     */
    public String getConditionMobileItemsJSON() {
        if (useConditionNavigationMobile) {
            return new Gson().toJson(conditionMobileItems);
        }

        return StringUtils.EMPTY;
    }

    /**
     * Inits the.
     */
    @PostConstruct
    protected void init() {
        if(currentPage.hasContent()) {
            homeLogoPathDesktop = logo;
            homeLogoPathMobile = logoMobile;
            homeLogoAltText = logoAltText;
            overrideHomeLogoPath(currentPage);

            final Page rootPath = getRootPath(currentPage);

            if (rootPath == null) {
                getHomePage(currentPage);
            }

            serverName = findServerNameFromResource(HomePage);

            if (readPageProperties || readPagePropsWOGlobalNav) {
                loadDynamicContent();
                final InheritanceValueMap ivm = new HierarchyNodeInheritanceValueMap(currentPage.getContentResource());
                final Boolean displaySecondaryNavigationProp = ivm.getInherited(DISPALY_SECONDARY_NAVIGATION, Boolean.FALSE);

                if (StringUtils.isNotEmpty(secondaryRootPath) || displaySecondaryNavigationProp) {
                    loadSecondaryNavigation();
                }

                setUp();

                if (useDynamicMobileNavigation) {
                    loadDynamicMobileNavigation();
                }

                if (useConditionNavigationMobile) {
                    loadConditionMobileNavigation();
                }
            } else {
                loadContent();
            }
        }
    }

    /**
     * Gets the home page.
     *
     * @param parent the parent
     * @return the home page
     */
    public void getHomePage(Page parent) {
        if (parent != null) {
            final ValueMap props = parent.getProperties();
            final Boolean usePageAsRoot = props.get(USE_PAGE_AS_ROOT, Boolean.FALSE);
            final String templateType = props.get(RESOURCE_TYPE, StringUtils.EMPTY);
            if (templateType.contains(NOVO_HOME_TYPE) || usePageAsRoot) {
                HomePage = parent;
            } else {
                getHomePage(parent.getParent());
            }
        }
    }

    /**
     * Checks in the properties of the provided page if there is a value to override the home logo path
     * @param parent the current parent page
     */
    private void overrideHomeLogoPath(Page parent) {
        if (parent != null) {
            var currPage = parent;

            while (currPage != null && currPage.getDepth() > LANGUAGE_PAGE_DEPTH_LEVEL) {
                final ValueMap props = currPage.getProperties();
                final String overrideLogoPathDesktop = props.get(OVERRIDE_MAIN_LOGO_DESKTOP_PN, StringUtils.EMPTY);

                if (!isBlank(overrideLogoPathDesktop)) {
                    homeLogoPathDesktop = overrideLogoPathDesktop;
                    homeLogoPathMobile = props.get(OVERRIDE_MAIN_LOGO_MOBILE_PN, overrideLogoPathDesktop);
                    homeLogoAltText = props.get(OVERRIDE_MAIN_LOGO_ALTERNATIVE_TEXT_PN, logoAltText);
                    homePath = props.get(OVERRIDE_MAIN_LOGO_LINK_TARGET_PN, homePath);
                    break;
                }

                currPage = currPage.getParent();
            }
        }
    }

    /**
     * Gets the root path.
     *
     * @param parent the parent
     * @return the root path
     */
    private Page getRootPath(final Page parent) {
        if (parent == null) {
            return null;
        }

        if (StringUtils.isEmpty(rootPath)) {
            return null;
        }

        HomePage = parent.getContentResource().getResourceResolver().getResource(rootPath).adaptTo(Page.class);

        return HomePage;
    }

    /**
     * Gets the secondary root path.
     *
     * @param parent the parent
     * @return the secondary root path
     */
    private Page getSecondaryRootPath(final Page parent) {
        if (parent == null) {
            return null;
        }

        if (StringUtils.isEmpty(secondaryRootPath)) {
            return null;
        }

        secondaryNavigationHomePage = parent.getContentResource().getResourceResolver().getResource(secondaryRootPath).adaptTo(Page.class);

        return secondaryNavigationHomePage;
    }

    /**
     * Load content.
     */
    private void loadContent() {
        items = new ArrayList<>();
        Page page = HomePage;
        if (page != null) {
            Iterator<Page> ip = page.listChildren();
            while(ip.hasNext()) {
                Page child = ip.next();
                addPageToList(child, Boolean.TRUE);
            }
        }
    }

    /**
     * Gets the curren page.
     *
     * @return the curren page
     */
    private String getCurrenPage() {
        if (StringUtils.isEmpty(activePage)) {
            return currentPage.getPath();
        }

        return activePage;
    }

    /**
     * Checks if is page set to hide in root page.
     *
     * @param propertyName the property name
     * @param pageName the page name
     * @return true, if is page set to hide in root page
     */
    private boolean isPageSetToHideInRootPage(String propertyName, final String pageName) {
        Page currentActivePage = currentPage;

        if (StringUtils.isNotEmpty(activePage)) {
            currentActivePage = currentPage.getContentResource().getResourceResolver().getResource(activePage).adaptTo(Page.class);
        }

        final InheritanceValueMap ivm = new HierarchyNodeInheritanceValueMap(currentActivePage.getContentResource());
        final String propertyValue = ivm.get(propertyName, StringUtils.EMPTY);
        return !isBlank(propertyValue) && Arrays.asList(propertyValue.split(",")).contains(pageName);
    }

    /**
     * Load dynamic content.
     */
    private void loadDynamicContent() {
        items = new ArrayList<>();
        Page page = HomePage;

        if (page != null) {
            Iterator<Page> ip = page.listChildren();
            
            while (ip.hasNext()) {
                Page child = ip.next();
                String redirectpath = child.getProperties().get("redirectTarget", String.class);
                
                Boolean active= Utils.isActivePage(redirectpath, currentPage, child, getCurrenPage());
                addPageToList(child, items, Boolean.FALSE, active);
            }
        }
    }

    /**
     * Gets the secondary home page.
     *
     * @param parent the parent
     * @return the secondary home page
     */
    private void getSecondaryHomePage(Page parent) {
        if (parent != null) {
            ValueMap props = parent.getProperties();
            final Boolean displaySecondaryNavigationProp = props.get(DISPALY_SECONDARY_NAVIGATION, Boolean.FALSE);
            if (displaySecondaryNavigationProp) {
                secondaryNavigationHomePage = parent;
            } else {
                getSecondaryHomePage(parent.getParent());
            }
        }
    }

    /**
     * Gets the condition mobile navgiation.
     *
     * @param parent the parent
     * @return the condition mobile navgiation
     */
    private void getConditionMobileNavgiation(final Page parent) {
        if (parent != null) {
            ValueMap props = parent.getProperties();
            final Boolean useCoditionNavigation = props.get(USE_CONDITION_NAVIGATION_MOBILE, Boolean.FALSE);
            if (useCoditionNavigation) {
                conditionMobileNavgiation = parent;
            } else {
                getConditionMobileNavgiation(parent.getParent());
            }
        }
    }

    /**
     * Load secondary navigation.
     */
    private void loadSecondaryNavigation() {
        if (getSecondaryRootPath(currentPage) == null) {
            getSecondaryHomePage(currentPage);
        }

        if (secondaryNavigationHomePage != null) {
            secondaryItems = new ArrayList<>();
            Iterator<Page> ip = secondaryNavigationHomePage.listChildren();

            while (ip.hasNext()) {
                Page child = ip.next();
                String redirectpath = child.getProperties().get("redirectTarget", String.class);
                Boolean active= Utils.isActivePage(redirectpath, currentPage, child, currentPage.getPath());
                addPageToList(child, secondaryItems, Boolean.FALSE, active);
            }
        }
    }

    /**
     * Load dynamic mobile navigation.
     */
    private void loadDynamicMobileNavigation() {
        mobileItems = new ArrayList<>();
        Page page = HomePage;

        if (page != null) {
            Iterator<Page> ip = page.listChildren();
            while (ip.hasNext()) {
                Page child = ip.next();
                String redirectpath = child.getProperties().get("redirectTarget", String.class); 
                Boolean active= Utils.isActivePage(redirectpath, currentPage, child, getCurrenPage());
                addPageToList(child, mobileItems, Boolean.TRUE, active);
            }
        }
    }

    /**
     * finds the servername through sling resource resolver.
     * @param page a Page
     * @return the http hostname or a null if there is an issue finding the hostname.
     */
    private String findServerNameFromResource(Page page) {
        final Externalizer externalizer = resourceResolver.adaptTo(Externalizer.class);

        if(externalizer == null || page == null) {
            return null;
        }

        String url = externalizer.publishLink(resourceResolver, page.getPath());

        try {
            if(url != null && !url.contains("localhost")) {
                return new URI(url).getHost();
            }
        } catch (URISyntaxException e) {
            LOGGER.warn("Unable to get hostname from the URI ", e);
        }

        return null;
    }

    /**
     * Load condition mobile navigation.
     */
    private void loadConditionMobileNavigation() {
        conditionMobileItems = new ArrayList<>();
        getConditionMobileNavgiation(currentPage);

        if(conditionMobileNavgiation == null) {
            // meaning currentPage could be an EF, so look for conditionMobileNavigation on the rootpage
            getConditionMobileNavgiation(HomePage);
        }

        if (conditionMobileNavgiation != null) {
            Iterator<Page> ip = conditionMobileNavgiation.listChildren();

            while (ip.hasNext()) {
                Page child = ip.next();
                addPageToList(child, conditionMobileItems, Boolean.TRUE, Boolean.FALSE);
            }
        }
    }

    /**
     * Adds the page to list.
     *
     * @param page the page
     * @param includeChildren the include children
     */
    private void addPageToList(Page page, Boolean includeChildren){
            ValueMap valueMap = page.getContentResource().getValueMap();


            Map<String, Object> item = new HashMap<>();
            Boolean hidden = valueMap.get("hideInNav", Boolean.FALSE);
            if (!hidden) {
                // fetch children
                List<Map<String, String>> children = new ArrayList<>();
                Map<String, String> obj = new HashMap<>();

                item.put("title", valueMap.get("sectionTitle", valueMap.get("jcr:title", StringUtils.EMPTY)));
                item.put("url", page.getPath());
                item.put("link", page.getPath() + ".html");
                item.put("icon", valueMap.get("sectionIcon", String.class));
                item.put("active", page.getPath().equals(currentPage.getPath()));

                obj = new HashMap<>();
                obj.put("title", page.getTitle());
                obj.put(HIDE_IN_NAV_DESK, valueMap.get(HIDE_IN_NAV_DESK, Boolean.FALSE).toString());
                obj.put(HIDE_IN_PRIME_NAV, valueMap.get(HIDE_IN_PRIME_NAV, Boolean.FALSE).toString());
                obj.put("url", page.getPath());
                obj.put("link", page.getPath() + ".html");
                children.add(obj);

                if (includeChildren) {
                    Iterator<Page> childPages = page.listChildren();
                    while (childPages.hasNext()) {
                        Page childPage = childPages.next();
                        if(childPage.hasContent()) {
                            ValueMap childMap = childPage.getContentResource().getValueMap();
                            Boolean childHidden = childMap.get("hideInNav", Boolean.FALSE);
                            if (!childHidden) {
                                obj = new HashMap<>();
                                obj.put("title", childPage.getTitle());
                                obj.put("url", childPage.getPath());
                                obj.put("link", childPage.getPath() + ".html");
                                obj.put(HIDE_IN_PRIME_NAV, childMap.get(HIDE_IN_PRIME_NAV, Boolean.FALSE).toString());
                                children.add(obj);
                            }
                        }
                    }
                }

                item.put("children", children);
                items.add(item);
            }
    }

    /**
     * Adds the children.
     *
     * @param parentPage the parent page
     * @param childPages the child pages
     * @param allElements the all elements
     * @param nestedChildren the nested children
     * @param includeChildren the include children
     */
    private void addChildren(
            final Page parentPage,
            final Iterator<Page> childPages,
            final List<Map<String, String>> allElements,
            final Boolean nestedChildren,
            final Boolean includeChildren) {
        while (childPages.hasNext()) {
            Page childPage = childPages.next();
            if (childPage.hasContent()) {
                ValueMap childMap = childPage.getContentResource().getValueMap();
                Boolean childHidden = childMap.get(HIDE_IN_NAV, Boolean.FALSE);
                
                if (childHidden) {
                    continue;
                }

                final Map<String, String> obj = new HashMap<>();
                final Iterator<Page> childNestedPages = childPage.listChildren();
                final Boolean noChildren = noChildren(childPage);
                String redirectpath = childPage.getProperties().get("redirectTarget", String.class);
                
                Boolean active= Utils.isActivePage(redirectpath, currentPage, childPage, getCurrenPage());
                obj.put(URL, childPage.getPath());
                obj.put(TITLE, childPage.getTitle());
                obj.put(HIDE_IN_NAV_DESK, childMap.get(HIDE_IN_NAV_DESK, Boolean.FALSE).toString());
                obj.put(BRAND_LOGO, childMap.get(BRAND_LOGO, StringUtils.EMPTY));
                obj.put(BRAND_LOGO_MOBILE, childMap.get(BRAND_LOGO_MOBILE, StringUtils.EMPTY));
                obj.put(BRAND_LOGO_ALT_TEXT, childMap.get(BRAND_LOGO_ALT_TEXT, StringUtils.EMPTY));
                obj.put(ACTIVE, Boolean.toString(active));
                obj.put(HIDE_IN_PRIME_NAV, childMap.get(HIDE_IN_PRIME_NAV, Boolean.FALSE).toString());

                if (!nestedChildren || noChildren) {
                    obj.put(LINK, childPage.getPath() + HTML_EXTENSION);
                }

                allElements.add(obj);

                if (nestedChildren && !noChildren) {
                    addChildren(parentPage, childNestedPages, allElements, Boolean.FALSE, Boolean.FALSE);
                }

                if (includeChildren && continueProcessing(parentPage, childPage)) {
                    addChildren(parentPage, childNestedPages, allElements, Boolean.FALSE, Boolean.TRUE);
                }
            }
        }
    }

    /**
     * No children.
     *
     * @param page the page
     * @return true, if successful
     */
    private boolean noChildren(final Page page) {
        final Iterator<Page> childNestedPages = page.listChildren();

        final List<Page> childrend = IteratorUtils
                .toList(childNestedPages)
                .stream()
                .filter(childPage -> childPage.hasContent() && !childPage.getContentResource().getValueMap().get(HIDE_IN_NAV, Boolean.FALSE))
                .collect(Collectors.toList());

        return CollectionUtils.isEmpty(childrend);
    }

    /**
     * Continue processing.
     *
     * @param parent the parent
     * @param child the child
     * @return true, if successful
     */
    private boolean continueProcessing(final Page parent, final Page child) {
        final ValueMap valueMap = parent.getContentResource().getValueMap();
        final Integer deepLevel = valueMap.get(DYNAMIC_MOBILE_DEEP_LEVEL, 1);
        final String parentPath = String.format(PARENT_REGEX, parent.getPath());
        final String childPath = child.getPath();
        final String path = childPath.replace(parentPath, StringUtils.EMPTY);

        return path.split(SEPARATOR).length < deepLevel;
    }

    /**
     * Adds the page to list.
     *
     * @param page the page
     * @param options the options
     * @param includeChildren the include children
     * @param active the active
     */
    private void addPageToList(
            final Page page,
            final List<Map<String, Object>> options,
            final Boolean includeChildren,
            final Boolean active) {
        if(page.hasContent()) {
            final Map<String, Object> item = new HashMap<>();
            final ValueMap valueMap = page.getContentResource().getValueMap();
            final Boolean hidden = valueMap.get(HIDE_IN_NAV, Boolean.FALSE);
            final boolean setToHideInRootPage = isPageSetToHideInRootPage(HIDE_NAV_ITEM, page.getName());
            if (hidden || setToHideInRootPage) {
                return;
            }

            item.put(TITLE, valueMap.get(SECTION_TITLE, valueMap.get(JCR_TITLE, StringUtils.EMPTY)));
            item.put(URL, page.getPath());
            item.put(LINK, page.getPath() + HTML_EXTENSION);
            item.put(HIDE_IN_NAV_DESK, valueMap.get(HIDE_IN_NAV_DESK, Boolean.FALSE).toString());
            item.put(ICON, valueMap.get(SECTION_ICON, String.class));
            item.put(ACTIVE, active);
            item.put(BANNER_SECTION_FRAGMENT_PATH, valueMap.get(BANNER_SECTION_FRAGMENT_PATH, StringUtils.EMPTY));
            item.put(HIDE_SUB_NAVIGATION_CURRENT_PAGE, isPageSetToHideInRootPage(HIDE_SUB_NAVIGATION, page.getName()));
            item.put(HIDE_DROPDOWN_PANEL, isPageSetToHideInRootPage(HIDE_DROPDOWN_PANEL, page.getName()));
            item.put(HIDE_IN_PRIME_NAV, valueMap.get(HIDE_IN_PRIME_NAV, Boolean.FALSE).toString());
            item.put(BRAND_LOGO, valueMap.get(BRAND_LOGO, StringUtils.EMPTY));
            item.put(BRAND_LOGO_MOBILE, valueMap.get(BRAND_LOGO_MOBILE, StringUtils.EMPTY));

            final Boolean groupNestedChildPages = valueMap.get(GROUP_NESTED_CHILD_PAGES, Boolean.FALSE);
            final Integer groupNestedChildPagesRows = valueMap.get(GROUP_NESTED_CHILD_PAGES_ROWS, 6);

            if (groupNestedChildPages) {
                final List<List<Map<String, String>>> nestedChildren = new ArrayList<>();
                final List<Map<String, String>> allElements = new ArrayList<>();
                final Iterator<Page> childPages = page.listChildren();
                addChildren(page, childPages, allElements, Boolean.TRUE, Boolean.FALSE);
                List<Map<String, String>> children = new ArrayList<>(allElements.size());

                for (Map<String, String> nestedPage : allElements) {
                    children.add(nestedPage);

                    if (children.size() == groupNestedChildPagesRows) {
                        nestedChildren.add(children);
                        children = new ArrayList<>();
                    }
                }

                if (CollectionUtils.isNotEmpty(children)) {
                    nestedChildren.add(children);
                }

                item.put(NESTED_CHILDREN, nestedChildren);
                item.put(DISPLAY_DROPDOWN_ICON, Boolean.FALSE);
            } else {
                final List<Map<String, String>> children = new ArrayList<>();
                final Iterator<Page> childPages = page.listChildren();
                addChildren(page, childPages, children, Boolean.FALSE, includeChildren);
                item.put(CHILDREN, children);
                addHideInPrimeNav(page,children,item);
            }

            options.add(item);
        }
    }

    private void addHideInPrimeNav(Page page, List<Map<String, String>> children,
			Map<String, Object> item) {
    	int pagesHideInPrimeNavCount = 0;
    	int childPageSize = children.size();
    	for(Map<String, String> childPageProperty : children) {
    		if (childPageProperty.get(HIDE_IN_PRIME_NAV).equals("true")) {
    			pagesHideInPrimeNavCount++;
            }
    	}
		int pageCount = childPageSize - pagesHideInPrimeNavCount;
		if (pageCount == 0 && pagesHideInPrimeNavCount != 0) {
			item.put(DISPLAY_DROPDOWN_ICON, Boolean.TRUE);
		} else {
			item.put(DISPLAY_DROPDOWN_ICON, Boolean.FALSE);
		}
    }
	

	/**
     * Gets the page.
     *
     * @return the page
     */
    public String getPage(){
        return HomePage.getTitle();
    }

    /**
     * Gets the this page.
     *
     * @return the this page
     */
    public String getThisPage(){
        ValueMap props = currentPage.getProperties();
        String templateType = props.get(RESOURCE_TYPE, StringUtils.EMPTY);

        return templateType;
    }

    /**
     * Gets the checks if is homepage.
     *
     * @return the checks if is homepage
     */
    public Boolean getIsHomepage(){
        return currentPage != null && currentPage.getPath().equals(homePath);
    }

    /**
     * Gets the checks if is secondary homepage.
     *
     * @return the checks if is secondary homepage
     */
    public Boolean getIsSecondaryHomepage() {
        return currentPage != null && secondaryNavigationHomePage != null
                && currentPage.getPath().equals(secondaryNavigationHomePage.getPath());
    }

    /**
     * Gets the current path.
     *
     * @return the current path
     */
    public String getCurrentPath(){
        return Optional.ofNullable(currentPage).map(Page::getPath).orElse(StringUtils.EMPTY);
    }

    /**
     * Gets the active page props.
     *
     * @return the active page props
     */
    private InheritanceValueMap getActivePageProps() {
        final Page currentActivePage = currentPage.getContentResource().getResourceResolver().getResource(activePage).adaptTo(Page.class);

        if (Objects.nonNull(currentActivePage) && currentActivePage.hasContent()) {
            return new HierarchyNodeInheritanceValueMap(currentActivePage.getContentResource());
        }

        return new HierarchyNodeInheritanceValueMap(currentPage.getContentResource());
    }

    /**
     * Sets the up.
     */
    private void setUp() {
        validateDisplayBrandLogoBannerForMobile(currentPage);

            InheritanceValueMap ivm = new HierarchyNodeInheritanceValueMap(currentPage.getContentResource());
            displaySecondaryNavigation = ivm.getInherited(DISPALY_SECONDARY_NAVIGATION, Boolean.FALSE);

            if (StringUtils.isNotEmpty(secondaryRootPath)) {
                displaySecondaryNavigation = Boolean.TRUE;
            }

            if (StringUtils.isNotEmpty(activePage)) {
                ivm = getActivePageProps();
            }

            useConditionNavigationMobile = ivm.getInherited(USE_CONDITION_NAVIGATION_MOBILE, Boolean.FALSE);
            conditionFragmentPath = ivm.getInherited(CONDITION_FRAGMENT_PATH, conditionFragmentPath);
            if (isBlank(conditionFragmentPath)) {
                conditionFragmentPath = StringUtils.EMPTY;
            }
            bannerText = ivm.getInherited(BANNER_TEXT, StringUtils.EMPTY);
            mobileConditionText = ivm.getInherited(MOBILE_CONDITION_TEXT, StringUtils.EMPTY);
            brandLogo = ivm.getInherited(BRAND_LOGO, StringUtils.EMPTY);
            brandLogoAltText = ivm.getInherited(BRAND_LOGO_ALT_TEXT, StringUtils.EMPTY);
            mobileOpenedConditionText = ivm.getInherited(MOBILE_OPENED_CONDITION_TEXT, StringUtils.EMPTY);
    }

    /**
     * Checks if the current page or parent page has activated the option to display a banner beneath the navigation
     * for mobile only
     * @param parent the current page
     */
    private void validateDisplayBrandLogoBannerForMobile(Page parent) {
        var currPage = parent;
        displayBrandLogoBannerForMobile = Boolean.FALSE;

        while (currPage != null && currPage.getDepth() > LANGUAGE_PAGE_DEPTH_LEVEL) {
            final ValueMap props = currPage.getProperties();
            displayBrandLogoBannerForMobile = props.get(DISPLAY_BRAND_LOGO_BANNER_FOR_MOBILE_PN, Boolean.FALSE);

            if (displayBrandLogoBannerForMobile) {
                brandLogoBannerForMobileOnly = props.get(BRAND_LOGO_BANNER_FOR_MOBILE_ONLY_PN, StringUtils.EMPTY);
                brandLogoBannerForMobileOnlyAltText = props.get(BAND_LOGO_BANNER_FOR_MOBILE_ONLY_ALT_TEXT,
                    StringUtils.EMPTY);
                break;
            }

            currPage = currPage.getParent();
        }
    }

    /**
     * Gets the value of the checkbox to enable the brand logo mobile displayment
     * @return a boolean value of TRUE indicating the banner is enabled and a FALSE the banner is not enabled
     */
    public Boolean getDisplayBrandLogoBannerForMobile() {
        return displayBrandLogoBannerForMobile;
    }

    /**
     * Gets the path of the brand banner logo
     * @return a String containing the brand banner logo path or empty if no value is set
     */
    public String getBrandLogoBannerForMobileOnly() {
        return brandLogoBannerForMobileOnly;
    }

    /**
     * Gets the alternative text for the brand logo banner
     * @return a String containing the brand logo banner or empty if no value is set
     */

    public String getBrandLogoBannerForMobileOnlyAltText() {
        return brandLogoBannerForMobileOnlyAltText;
    }
    /**
     * Gets the display secondary navigation.
     *
     * @return the display secondary navigation
     */
    public Boolean getDisplaySecondaryNavigation() {
        return displaySecondaryNavigation;
    }

    /**
     * Gets the condition fragment path.
     *
     * @return the condition fragment path
     */
    public String getConditionFragmentPath() {
        return conditionFragmentPath;
    }

    /**
     * Gets the banner text.
     *
     * @return the banner text
     */
    public String getBannerText() {
        return bannerText;
    }

    /**
     * Gets the mobile condition text.
     *
     * @return the mobile condition text
     */
    public String getMobileConditionText() {
        return mobileConditionText;
    }

    /**
     * Gets the brand logo.
     *
     * @return the brand logo
     */
    public String getBrandLogo() {
        return brandLogo;
    }

    /**
     * Gets the brand logo alt text.
     *
     * @return the brand logo alt text
     */
    public String getBrandLogoAltText() {
        return brandLogoAltText;
    }

    /**
     * Gets the mobile opened condition text.
     *
     * @return the mobile opened condition text
     */
    public String getMobileOpenedConditionText() {
        return mobileOpenedConditionText;
    }

    /**
     * Gets the server name.
     *
     * @return the server name
     */
    public String getServerName() {
        return serverName;
    }

    /**
     * Gets the header main logo for desktop view
     * @return the header main logo path for desktop view
     */
    public String getHomeLogoPathDesktop() {
        return homeLogoPathDesktop;
    }

    /**
     * Gets the header main logo for mobile view
     * @return the header main logo path for mobile view
     */
    public String getHomeLogoPathMobile() {
        return homeLogoPathMobile;
    }

    /**
     * Gets the header main logo alternative text
     * @return the header main logo alternative text
     */
    public String getHomeLogoAltText() {
        return homeLogoAltText;
    }

    public String getHomePath() {
        return homePath;
    }
}
