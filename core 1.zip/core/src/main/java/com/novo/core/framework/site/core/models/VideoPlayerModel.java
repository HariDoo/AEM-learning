package com.novo.core.framework.site.core.models;

import com.google.gson.JsonElement;


import com.google.gson.JsonObject;
import com.novo.core.framework.site.core.models.beans.TwentyThreeVideoBean;
import com.novo.core.framework.site.core.services.TwentyThreeVideoService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DurationFormatUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


@Model(adaptables = SlingHttpServletRequest.class)
public class VideoPlayerModel {

    @Inject
    @Optional
    @Via("resource")
    @Named("layout")
    public String layout;

    @Inject
    @Optional
    @Via("resource")
    @Named("linkHref")
    public String linkHref;

    @Inject
    @Optional
    @Via("resource")
    @Named("isIsi")
    public Boolean isIsi;

    private List<TwentyThreeVideoBean> videoBeanList;

    @SlingObject
    private ResourceResolver resourceResolver;

    @Self
    private SlingHttpServletRequest request;

    @OSGiService
    private TwentyThreeVideoService twentyThreeVideoService;

    private String videoId;
    private String playlist;
    private String calculatedLayout;
    private String href;
    private String origin;
    private List<String> transcriptsList;

    private static final Logger LOGGER = LoggerFactory.getLogger(VideoPlayerModel.class);
    private static final String COLON = ":";
    private static final String SLASH = "/";
    private static final String DOUBLE_SLASH = SLASH + SLASH;
    private static final String PROP_NAME_VIDEO_URL = "videoUrl";

    @PostConstruct
    protected void init() {
        Resource currentRes = request.getResource();
        Resource vidDetailsRes = currentRes.getChild("videDetails");
        if (null != vidDetailsRes) {
            Iterator<Resource> videos = vidDetailsRes.listChildren();
            videoBeanList = new ArrayList<>();
            int videosCount = 0;
            while (videos.hasNext()) {
                
                Resource videoRes = videos.next();
                ValueMap videoProps = videoRes.getValueMap();
                URL url = getVideoUrl(videoProps);
                if (url == null) {
                    continue;
                }
                String videoId = url.getPath().substring(url.getPath().lastIndexOf(SLASH) + 1);
                String videoServer = twentyThreeVideoService.getTwentyThreeVideoHost();
                String transcript = videoProps.containsKey("transcripts") ? videoProps.get("transcripts", String.class) : StringUtils.EMPTY;
                if (StringUtils.isNotEmpty(videoId) && StringUtils.isNotEmpty(videoServer)) {
                    videosCount++;
                    JsonObject response = twentyThreeVideoService.getTwentyThreeVideoObject(videoId, videoServer);
                    JsonObject photoJsonObject = getJsonObject(response, "photo");
                    TwentyThreeVideoBean videoBean = new TwentyThreeVideoBean();
                    String videoObjectId = getString(photoJsonObject, "photo_id");
                    String tokenObject = getString(photoJsonObject, "token");
                    String videoDuration = getString(photoJsonObject, "video_length");
                    if (videoDuration != null) {
                        long durationInLong = Long.parseLong(videoDuration) * 1000;
                        String formattedDuration = DurationFormatUtils.formatDuration(durationInLong, "HH:mm:ss");
                        videoBean.setDuration(formattedDuration);
                    }

                    videoBean.setVideoIdProp(videoId);
                    videoBean.setVideoId(videoObjectId);
                    videoBean.setVideoToken(tokenObject);
                    videoBean.setTreeId(getString(photoJsonObject, "tree_id"));
                    videoBean.setTitle(getString(photoJsonObject, "title"));
                    videoBean.setDescription(getString(photoJsonObject, "content"));
                    videoBean.setTranscript(transcript);
                    videoBean.setVideoServer(videoServer);
                    videoBeanList.add(videoBean);
                }
            }
            if (videosCount > 0) {
                videoId = videoBeanList.get(0).getVideoIdProp();

                if (videosCount > 1) {
                    for (int i = 0; i < videosCount; i++) {
                        if (i == 0) {
                            playlist = "playlist=" + videoBeanList.get(i).getVideoIdProp();
                            continue;
                        }

                        playlist += "," + videoBeanList.get(i).getVideoIdProp();
                    }
                }
            }
        }

        if (isIsi != null && layout != null) {
            calculatedLayout = isIsi && layout.contains("horizontal") ? "cope-core-videoplayer-horizontal" : "cope-core-videoplayer-vertical";
        }

        if (linkHref != null) {
            href = linkHref;
            Resource pathResource = resourceResolver.getResource(href);
            // check if resource exists and resource is not a dam object
            if (pathResource != null && linkHref.indexOf("/content/dam") != 0) {
                // append .html
                href += ".html";
            }
        }

        origin = request.getScheme() + "://" + request.getServerName() + (request.getServerPort() > 0 ? ":" + request.getServerPort() : "");
    }

    private URL getVideoUrl(ValueMap videoProps) {
        URL url = null;
        String videoUrlStr = videoProps.get(PROP_NAME_VIDEO_URL, StringUtils.EMPTY);
        if(StringUtils.isNotBlank(videoUrlStr)) {
            try {
                url = new URL(videoUrlStr);
            } catch (MalformedURLException e) {
                LOGGER.error("Error while parsing video url", e);
            }
        }
        return url;
    }

    private String getString(JsonObject json, String key) {
        java.util.Optional<JsonElement> jsonElement = getElement(json, key);
        return jsonElement.isPresent() ? jsonElement.get().getAsString() : null;
    }

    private JsonObject getJsonObject(JsonObject response, String key) {
        if (response != null) {
            java.util.Optional<JsonElement> jsonElement = getElement(response, key);

            if (jsonElement.isPresent() && jsonElement.get().isJsonObject()) {
                return jsonElement.get().getAsJsonObject();
            }
        }

        return null;
    }

    private java.util.Optional<JsonElement> getElement(JsonObject response, String photo) {
        return response != null ? java.util.Optional.ofNullable(response.get(photo)) : java.util.Optional.empty();
    }

    /*Getter Methods */
    public String getVideoId() {
        return videoId != null ? videoId : "";
    }

    public String getPlaylist() {
        return playlist != null ? playlist : "";
    }

    public String getCalculatedLayout() {
        return calculatedLayout;
    }

    public String getHref() {
        return href != null ? href : "";
    }

    public String getOrigin() {
        return origin;
    }

    public List<TwentyThreeVideoBean> getVideoBeanList() {
        return videoBeanList;
    }

    public TwentyThreeVideoBean getFirstVideoBean() {
        return videoBeanList.isEmpty() ? null : videoBeanList.get(0);
    }

    public List<String> getTranscriptsList() {
        //  return transcriptsList;
        return transcriptsList.isEmpty() ? null : transcriptsList;
    }
}
