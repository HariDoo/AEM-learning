package com.novo.core.framework.site.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;

import com.novo.core.framework.site.core.common.SiteTestContext;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import io.wcm.testing.mock.aem.junit5.AemContext;
import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith(AemContextExtension.class)
class ExperienceFragmentTest {

    private final AemContext context = SiteTestContext.newAemContext();

    private ExperienceFragment xf;

    private static final String FRAGMENT_PATH = "/content/experience-fragments/campaigns/hcp/rybelsus/poc/header/header";
    private static final String XF_PATH = "/content/rybelsus/mail/rybelsus-test/jcr:content/par/experiencefragment";
    private static final String XF_TITLE = "Header";
    private static final String XF_ID = "rybelsus-header";
    private static final String XF_CLASS = "rybelsus-header-xf";
    private static final String XF_AD_CONTENT = "ad-content";
    private static final String XF_TRIGGET_VALUE = "rxjanuvia";

    @BeforeEach
    public void setup() throws Exception {
        context.load().json("/experiencefragment/xf-cmp.json", "/content");
        context.currentResource(XF_PATH);
        xf = context.request().adaptTo(ExperienceFragment.class);
    }

    @Test
    void testInit() throws Exception {
        assertNotNull(xf);
    }

    @Test
    void testGetFragmentPath() throws Exception {
        assertEquals(FRAGMENT_PATH + "/jcr:content", xf.getFragmentPath());
    }

    @Test
    void testGetTitle() throws Exception {
        assertEquals(XF_TITLE, xf.getTitle());
    }

    @Test
    void testGetAdContent() throws Exception {
        assertEquals(XF_AD_CONTENT, xf.getAdContent());
    }

    @Test
    void testGetTriggerValue() throws Exception {
        assertEquals(XF_TRIGGET_VALUE, xf.getTriggerValue());
    }

    @Test
    void testGetId() throws Exception {
        assertEquals(XF_ID, xf.getId());
    }

    @Test
    void testGetClassName() throws Exception {
        assertEquals(XF_CLASS, xf.getClassName());
    }

    @Test
    void testIsInitiallyHidden() throws Exception {
        assertEquals(false, xf.isInitiallyHidden());
    }
}
