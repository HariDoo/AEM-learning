package com.novo.core.framework.site.core.models;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.day.cq.tagging.Tag;
import com.day.cq.tagging.TagManager;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;


import io.wcm.testing.mock.aem.junit5.AemContextExtension;

@ExtendWith({ AemContextExtension.class, MockitoExtension.class })
class ContentRollupModelTest {
	
	@InjectMocks
	private ContentRollupModel xf;

	public ContentRollupCategoryListClass groupTag = new ContentRollupCategoryListClass();

	@Mock
	Page homePage, res;
	@Mock
	ResourceResolver resourceResolver;
	@Mock
	PageManager pageManager;
	@Mock
	TagManager TagManager;
	@Mock
	Resource currentResource, categoryObject1;
	@Mock
	ValueMap props, homepageprops, childProps, prop1;
	@Mock
	Iterator<Page> iterator, childPages;
	@Mock
	Tag tag1;

	private static final String PARENT_PATH = "/content/cope-sandbox/en/test_gyqp";
	private static final String[] PARENT_TAG = { "tag1,tag2" };
	private static final String templateType = "/conf/novo-home";
	private static final String childTemplateType = "/conf/novo-home/novo-content-rollup";
	private static final String[] CHILD_TAG = { "tag1,tag2" };

	List<Resource> categoryObjectList = new ArrayList<Resource>();

	@BeforeEach
	void setUp() throws Exception {
		xf.setParentPath(PARENT_PATH);
		Mockito.lenient().when(resourceResolver.adaptTo(PageManager.class)).thenReturn(pageManager);
		Mockito.lenient().when(pageManager.getPage(PARENT_PATH)).thenReturn(homePage);
		xf.setParentTag(PARENT_TAG);
		Mockito.lenient().when(resourceResolver.adaptTo(TagManager.class)).thenReturn(TagManager);
		xf.setFilterStyle("dropdowns");
		xf.setCurrentResource(currentResource);
		Mockito.lenient().when(currentResource.getValueMap()).thenReturn(props);
		Mockito.lenient().when(props.get("filterAlphabetical", "false")).thenReturn("true");
		categoryObjectList.add(categoryObject1);
		xf.setCategoryObjectList(categoryObjectList);
		groupTag.setGroupTag("groupTag");
		groupTag.setGroupHeading("GroupHeadcing");
		Mockito.lenient().when(categoryObject1.adaptTo(ContentRollupCategoryListClass.class)).thenReturn(groupTag);

		/****** getChildValues() ******/
		Mockito.lenient().when(homePage.listChildren()).thenReturn(childPages);
		Mockito.lenient().when(childPages.hasNext()).thenReturn(true, false);
		Mockito.lenient().when(childPages.next()).thenReturn(res);
		Mockito.lenient().when(res.getProperties()).thenReturn(childProps);

		Mockito.lenient().when(childProps.get("sling:resourceType", StringUtils.EMPTY)).thenReturn(childTemplateType);
		Mockito.lenient().when(childProps.get("cq:tags", String[].class)).thenReturn(CHILD_TAG);
		Mockito.lenient().when(childProps.get("rollupDescription", StringUtils.EMPTY)).thenReturn("rollupDescription");
		Mockito.lenient().when(childProps.get("rollupImage", StringUtils.EMPTY)).thenReturn("rollupImage");
		Mockito.lenient().when(childProps.get("rollupImageMobile", StringUtils.EMPTY)).thenReturn("rollupImageMobile");
		Mockito.lenient().when(childProps.get("thumbnailImage", StringUtils.EMPTY)).thenReturn("thumbnailImage");
		Mockito.lenient().when(childProps.get("sectionTitle", StringUtils.EMPTY)).thenReturn("sectionTitle");
		Mockito.lenient().when(childProps.get("rollupMedia", StringUtils.EMPTY)).thenReturn("Asset");
		Mockito.lenient().when(childProps.get("rollupDownload", StringUtils.EMPTY)).thenReturn("jpeg");
		Mockito.lenient().when(childProps.get("rollupVideo", StringUtils.EMPTY)).thenReturn("rollupVideo");
		Mockito.lenient().when(childProps.get("hideDownloadLink", Boolean.FALSE)).thenReturn(Boolean.TRUE);
		Mockito.lenient().when(childProps.get("linkOneLabel", StringUtils.EMPTY)).thenReturn("linkOneLabel");
		Mockito.lenient().when(childProps.get("linkOnePath", StringUtils.EMPTY)).thenReturn("linkOnePath");
		Mockito.lenient().when(childProps.get("linkOneTarget", StringUtils.EMPTY)).thenReturn("linkOneTarget");
		Mockito.lenient().when(childProps.get("linkTwoLabel", StringUtils.EMPTY)).thenReturn("linkTwoLabel");
		Mockito.lenient().when(childProps.get("linkTwoPath", StringUtils.EMPTY)).thenReturn("linkTwoPath");
		Mockito.lenient().when(childProps.get("linkTwoTarget", StringUtils.EMPTY)).thenReturn("linkTwoTarget");

		/****** getDiseaseTag() ******/
		// Mockito.lenient().when(res.adaptTo(ValueMap.class)).thenReturn(prop1);
		Mockito.lenient().when(childProps.get("diseaseTag", StringUtils.EMPTY)).thenReturn("tagProperty");
		// Mockito.lenient().when(TagManager.resolve("tagProperty")).thenReturn(tag1);
		/****** getAddToCartAlt() ******/
		Mockito.lenient().when(currentResource.adaptTo(ValueMap.class)).thenReturn(prop1);
		Mockito.lenient().when(prop1.get("addToCartAlt", StringUtils.EMPTY)).thenReturn("addToCartAlt");
		/****** getAddToCartAlt() ******/
		Mockito.lenient().when(prop1.get("addToCartIcon", StringUtils.EMPTY)).thenReturn("addToCartIcon");
		/****** getAddToCartLabel() ******/
		Mockito.lenient().when(prop1.get("addToCartLabel", StringUtils.EMPTY)).thenReturn("addToCartLabel");
		Mockito.lenient().when(prop1.get("removeCartLabel", StringUtils.EMPTY)).thenReturn("removeCartLabel");
		Mockito.lenient().when(prop1.get("removeCartAlt", StringUtils.EMPTY)).thenReturn("removeCartAlt");
		Mockito.lenient().when(prop1.get("removeCartIcon", StringUtils.EMPTY)).thenReturn("removeCartIcon");

		/**** getTemplatePath ***********/
		Mockito.lenient().when(homePage.getProperties()).thenReturn(homepageprops);
		Mockito.lenient().when(homepageprops.get("sling:resourceType", StringUtils.EMPTY)).thenReturn(templateType);

	}

	@Test
	void test() {
		xf.init();
		assertNotNull(homePage);
	}

	@Test
	void testgetTemplatePath() {
		xf.getTemplatePath(homePage);
		assertNotNull(homePage);
	}

	@Test
	void testgetAddToCartIcon() {

		assertEquals("addToCartIcon", xf.getAddToCartIcon());
	}

	@Test
	void testgetAddToCartAlt() {
		assertEquals("addToCartAlt", xf.getAddToCartAlt());
	}

	@Test
	void testgetAddToCartLabel() {
		assertEquals("addToCartLabel", xf.getAddToCartLabel());
	}

	@Test
	void testgetRemoveCartLabel() {
		assertEquals("removeCartLabel", xf.getRemoveCartLabel());
	}

	@Test
	void testgetRemoveCartAlt() {
		assertEquals("removeCartAlt", xf.getRemoveCartAlt());
	}

	@Test
	void testgetRemoveCartIcon() {
		assertEquals("removeCartIcon", xf.getRemoveCartIcon());
	}

}
